"use client";
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Menu,
  MessageSquare,
  BookOpen,
  Globe,
  Sparkles,
  MoreVertical,
  Settings,
} from 'lucide-react';

const tabs = [
  { href: '/app/chat', label: 'Chat', icon: <MessageSquare className="w-5 h-5" /> },
  { href: '/app/board', label: 'Board', icon: <BookOpen className="w-5 h-5" /> },
  { href: '/app/map', label: 'Map', icon: <Globe className="w-5 h-5" /> },
  { href: '/app/more', label: 'More', icon: <Sparkles className="w-5 h-5" /> },
];

export default function BottomNav() {
  const pathname = usePathname() || '/app/chat';
  const [drawerOpen, setDrawerOpen] = useState(false);

  const activeTab = useMemo(
    () => tabs.find((tab) => pathname.startsWith(tab.href)) ?? tabs[0],
    [pathname]
  );

  const navButtonClasses =
    'p-2 text-primary/60 hover:text-primary transition-colors outline-none';

  return (
    <nav className="fixed inset-x-0 bottom-0 z-[999] bg-black/95 backdrop-blur-md border-t border-primary/20 lg:hidden">
      <div className="flex items-center justify-between px-3 py-2">
        <button
          type="button"
          className={navButtonClasses}
          onClick={() => setDrawerOpen((prev) => !prev)}
          aria-label="Open navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center gap-1 text-center font-mono text-[10px] tracking-[0.2em] uppercase text-primary glow-text">
          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/5 border border-primary/20">
            {activeTab.icon}
          </div>
          <span className="text-[10px] uppercase tracking-[0.25em]">{activeTab.label}</span>
        </div>

        <button
          type="button"
          className={navButtonClasses}
          onClick={() => setDrawerOpen((prev) => !prev)}
          aria-label="Toggle menu"
        >
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>

      <AnimatePresence>
        {drawerOpen && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            transition={{ duration: 0.16 }}
            className="fixed inset-x-3 bottom-[68px] z-[1000] rounded-2xl border border-primary/30 bg-black/95 backdrop-blur-md p-2 shadow-[0_24px_80px_rgba(0,0,0,0.45)]"
          >
            <div className="space-y-1">
              {tabs.map((tab) => {
                const active = pathname.startsWith(tab.href);
                return (
                  <Link
                    key={tab.href}
                    href={tab.href}
                    onClick={() => setDrawerOpen(false)}
                    className={`flex items-center gap-3 rounded-xl px-4 py-3 transition-all ${
                      active
                        ? 'bg-primary/10 text-primary'
                        : 'text-primary/40 hover:text-primary/70 hover:bg-primary/5'
                    }`}
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-primary/70">
                      {tab.icon}
                    </div>
                    <div className="flex-1">
                      <div className="font-mono text-sm tracking-[0.2em] uppercase">{tab.label}</div>
                    </div>
                    <span className={`h-1.5 w-1.5 rounded-full ${active ? 'bg-primary' : 'bg-transparent'}`} />
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
