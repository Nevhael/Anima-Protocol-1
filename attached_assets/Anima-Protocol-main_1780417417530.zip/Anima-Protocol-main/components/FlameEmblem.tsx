"use client";
import { motion } from 'framer-motion';

interface FlameEmblemProps {
  diameter?: number;
  animated?: boolean;
}

export default function FlameEmblem({ diameter = 340, animated = true }: FlameEmblemProps) {
  const radius = diameter / 2;
  const innerFlameSize = diameter * 0.55;
  const wreathRadius = diameter * 0.42;
  
  // Binary text for the outer ring - "LIGHT. THOUGHT. HARMONY."
  const binaryText = "● 01001100 • 01010100 • 01001000 ●";
  const displayText = "LIGHT. THOUGHT. HARMONY.";
  
  const containerVariants = {
    animate: animated ? {
      scale: [0.98, 1.02, 0.98],
    } : {},
  };

  const glowVariants = {
    animate: animated ? {
      opacity: [0.3, 0.7, 0.3],
      boxShadow: [
        `0 0 20px rgba(6, 182, 212, 0.3), 0 0 40px rgba(6, 182, 212, 0.1)`,
        `0 0 60px rgba(6, 182, 212, 0.6), 0 0 100px rgba(139, 92, 246, 0.3)`,
        `0 0 20px rgba(6, 182, 212, 0.3), 0 0 40px rgba(6, 182, 212, 0.1)`,
      ],
    } : {},
  };

  return (
    <motion.div
      className="relative flex items-center justify-center"
      style={{ width: diameter, height: diameter }}
      variants={containerVariants}
      animate="animate"
      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
    >
      {/* Outer glow halo - most distant */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: diameter + 80,
          height: diameter + 80,
          background: `radial-gradient(circle, rgba(6, 182, 212, 0.15) 0%, rgba(139, 92, 246, 0.05) 50%, transparent 100%)`,
        }}
        variants={glowVariants}
        animate="animate"
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Main emblem container with outer border */}
      <div
        className="relative flex items-center justify-center"
        style={{
          width: diameter,
          height: diameter,
          borderRadius: '50%',
          background: `radial-gradient(circle at 35% 35%, rgba(139, 92, 246, 0.1), rgba(6, 182, 212, 0.05), rgba(15, 23, 42, 0.8))`,
          border: `2px solid rgba(6, 182, 212, 0.4)`,
          boxShadow: `
            0 0 30px rgba(6, 182, 212, 0.4),
            0 0 60px rgba(139, 92, 246, 0.2),
            inset 0 0 40px rgba(6, 182, 212, 0.1),
            inset -40px -40px 60px rgba(0, 0, 0, 0.4)
          `,
        }}
      >
        {/* OUTER RING: Binary text "LIGHT. THOUGHT. HARMONY." */}
        <svg
          className="absolute"
          style={{
            width: diameter,
            height: diameter,
            filter: 'drop-shadow(0 0 8px rgba(6, 182, 212, 0.6))',
          }}
          viewBox={`0 0 ${diameter} ${diameter}`}
        >
          <defs>
            <path
              id="circlePath"
              d={`M ${radius}, ${radius} m -${radius}, 0 a ${radius},${radius} 0 1,1 ${diameter},0 a ${radius},${radius} 0 1,1 -${diameter},0`}
              fill="none"
            />
            <linearGradient id="ringGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(6, 182, 212, 1)" />
              <stop offset="50%" stopColor="rgba(139, 92, 246, 0.9)" />
              <stop offset="100%" stopColor="rgba(6, 182, 212, 1)" />
            </linearGradient>
          </defs>
          
          <text
            fill="url(#ringGradient)"
            fontSize={diameter * 0.06}
            fontFamily="'Share Tech Mono', monospace"
            fontWeight="600"
            letterSpacing="0.15em"
            textAnchor="middle"
            style={{
              filter: 'drop-shadow(0 0 4px rgba(6, 182, 212, 0.8))',
            }}
          >
            <textPath href="#circlePath" startOffset="50%" textAnchor="middle">
              {displayText}
            </textPath>
          </text>

          {/* Optional decorative dots around ring */}
          {[...Array(8)].map((_, i) => {
            const angle = (i / 8) * Math.PI * 2;
            const x = radius + Math.cos(angle - Math.PI / 2) * (radius - 15);
            const y = radius + Math.sin(angle - Math.PI / 2) * (radius - 15);
            return (
              <circle
                key={`ring-dot-${i}`}
                cx={x}
                cy={y}
                r="2"
                fill="rgba(6, 182, 212, 0.8)"
                opacity={0.6 + Math.sin(Date.now() / 500 + i) * 0.3}
              />
            );
          })}
        </svg>

        {/* WREATH / PETAL RING - Blue leaf shapes around the flame */}
        <svg
          className="absolute"
          style={{
            width: wreathRadius * 2,
            height: wreathRadius * 2,
          }}
          viewBox={`0 0 ${wreathRadius * 2} ${wreathRadius * 2}`}
        >
          <defs>
            <filter id="bloomFilter" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" />
            </filter>
          </defs>
          
          {/* 6 petal/leaf shapes in cyan-blue */}
          {[...Array(6)].map((_, i) => {
            const angle = (i / 6) * Math.PI * 2;
            const x = wreathRadius + Math.cos(angle) * (wreathRadius * 0.55);
            const y = wreathRadius + Math.sin(angle) * (wreathRadius * 0.55);
            return (
              <g key={`petal-${i}`} transform={`translate(${x}, ${y}) rotate(${(angle * 180) / Math.PI})`}>
                {/* Petal shape - elongated ellipse */}
                <ellipse
                  cx="0"
                  cy="0"
                  rx="12"
                  ry="24"
                  fill="rgba(6, 182, 212, 0.5)"
                  filter="url(#bloomFilter)"
                  style={{
                    opacity: 0.5 + 0.3 * Math.sin(Date.now() / 1000 + i),
                  }}
                />
                {/* Inner highlight */}
                <ellipse
                  cx="0"
                  cy="-8"
                  rx="6"
                  ry="12"
                  fill="rgba(6, 182, 212, 0.7)"
                  opacity="0.6"
                />
              </g>
            );
          })}
        </svg>

        {/* INNER FLAME: Purple-to-cyan gradient with glow */}
        <motion.div
          className="absolute flex items-center justify-center"
          style={{
            width: innerFlameSize,
            height: innerFlameSize,
          }}
          animate={animated ? { scale: [0.98, 1.04, 0.98] } : {}}
          transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <svg
            viewBox="0 0 100 140"
            style={{
              width: '100%',
              height: '100%',
              filter: `
                drop-shadow(0 0 15px rgba(139, 92, 246, 0.6))
                drop-shadow(0 0 30px rgba(6, 182, 212, 0.3))
                drop-shadow(0 0 45px rgba(139, 92, 246, 0.2))
              `,
            }}
            className="drop-shadow-2xl"
          >
            <defs>
              <linearGradient id="flameGradient" x1="50%" y1="0%" x2="50%" y2="100%">
                <stop offset="0%" stopColor="#c084fc" />
                <stop offset="40%" stopColor="#a855f7" />
                <stop offset="70%" stopColor="#06b6d4" />
                <stop offset="100%" stopColor="#0891b2" />
              </linearGradient>
              <filter id="glowInner" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur in="SourceGraphic" stdDeviation="2" />
              </filter>
            </defs>

            {/* Main flame body - organic teardrop shape */}
            <path
              d="M 50 10 C 40 25, 30 40, 30 55 C 30 75, 40 95, 50 110 C 60 95, 70 75, 70 55 C 70 40, 60 25, 50 10 Z"
              fill="url(#flameGradient)"
              filter="url(#glowInner)"
            />

            {/* Secondary flame wing - left side */}
            <path
              d="M 40 30 Q 25 40, 25 60 Q 25 75, 35 85"
              stroke="rgba(139, 92, 246, 0.6)"
              strokeWidth="3"
              fill="none"
              strokeLinecap="round"
              filter="url(#glowInner)"
            />

            {/* Secondary flame wing - right side */}
            <path
              d="M 60 30 Q 75 40, 75 60 Q 75 75, 65 85"
              stroke="rgba(6, 182, 212, 0.6)"
              strokeWidth="3"
              fill="none"
              strokeLinecap="round"
              filter="url(#glowInner)"
            />

            {/* Inner core highlight - bright cyan at flame base */}
            <ellipse
              cx="50"
              cy="70"
              rx="14"
              ry="18"
              fill="rgba(6, 182, 212, 0.5)"
              opacity="0.8"
            />

            {/* Tip highlight */}
            <circle
              cx="50"
              cy="15"
              r="6"
              fill="rgba(6, 182, 212, 0.9)"
              opacity="0.7"
            />
          </svg>
        </motion.div>

        {/* Inner glow circle - soft bloom at center */}
        <div
          className="absolute rounded-full"
          style={{
            width: innerFlameSize * 0.7,
            height: innerFlameSize * 0.7,
            background: `radial-gradient(circle, rgba(6, 182, 212, 0.25), transparent)`,
            filter: 'blur(12px)',
          }}
        />
      </div>

      {/* Outermost accent ring - thin crisp border with dots */}
      <div
        className="absolute rounded-full"
        style={{
          width: diameter + 12,
          height: diameter + 12,
          border: `1px solid rgba(6, 182, 212, 0.3)`,
          boxShadow: `0 0 15px rgba(6, 182, 212, 0.2)`,
        }}
      />
    </motion.div>
  );
}
