import React from 'react';

export default function StatusBar(){
  return (
    <div className="w-full flex items-center justify-between px-3 py-2 text-zinc-300 text-xs">
      <div className="flex items-center gap-2">
        <span className="text-zinc-200 font-medium">18:09</span>
        <span className="h-2 w-2 bg-red-500 rounded-full shadow-[0_0_8px_rgba(255,0,0,0.6)]" />
      </div>
      <div className="flex items-center gap-2">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="opacity-90"><path d="M6 2v20" stroke="#a3a3a3" strokeWidth="1.5" strokeLinecap="round"/></svg>
        <div className="text-zinc-300">100%</div>
      </div>
    </div>
  );
}
