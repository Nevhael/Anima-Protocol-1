"use client";
import { motion } from 'framer-motion';
import React from 'react';

export default function GlowingOrb({ color = '#06b6d4', size=24, label}:{color?:string,size?:number,label?:string}){
  return (
    <motion.div animate={{ scale:[1,1.06,1] }} transition={{ duration:4, repeat:Infinity }} className="flex items-center gap-2">
      <div style={{width:size, height:size, borderRadius:999, background:color, boxShadow:`0 8px 40px ${color}33, 0 0 30px ${color}66`}} />
      {label && <div className="text-xs text-zinc-300">{label}</div>}
    </motion.div>
  );
}
