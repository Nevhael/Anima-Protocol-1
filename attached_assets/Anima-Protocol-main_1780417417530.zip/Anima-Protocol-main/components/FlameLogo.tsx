"use client";
import { motion } from 'framer-motion';

export default function FlameLogo({ size = 56 }: { size?: number }){
  return (
    <motion.div
      initial={{ scale:0.9, opacity:0.8 }}
      animate={{ scale:[0.96,1.02,0.98], rotate: [0,1,-1,0] }}
      transition={{ duration:3, repeat: Infinity }}
      className="flex items-center justify-center"
      style={{ width:size, height:size }}>
      <div className="w-full h-full rounded-full bg-gradient-to-br from-[#7c3aed]/50 to-[#06b6d4]/30 flex items-center justify-center glass-card glow-pill" style={{boxShadow:'0 8px 40px rgba(192,132,252,0.18), 0 0 60px rgba(0,245,255,0.06)'}}>
        <svg viewBox="0 0 24 24" fill="none" width={size*0.7} height={size*0.7}>
          <path d="M12 3s3 2 3 5-2 4-3 6-1 4-1 4" stroke="#c084fc" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M12 21s-1-2-1-3 1-2 1-3 1-1 2-2 2-2 2-4S13 3 12 3" stroke="#00f5ff" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
    </motion.div>
  );
}
