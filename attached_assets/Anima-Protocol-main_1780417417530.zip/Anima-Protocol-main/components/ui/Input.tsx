import React from 'react'

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

const Input = React.forwardRef<HTMLInputElement, InputProps>(({ className, ...props }, ref) => {
  return (
    <input
      ref={ref}
      className={
        'bg-card border input px-3 py-2 rounded-md text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring' +
        (className ? ` ${className}` : '')
      }
      {...props}
    />
  )
})

Input.displayName = 'Input'

export default Input
