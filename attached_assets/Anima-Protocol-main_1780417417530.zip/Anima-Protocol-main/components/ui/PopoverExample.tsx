import React from 'react'
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
} from '@/components/ui/popover'
import { Button } from './index'

export default function PopoverExample() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost">Open Popover</Button>
      </PopoverTrigger>
      <PopoverContent className="w-56">
        <div className="text-sm text-foreground">This is an example popover content.</div>
        <div className="mt-2 text-[12px] text-muted-foreground">Use this area for actions or information.</div>
      </PopoverContent>
    </Popover>
  )
}
