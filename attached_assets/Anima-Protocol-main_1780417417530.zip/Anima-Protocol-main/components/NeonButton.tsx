"use client";
import React from 'react';
import { motion } from 'framer-motion';

export default function NeonButton({ children, className='', onClick }: { children: React.ReactNode; className?: string; onClick?: ()=>void }){
  return (
    <motion.button
      whileHover={{ scale:1.02 }}
      whileTap={{ scale:0.98 }}
      className={`px-5 py-3 rounded-xl bg-gradient-to-r from-[#00f5ff] to-[#c084fc] text-black font-semibold shadow-[0_8px_40px_rgba(0,245,255,0.12)] ${className}`}
      onClick={onClick}
    >
      {children}
    </motion.button>
  );
}
