import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { character_id, character_name, original_personality, recent_interactions, relationship_changes, emotional_journey } = await req.json();

    if (!character_name || !recent_interactions) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const evolutionPrompt = `${character_name} has been through transformative experiences. Analyze their growth:

ORIGINAL PERSONALITY:
${original_personality || 'Unknown'}

RECENT INTERACTIONS:
${recent_interactions.map((i) => `- ${i}`).join('\n')}

${relationship_changes ? `RELATIONSHIP CHANGES:\n${relationship_changes.map((r) => `- ${r}`).join('\n')}` : ''}

${emotional_journey ? `EMOTIONAL JOURNEY:\n${emotional_journey}` : ''}

Generate an EVOLVED version of this character:
1. New personality traits (what's changed)
2. Growth areas (how they've evolved)
3. New speaking patterns (if applicable)
4. Updated motivations
5. New vulnerabilities or strengths

Keep the core identity but show genuine growth and change. Be specific about what catalyzed each change.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: evolutionPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          evolved_personality: { type: 'string' },
          new_traits: { type: 'array', items: { type: 'string' } },
          growth_areas: { type: 'array', items: { type: 'string' } },
          updated_motivations: { type: 'array', items: { type: 'string' } },
          new_vulnerabilities: { type: 'array', items: { type: 'string' } },
          speaking_style_evolution: { type: 'string' },
        },
      },
    });

    return Response.json(response);
  } catch (error) {
    console.error('Character evolution error:', error);
    return Response.json(
      { error: error.message || 'Failed to evolve character' },
      { status: 500 }
    );
  }
});