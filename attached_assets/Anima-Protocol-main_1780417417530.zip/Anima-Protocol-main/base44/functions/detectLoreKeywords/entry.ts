import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Detects lore keywords in message content and retrieves deeper historical context.
 * Focuses on Slipthk War and world-building references.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { content, session_id } = await req.json();

    if (!content || typeof content !== 'string') {
      return Response.json({ error: 'Invalid content' }, { status: 400 });
    }

    // Core lore keywords and their significance
    const loreKeywords = {
      'Slipthk': { category: 'war', weight: 10, context: 'ancient_conflict' },
      'Resonance': { category: 'metaphysics', weight: 9, context: 'core_system' },
      'Anima': { category: 'beings', weight: 8, context: 'guardians' },
      'Fracture': { category: 'catastrophe', weight: 9, context: 'reality_break' },
      'Void': { category: 'danger', weight: 9, context: 'antimatter' },
      'Serenity': { category: 'character', weight: 7, context: 'guide' },
      'Chronicles': { category: 'history', weight: 8, context: 'records' },
      'Convergence': { category: 'event', weight: 8, context: 'timeline' },
      'Ethereal': { category: 'realm', weight: 7, context: 'dimension' },
      'Nexus': { category: 'location', weight: 8, context: 'centerpoint' },
    };

    // Detect keywords
    const detected = [];
    const contentLower = content.toLowerCase();

    for (const [keyword, metadata] of Object.entries(loreKeywords)) {
      if (contentLower.includes(keyword.toLowerCase())) {
        detected.push({
          keyword,
          ...metadata,
          position: contentLower.indexOf(keyword.toLowerCase()),
        });
      }
    }

    if (detected.length === 0) {
      return Response.json({ detected: [], context: [] });
    }

    // Sort by weight (higher = more important)
    detected.sort((a, b) => b.weight - a.weight);

    // Fetch lore context from WorldState
    const allLore = await base44.asServiceRole.entities.WorldState.list('-created_date', 500);
    
    const contextEntries = detected.map(detection => {
      // Find matching lore entry
      const matchingLore = allLore.find(entry =>
        entry.subject?.toLowerCase().includes(detection.keyword.toLowerCase()) ||
        entry.fact?.toLowerCase().includes(detection.keyword.toLowerCase())
      ) || {
        subject: detection.keyword,
        fact: `Key concept in the Slipthk universe: ${detection.keyword}`,
        category: detection.category,
        importance: detection.weight > 8 ? 'critical' : 'standard',
      };

      return {
        keyword: detection.keyword,
        category: detection.category,
        weight: detection.weight,
        subject: matchingLore.subject || detection.keyword,
        fact: matchingLore.fact,
        importance: matchingLore.importance,
        color_hex: matchingLore.color_hex || '#60A5FA',
      };
    });

    return Response.json({
      detected: detected.slice(0, 3), // Limit to top 3 to avoid clutter
      context: contextEntries.slice(0, 3),
      session_id,
    });
  } catch (error) {
    console.error('Lore keyword detection error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});