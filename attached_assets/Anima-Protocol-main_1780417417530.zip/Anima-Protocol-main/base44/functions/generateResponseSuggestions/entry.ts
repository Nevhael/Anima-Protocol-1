import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, character_id, recent_messages, emotional_state } = await req.json();

    if (!session_id || !character_id || !recent_messages || recent_messages.length === 0) {
      return Response.json(
        { error: 'Missing required parameters' },
        { status: 400 }
      );
    }

    // Fetch character data
    const character = await base44.entities.Character.list('-created_date', 1).then(chars => {
      return chars.find(c => c.id === character_id);
    });

    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Build context from recent messages
    const messageContext = recent_messages
      .slice(-5)
      .map(m => `${m.character_name || 'User'}: ${m.content}`)
      .join('\n');

    const emotionalNote = emotional_state?.emotion
      ? `Current emotion: ${emotional_state.emotion} (intensity: ${emotional_state.intensity}/10)`
      : '';

    const prompt = `You are ${character.name}${character.universe ? ` from ${character.universe}` : ''}.
${character.personality ? `Personality: ${character.personality}\n` : ''}${character.speaking_style ? `Speaking style: ${character.speaking_style}\n` : ''}${emotionalNote ? `\n${emotionalNote}\n` : ''}
Recent conversation:
${messageContext}

Generate 3 distinct, contextual response options for ${character.name} to say next. Each response should:
1. Stay in character with unique voice and perspective
2. Reflect current emotional state
3. Move the conversation forward authentically
4. Be 1-2 sentences max

Respond with ONLY valid JSON array with no markdown or extra text:
[
  { "text": "First response option", "reasoning": "Why this works" },
  { "text": "Second response option", "reasoning": "Why this works" },
  { "text": "Third response option", "reasoning": "Why this works" }
]`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "array",
        items: {
          type: "object",
          properties: {
            text: { type: "string" },
            reasoning: { type: "string" }
          }
        }
      }
    });

    // Ensure result is an array
    const suggestions = Array.isArray(result) ? result : [];

    return Response.json({
      suggestions: suggestions.slice(0, 3),
    });
  } catch (error) {
    console.error('Error generating suggestions:', error);
    return Response.json(
      { error: error.message || 'Failed to generate suggestions' },
      { status: 500 }
    );
  }
});