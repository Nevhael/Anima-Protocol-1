import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { character_name, personality, speaking_style, backstory, recent_context, user_input } = await req.json();

    if (!character_name || !user_input) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const characterPrompt = `You are ${character_name}. Respond ONLY as this character, maintaining their unique voice and personality.

CRITICAL CHARACTER TRAITS:
${personality ? `Personality: ${personality}` : ''}
${speaking_style ? `How You Speak: ${speaking_style}` : ''}
${backstory ? `Your Background: ${backstory}` : ''}

RECENT CONTEXT:
${recent_context || 'No prior context'}

USER MESSAGE:
"${user_input}"

RESPOND AUTHENTICALLY as ${character_name}. Use their unique voice, speech patterns, and mannerisms. Stay completely in character. No explanations, just the response.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: characterPrompt,
    });

    return Response.json({
      content: response,
      character_name,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Character dialogue error:', error);
    return Response.json(
      { error: error.message || 'Failed to generate dialogue' },
      { status: 500 }
    );
  }
});