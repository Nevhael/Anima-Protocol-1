import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_a_id,
      character_b_id,
      session_id,
      score_delta,
      catalyst_event,
      shared_memory_id,
      emotional_context,
    } = await req.json();

    if (!character_a_id || !character_b_id || !session_id || score_delta === undefined) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Normalize IDs for consistent querying (alphabetical order)
    const [charA, charB] = [character_a_id, character_b_id].sort();

    // Find or create relationship history
    let relationship = await base44.entities.RelationshipHistory.filter({
      character_a_id: charA,
      character_b_id: charB,
    });

    let relHistory;
    if (relationship?.length > 0) {
      relHistory = relationship[0];
    } else {
      relHistory = await base44.entities.RelationshipHistory.create({
        character_a_id: charA,
        character_b_id: charB,
        session_ids: [session_id],
        interaction_count: 1,
        current_score: 0,
        score_history: [],
        shared_memories: [],
        relationship_arc: 'forming',
        key_turning_points: [],
        recurring_themes: [],
        trust_level: 0.3,
        vulnerability_history: [],
      });
    }

    // Update score
    const newScore = Math.max(-100, Math.min(100, (relHistory.current_score || 0) + score_delta));
    const scoreChange = newScore - (relHistory.current_score || 0);

    // Add to score history
    const updatedScoreHistory = [
      ...(relHistory.score_history || []),
      {
        session_id,
        score: newScore,
        delta: scoreChange,
        catalyst: catalyst_event || 'interaction',
      },
    ];

    // Add session if new
    const updatedSessions = Array.from(
      new Set([...(relHistory.session_ids || []), session_id])
    );

    // Add shared memory
    const updatedSharedMemories = shared_memory_id
      ? Array.from(new Set([...(relHistory.shared_memories || []), shared_memory_id]))
      : relHistory.shared_memories || [];

    // Determine relationship arc
    const arc = determineRelationshipArc(updatedScoreHistory, newScore);

    // Identify turning points (large score swings)
    const updatedTurningPoints = [...(relHistory.key_turning_points || [])];
    if (Math.abs(scoreChange) >= 15) {
      updatedTurningPoints.push({
        memory_id: shared_memory_id || 'unknown',
        session_id,
        impact: scoreChange,
        description: catalyst_event || 'Major relationship shift',
      });
    }

    // Calculate trust level (based on consistency)
    const trustLevel = calculateTrustLevel(updatedScoreHistory);

    // Detect recurring themes
    const themes = extractRecurringThemes(updatedScoreHistory, updatedTurningPoints);

    // Update relationship
    const updated = await base44.entities.RelationshipHistory.update(relHistory.id, {
      current_score: newScore,
      score_history: updatedScoreHistory,
      session_ids: updatedSessions,
      shared_memories: updatedSharedMemories,
      interaction_count: (relHistory.interaction_count || 0) + 1,
      relationship_arc: arc,
      key_turning_points: updatedTurningPoints.slice(-5), // Keep last 5
      recurring_themes: themes,
      trust_level: trustLevel,
    });

    return Response.json({
      relationship: updated,
      score_change: scoreChange,
      new_score: newScore,
      arc: arc,
      trust_level: trustLevel,
    });
  } catch (error) {
    console.error('Relationship evolution error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function determineRelationshipArc(scoreHistory, currentScore) {
  if (scoreHistory.length < 2) return 'forming';

  const recentDeltas = scoreHistory.slice(-5).map(h => h.delta || 0);
  const avgRecent = recentDeltas.reduce((a, b) => a + b, 0) / recentDeltas.length;
  const trend = recentDeltas.slice(-2).reduce((a, b) => a + b, 0) / 2;

  if (currentScore < -30) return 'deteriorating';
  if (currentScore > 50) return 'deepening';
  if (avgRecent > 5) return 'recovering';
  if (trend > 0) return 'transforming';
  if (Math.abs(trend) < 2) return 'stable';
  return 'forming';
}

function calculateTrustLevel(scoreHistory) {
  if (scoreHistory.length === 0) return 0.3;

  // Trust increases with consistency (low variance in deltas)
  const deltas = scoreHistory.map(h => h.delta || 0);
  const avgDelta = deltas.reduce((a, b) => a + b, 0) / deltas.length;
  const variance = deltas.reduce((sum, d) => sum + Math.pow(d - avgDelta, 2), 0) / deltas.length;
  const stability = Math.max(0, 1 - variance / 100);

  // Also consider score level (higher scores = more trust)
  const currentScore = scoreHistory[scoreHistory.length - 1]?.score || 0;
  const scoreComponent = (currentScore + 100) / 200;

  return Math.min(1, (stability * 0.5 + scoreComponent * 0.5));
}

function extractRecurringThemes(scoreHistory, turningPoints) {
  // Simple theme extraction from deltas and turning point descriptions
  const themes = new Set();

  scoreHistory.forEach(h => {
    if (h.catalyst?.includes('conflict')) themes.add('conflict-resolution');
    if (h.catalyst?.includes('vulnerability')) themes.add('emotional-openness');
    if (h.catalyst?.includes('growth')) themes.add('mutual-growth');
    if (h.delta > 10) themes.add('positive-breakthrough');
    if (h.delta < -10) themes.add('tension');
  });

  turningPoints.forEach(tp => {
    if (tp.description?.includes('betrayal')) themes.add('trust-rebuilding');
    if (tp.impact > 20) themes.add('major-positive-shift');
  });

  return Array.from(themes);
}