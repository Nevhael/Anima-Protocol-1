import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, branches, triggering_choice, timestamp } = await req.json();

    if (!session_id || !branches || branches.length === 0) {
      return Response.json({ success: false, message: 'Missing required fields' }, { status: 400 });
    }

    // Store as a WorldSnapshot for later branch restoration
    const branchSnapshot = {
      session_id,
      branch_name: `Decision Point: ${triggering_choice.substring(0, 40)}...`,
      decision_point: triggering_choice,
      message_index: 0,
      world_state: {
        predicted_branches: branches.map(b => ({
          id: b.id,
          name: b.name,
          status: b.status,
          probability: b.probability,
          impact_level: b.impact_level,
          consequences: b.consequences,
        })),
      },
      key_events: branches.map(b => `${b.name}: ${b.description}`),
      is_active: true,
      depth: 0,
    };

    await base44.entities.WorldSnapshot.create(branchSnapshot).catch(() => {});

    return Response.json({
      success: true,
      branches_stored: branches.length,
      snapshot_created: true,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});