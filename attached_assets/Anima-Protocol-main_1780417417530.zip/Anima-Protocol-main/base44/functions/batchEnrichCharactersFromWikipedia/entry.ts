import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { batch_size = 5, limit = null } = await req.json();

    // Fetch all characters
    const characters = await base44.entities.Character.list("-created_date", 1000);
    const toProcess = limit ? characters.slice(0, limit) : characters;

    const results = {
      total: toProcess.length,
      enriched: 0,
      failed: 0,
      skipped: 0,
      updates: [],
    };

    // Process in batches to avoid overwhelming Wikipedia API
    for (let i = 0; i < toProcess.length; i += batch_size) {
      const batch = toProcess.slice(i, i + batch_size);

      await Promise.all(
        batch.map(async (char) => {
          try {
            if (char._enriched_at) {
              results.skipped++;
              return;
            }

            const wikiData = await fetchWikipediaData(
              char.universe ? `${char.name} ${char.universe}` : char.name
            );

            if (!wikiData) {
              results.failed++;
              return;
            }

            const extracted = extractPersonalityTraits(wikiData.content, char.name);
            const speaking_style = generateSpeakingStyle(wikiData.content, char.name);
            const backstory = wikiData.content.slice(0, 500);

            // Update character
            await base44.entities.Character.update(char.id, {
              personality: extracted.personality,
              backstory,
              speaking_style,
              _wikipedia_source: wikiData.url,
              _enriched_at: new Date().toISOString(),
            });

            results.enriched++;
            results.updates.push({
              character_id: char.id,
              character_name: char.name,
              wikipedia_url: wikiData.url,
            });
          } catch (err) {
            console.error(`Error enriching ${char.name}:`, err);
            results.failed++;
          }
        })
      );

      // Small delay between batches to respect API rate limits
      if (i + batch_size < toProcess.length) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    return Response.json({
      success: true,
      results,
      summary: `Enriched ${results.enriched}/${results.total} characters from Wikipedia`,
    });
  } catch (error) {
    console.error('Batch enrichment error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function fetchWikipediaData(query) {
  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(query)}&utf8=1`;
    const searchRes = await fetch(searchUrl);
    const searchData = await searchRes.json();

    if (!searchData.query.search.length) return null;

    const pageTitle = searchData.query.search[0].title;
    const contentUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&titles=${encodeURIComponent(pageTitle)}&prop=extracts&exintro=true&explaintext=true`;
    const contentRes = await fetch(contentUrl);
    const contentData = await contentRes.json();

    const pages = contentData.query.pages;
    const pageId = Object.keys(pages)[0];
    const extract = pages[pageId].extract || '';

    return {
      title: pageTitle,
      content: extract,
      url: `https://en.wikipedia.org/wiki/${encodeURIComponent(pageTitle)}`,
    };
  } catch (err) {
    console.error('Wikipedia fetch error:', err);
    return null;
  }
}

function extractPersonalityTraits(content, characterName) {
  const traits = [];
  const personality = [];

  const personalityKeywords = {
    brave: ['brave', 'courageous', 'fearless', 'valiant', 'heroic'],
    intelligent: ['intelligent', 'wise', 'clever', 'smart', 'intellectual'],
    kind: ['kind', 'compassionate', 'caring', 'empathetic', 'gentle'],
    cunning: ['cunning', 'sly', 'manipulative', 'strategic', 'scheming'],
    stoic: ['stoic', 'calm', 'composed', 'collected', 'serene'],
    passionate: ['passionate', 'fiery', 'intense', 'emotional', 'fervent'],
    mysterious: ['mysterious', 'enigmatic', 'secretive', 'hidden', 'obscure'],
    noble: ['noble', 'honorable', 'dignified', 'refined', 'aristocratic'],
    ambitious: ['ambitious', 'driven', 'determined', 'goal-oriented', 'striving'],
    rebellious: ['rebellious', 'defiant', 'revolutionary', 'radical', 'nonconformist'],
  };

  const contentLower = content.toLowerCase();

  Object.entries(personalityKeywords).forEach(([trait, keywords]) => {
    if (keywords.some(kw => contentLower.includes(kw))) {
      traits.push(trait);
      personality.push(`${trait.charAt(0).toUpperCase() + trait.slice(1)}`);
    }
  });

  return {
    traits: traits.slice(0, 5),
    personality: personality.slice(0, 4).join(', ') || `${characterName} is a complex character.`,
  };
}

function generateSpeakingStyle(content, characterName) {
  const contentLower = content.toLowerCase();

  const patterns = {
    formal: contentLower.includes('diplomat') || contentLower.includes('royal') || contentLower.includes('noble'),
    sarcastic: contentLower.includes('wit') || contentLower.includes('humor') || contentLower.includes('irony'),
    poetic: contentLower.includes('artist') || contentLower.includes('poet') || contentLower.includes('muse'),
    technical: contentLower.includes('scientist') || contentLower.includes('inventor') || contentLower.includes('academic'),
    casual: contentLower.includes('adventurer') || contentLower.includes('rogue') || contentLower.includes('free'),
  };

  const detected = Object.entries(patterns)
    .filter(([_, match]) => match)
    .map(([style]) => style)[0] || 'conversational';

  const styles = {
    formal: `${characterName} speaks with refined eloquence and measured precision, employing sophisticated vocabulary and articulate phrasing.`,
    sarcastic: `${characterName} communicates with wit and irony, employing clever wordplay and sharp observations.`,
    poetic: `${characterName} speaks in vivid, evocative language, painting scenes with metaphor and symbolism.`,
    technical: `${characterName} speaks methodically, favoring precise terminology and logical explanations.`,
    casual: `${characterName} speaks conversationally and informally, with natural charm and spontaneity.`,
    conversational: `${characterName} communicates in a balanced, approachable manner, maintaining authenticity.`,
  };

  return styles[detected] || styles.conversational;
}