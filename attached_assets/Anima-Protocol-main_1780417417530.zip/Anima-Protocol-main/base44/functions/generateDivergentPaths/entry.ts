import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      session_id,
      character_id,
      character_name,
      recent_messages,
      character_memories = [],
      world_state = {},
      relationships = {},
    } = await req.json();

    if (!session_id || !character_id) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Build context for path generation
    const recentDialogue = recent_messages
      .slice(-4)
      .map(m => `${m.character_name}: ${m.content}`)
      .join('\n');

    const memoryContext = character_memories
      .slice(0, 5)
      .map(m => `• ${m.fact || m.category}`)
      .join('\n');

    const prompt = `You are a narrative designer. Given the current scene state and character dynamics, generate 3 divergent story paths.

CHARACTER: ${character_name}
RECENT DIALOGUE:
${recentDialogue}

CHARACTER MEMORIES:
${memoryContext || 'No memories recorded yet'}

WORLD STATE:
${world_state.current_location ? `Location: ${world_state.current_location}` : ''}
${world_state.current_season ? `Season: ${world_state.current_season}` : ''}

TASK: Generate 3 distinct narrative paths that:
1. Build on character memories and established personality
2. Create different emotional/dramatic arcs
3. Vary in tone and consequence

Format as JSON array with 3 objects, each containing:
{
  "title": "Short path name (3 words max)",
  "description": "One sentence outcome",
  "emotional_arc": "tension/discovery/resolution/mystery/conflict/harmony",
  "consequences": "Brief impact on world/relationships",
  "difficulty": "emotional stakes - high/medium/low"
}`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          paths: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                description: { type: 'string' },
                emotional_arc: { type: 'string' },
                consequences: { type: 'string' },
                difficulty: { type: 'string' },
              },
            },
            minItems: 3,
            maxItems: 3,
          },
        },
        required: ['paths'],
      },
    });

    // Extract paths from response
    const paths = response.paths || [];
    if (paths.length < 3) {
      return Response.json({ error: 'Failed to generate 3 paths' }, { status: 500 });
    }

    return Response.json({
      success: true,
      paths: paths.map((p, idx) => ({
        id: `path-${idx}`,
        index: idx,
        title: p.title,
        description: p.description,
        emotional_arc: p.emotional_arc,
        consequences: p.consequences,
        difficulty: p.difficulty,
      })),
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error generating divergent paths:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});