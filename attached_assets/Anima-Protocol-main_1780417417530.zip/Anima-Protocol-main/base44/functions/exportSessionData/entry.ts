import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { session_id, format, data_types } = body;

    if (!session_id || !format || !['csv', 'pdf'].includes(format)) {
      return Response.json({ error: 'Invalid parameters' }, { status: 400 });
    }

    // Fetch session
    const session = await base44.entities.ChatSession.list();
    const targetSession = session.find(s => s.id === session_id);

    if (!targetSession) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    // Collect data based on requested types
    let exportData = {
      session: targetSession,
      messages: [],
      characters: [],
      memories: [],
      quests: [],
      inventory: [],
    };

    if (data_types.includes('messages')) {
      exportData.messages = targetSession.messages || [];
    }

    if (data_types.includes('characters')) {
      const chars = await base44.entities.Character.list('-created_date', 100);
      exportData.characters = chars || [];
    }

    if (data_types.includes('memories') && targetSession.character_id) {
      const mems = await base44.entities.VectorMemory.filter({ 
        character_id: targetSession.character_id 
      }, '-created_date', 100);
      exportData.memories = mems || [];
    }

    if (data_types.includes('quests')) {
      const quests = await base44.entities.Quest.filter({ 
        session_id: session_id 
      }, '-created_date', 100);
      exportData.quests = quests || [];
    }

    if (data_types.includes('inventory') && targetSession.character_id) {
      const inv = await base44.entities.Inventory.filter({ 
        character_id: targetSession.character_id,
        session_id: session_id
      }, '-created_date', 100);
      exportData.inventory = inv || [];
    }

    // Generate export based on format
    if (format === 'csv') {
      const csv = generateCSV(exportData, data_types);
      const filename = `${targetSession.title || 'session'}_export_${new Date().getTime()}.csv`;
      
      return new Response(csv, {
        headers: {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': `attachment; filename="${filename}"`,
        },
      });
    }

    if (format === 'pdf') {
      // For PDF, we'll return the data and let the frontend generate it with jsPDF
      return Response.json({
        success: true,
        data: exportData,
        filename: `${targetSession.title || 'session'}_export_${new Date().getTime()}.pdf`,
      });
    }
  } catch (error) {
    console.error('Export error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function generateCSV(data, dataTypes) {
  const rows = [];

  // Add metadata
  rows.push(['EXPORT METADATA']);
  rows.push(['Session Title', data.session.title || 'Untitled']);
  rows.push(['Export Date', new Date().toISOString()]);
  rows.push(['Mode', data.session.mode || 'unknown']);
  rows.push([]);

  // Messages
  if (dataTypes.includes('messages') && data.messages.length > 0) {
    rows.push(['MESSAGES']);
    rows.push(['Timestamp', 'Character', 'Content']);
    data.messages.forEach(msg => {
      const content = (msg.content || '').replace(/"/g, '""').replace(/\n/g, ' ');
      rows.push([
        msg.timestamp || '',
        msg.character_name || msg.role || '',
        `"${content}"`,
      ]);
    });
    rows.push([]);
  }

  // Characters
  if (dataTypes.includes('characters') && data.characters.length > 0) {
    rows.push(['CHARACTERS']);
    rows.push(['Name', 'Universe', 'Category', 'Personality']);
    data.characters.forEach(char => {
      const personality = (char.personality || '').replace(/"/g, '""').slice(0, 100);
      rows.push([
        char.name || '',
        char.universe || '',
        char.category || '',
        `"${personality}"`,
      ]);
    });
    rows.push([]);
  }

  // Memories
  if (dataTypes.includes('memories') && data.memories.length > 0) {
    rows.push(['MEMORIES']);
    rows.push(['Title', 'Type', 'Content', 'Emotional Weight']);
    data.memories.forEach(mem => {
      const content = (mem.content || '').replace(/"/g, '""').slice(0, 100);
      rows.push([
        mem.title || mem.subject || '',
        mem.memory_type || '',
        `"${content}"`,
        mem.emotional_signature?.intensity || '',
      ]);
    });
    rows.push([]);
  }

  // Quests
  if (dataTypes.includes('quests') && data.quests.length > 0) {
    rows.push(['QUESTS']);
    rows.push(['Title', 'Status', 'Difficulty', 'Description']);
    data.quests.forEach(quest => {
      const desc = (quest.description || '').replace(/"/g, '""').slice(0, 100);
      rows.push([
        quest.title || '',
        quest.status || '',
        quest.difficulty || '',
        `"${desc}"`,
      ]);
    });
    rows.push([]);
  }

  // Inventory
  if (dataTypes.includes('inventory') && data.inventory.length > 0) {
    rows.push(['INVENTORY']);
    rows.push(['Item', 'Type', 'Quantity', 'Rarity', 'Equipped']);
    data.inventory.forEach(item => {
      rows.push([
        item.name || '',
        item.type || '',
        item.quantity || 1,
        item.rarity || '',
        item.equipped ? 'Yes' : 'No',
      ]);
    });
    rows.push([]);
  }

  // Convert to CSV string
  return rows.map(row => 
    row.map(cell => {
      if (typeof cell === 'string' && (cell.includes(',') || cell.includes('"') || cell.includes('\n'))) {
        return `"${cell.replace(/"/g, '""')}"`;
      }
      return cell;
    }).join(',')
  ).join('\n');
}