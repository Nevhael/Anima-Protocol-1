import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, format = 'markdown', include_summary = true } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    if (!['markdown', 'pdf'].includes(format)) {
      return Response.json({ error: 'Invalid format' }, { status: 400 });
    }

    // Fetch session
    const sessions = await base44.asServiceRole.entities.ChatSession.list('-updated_date', 100);
    const session = sessions.find((s) => s.id === session_id);

    if (!session) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    // Generate AI summary if requested
    let summary = '';
    if (include_summary) {
      const messages = (session.messages || []).slice(-20);
      const conversationText = messages
        .map((m) => `${m.character_name || 'You'}: ${m.content}`)
        .join('\n\n');

      const summaryResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a brief chapter summary (150-200 words) of this story excerpt. Focus on key moments, character interactions, and narrative progress:\n\n${conversationText}`,
      });
      summary = summaryResult;
    }

    // Build markdown content
    let content = '';
    content += `# ${session.title || 'Chat Session'}\n\n`;
    content += `**Date:** ${new Date(session.created_date).toLocaleDateString()}\n\n`;

    if (summary) {
      content += `## Chapter Summary\n\n${summary}\n\n`;
    }

    content += `## Conversation\n\n`;

    const messages = session.messages || [];
    messages.forEach((msg) => {
      if (msg.type === 'event') return;
      if (msg.character_name === '__typing__' || msg.character_name === '__thinking__') return;

      const speaker = msg.role === 'user' ? 'You' : (msg.character_name || 'Character');
      content += `**${speaker}:** ${msg.content}\n\n`;
    });

    if (format === 'markdown') {
      return new Response(content, {
        status: 200,
        headers: {
          'Content-Type': 'text/markdown; charset=utf-8',
          'Content-Disposition': `attachment; filename="${(session.title || 'session').replace(/[^a-z0-9]/gi, '_')}.md"`,
        },
      });
    }

    // PDF export using simple HTML-to-PDF approach
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; max-width: 800px; margin: 40px; }
          h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
          h2 { color: #555; margin-top: 30px; }
          strong { color: #0056b3; }
          p { color: #666; }
        </style>
      </head>
      <body>
        ${content.replace(/\n/g, '</p><p>').replace(/#+ /g, (match) => {
          const level = match.trim().split(' ')[0].length;
          return `</p><h${level}>`;
        }).replace(/\*\*/g, '<strong>').replace(/<strong>([^<]+)<\/strong>/g, '<strong>$1</strong>')}
      </body>
      </html>
    `;

    // For now, return HTML content (user can print to PDF via browser)
    return new Response(htmlContent, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `attachment; filename="${(session.title || 'session').replace(/[^a-z0-9]/gi, '_')}.html"`,
      },
    });
  } catch (error) {
    console.error('Export error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});