import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { snapshot_id, session_id } = await req.json();

    if (!snapshot_id || !session_id) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    // Fetch snapshot
    const snapshots = await base44.entities.WorldSnapshot.list("-created_date", 100);
    const snapshot = snapshots?.find(s => s.id === snapshot_id);

    if (!snapshot) {
      return Response.json({ error: 'Snapshot not found' }, { status: 404 });
    }

    // Update session to point to this branch
    await base44.entities.ChatSession.update(session_id, {
      active_branch_id: snapshot_id,
    }).catch(() => {});

    // Mark snapshot as active
    const allSnapshots = await base44.entities.WorldSnapshot.filter({ session_id });
    for (const snap of allSnapshots || []) {
      await base44.entities.WorldSnapshot.update(snap.id, {
        is_active: snap.id === snapshot_id,
      }).catch(() => {});
    }

    return Response.json({
      success: true,
      branch: snapshot.branch_name,
      message: `Restored to "${snapshot.branch_name}" timeline`,
    });
  } catch (error) {
    console.error('World branch restore error:', error);
    return Response.json(
      { error: error.message || 'Failed to restore branch' },
      { status: 500 }
    );
  }
});