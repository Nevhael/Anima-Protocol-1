import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id } = await req.json();
    if (!session_id) {
      return Response.json({ error: 'session_id required' }, { status: 400 });
    }

    // Fetch session data
    const sessions = await base44.entities.ChatSession.filter({ id: session_id }, "-updated_date", 1);
    const session = sessions?.[0];
    
    if (!session || !session.messages) {
      return Response.json({ intensity_timeline: [], hotspots: [] });
    }

    const messages = session.messages || [];
    const intensity_timeline = [];
    let cumulativeScore = 0;

    // Analyze each message for conflict indicators
    messages.forEach((msg, idx) => {
      if (msg.role === 'assistant' || msg.type === 'event') {
        const content = msg.content || '';
        
        // Score conflict intensity (0-100)
        let score = 20; // baseline
        
        // Intensity markers
        if (/\b(conflict|battle|fight|war|attack|danger|threat|death|defeat|betrayal|crisis|disaster|catastrophe)\b/gi.test(content)) {
          score += 30;
        }
        if (/\b(rage|fury|anger|hate|desperate|fear|terror|panic)\b/gi.test(content)) {
          score += 15;
        }
        if (/\b(resolve|triumph|victory|overcome|survive|escape)\b/gi.test(content)) {
          score -= 10;
        }
        if (/\b(peace|calm|serenity|harmony|rest|hope)\b/gi.test(content)) {
          score -= 20;
        }
        if (/\[event:|EVENT:/gi.test(content)) {
          score += 25;
        }

        cumulativeScore = Math.max(0, Math.min(100, cumulativeScore * 0.7 + score * 0.3));
        
        intensity_timeline.push({
          message_index: idx,
          timestamp: msg.timestamp || new Date().toISOString(),
          intensity: Math.round(cumulativeScore),
          character: msg.character_name || 'Narrator',
          preview: content.slice(0, 80),
        });
      }
    });

    // Detect hotspots (significant intensity peaks)
    const hotspots = [];
    for (let i = 1; i < intensity_timeline.length - 1; i++) {
      const prev = intensity_timeline[i - 1].intensity;
      const curr = intensity_timeline[i].intensity;
      const next = intensity_timeline[i + 1].intensity;
      
      // Peak detection: current is higher than neighbors
      const isPeak = curr > prev + 10 && curr > next + 10;
      const isSignificant = curr > 60;
      
      if (isPeak && isSignificant) {
        const msg = messages[intensity_timeline[i].message_index];
        hotspots.push({
          message_index: intensity_timeline[i].message_index,
          intensity: curr,
          timestamp: intensity_timeline[i].timestamp,
          character: intensity_timeline[i].character,
          preview: msg.content.slice(0, 150),
          delta: curr - prev,
        });
      }
    }

    // Sort hotspots by intensity
    hotspots.sort((a, b) => b.intensity - a.intensity);

    return Response.json({
      success: true,
      intensity_timeline,
      hotspots: hotspots.slice(0, 10), // Top 10 hotspots
      total_messages: messages.length,
      average_intensity: Math.round(intensity_timeline.reduce((sum, t) => sum + t.intensity, 0) / intensity_timeline.length),
      peak_intensity: Math.max(...intensity_timeline.map(t => t.intensity)),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});