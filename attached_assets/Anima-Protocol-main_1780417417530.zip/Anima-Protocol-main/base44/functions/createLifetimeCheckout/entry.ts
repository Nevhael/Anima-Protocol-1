import Stripe from 'npm:stripe@16.2.0';
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { priceId, successUrl, cancelUrl } = await req.json();

    if (!priceId || !successUrl || !cancelUrl) {
      return Response.json(
        { error: 'Missing priceId, successUrl, or cancelUrl' },
        { status: 400 }
      );
    }

    // Create checkout session for one-time lifetime purchase
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: successUrl,
      cancel_url: cancelUrl,
      customer_email: user.email,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        user_email: user.email,
        product_type: 'lifetime_access',
      },
    });

    console.log(`[Lifetime Checkout] Session created: ${session.id} for ${user.email}`);

    return Response.json({
      sessionId: session.id,
      checkoutUrl: session.url,
    });
  } catch (error) {
    console.error('[Lifetime Checkout] Error:', error.message);
    return Response.json(
      { error: `Checkout error: ${error.message}` },
      { status: 500 }
    );
  }
});