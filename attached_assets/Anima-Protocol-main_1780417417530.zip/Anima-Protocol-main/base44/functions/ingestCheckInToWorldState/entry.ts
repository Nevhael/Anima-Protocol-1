import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { check_in_id, session_id, character_id } = await req.json();

    // Fetch the check-in
    const checkIn = await base44.entities.CheckIn.list().then(checkins =>
      checkins.find(c => c.id === check_in_id)
    );

    if (!checkIn) {
      return Response.json({ error: 'Check-in not found' }, { status: 404 });
    }

    // Get current character emotional state
    const emotionalStates = await base44.entities.CharacterEmotionalState.filter({
      character_id,
      session_id,
      is_current: true,
    });

    const currentState = emotionalStates?.[0];

    // Update character emotional state based on mood
    const moodIntensityMap = {
      joyful: 9,
      energized: 8,
      focused: 7,
      calm: 5,
      contemplative: 5,
      scattered: 4,
      anxious: 6,
      weary: 3,
    };

    const updatedEmotionalState = {
      character_id,
      session_id,
      primary_emotion: checkIn.mood,
      intensity: moodIntensityMap[checkIn.mood] || 5,
      trigger: `User check-in: ${checkIn.mood}. Focus: ${checkIn.current_focus}`,
      affected_by_actor: 'user_ritual',
      is_current: true,
    };

    if (currentState) {
      await base44.entities.CharacterEmotionalState.update(currentState.id, updatedEmotionalState);
    } else {
      await base44.entities.CharacterEmotionalState.create(updatedEmotionalState);
    }

    // Embed check-in into world state for narrative awareness
    const worldStateEntry = {
      session_id,
      category: 'user_ritual',
      subject: `Daily Check-In: ${checkIn.mood}`,
      fact: `User reported: mood=${checkIn.mood}, focus=${checkIn.current_focus}, revelation=${checkIn.revelation}, notes=${checkIn.freeform_note}`,
      importance: 'notable',
      is_active: true,
    };

    await base44.entities.WorldState.create(worldStateEntry);

    // Mark check-in as processed
    await base44.entities.CheckIn.update(check_in_id, {
      processed: true,
      world_state_impact: {
        emotional_shift: checkIn.mood,
        narrative_hook: `User's current focus on "${checkIn.current_focus}" weaves into the story.`,
        revealed_insight: checkIn.revelation,
      },
    });

    // Optionally trigger daily summary compilation if that function exists
    try {
      await base44.functions.invoke('dailyJournalCompilation', {
        session_id,
        character_id,
        check_in_id,
      });
    } catch (e) {
      // Silent fail if function doesn't exist or errors
      console.log('Daily compilation skipped:', e.message);
    }

    return Response.json({
      success: true,
      check_in_id,
      emotional_state_updated: true,
      world_state_ingested: true,
    });
  } catch (error) {
    console.error('Check-in ingestion error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});