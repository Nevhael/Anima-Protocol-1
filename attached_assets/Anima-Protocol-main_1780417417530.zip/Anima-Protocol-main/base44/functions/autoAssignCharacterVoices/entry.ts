import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get all characters
    const characters = await base44.asServiceRole.entities.Character.list('-created_date', 200);
    
    if (!characters || characters.length === 0) {
      return Response.json({ assigned: 0, skipped: 0, message: 'No characters found' });
    }

    let assigned = 0;
    let skipped = 0;

    // Assign voices to each character
    for (const char of characters) {
      // Skip if already has a voice assigned
      if (char.elevenlabs_voice_id) {
        skipped++;
        continue;
      }

      try {
        // Call assignCharacterVoices for this character
        const voiceRes = await base44.asServiceRole.functions.invoke('assignCharacterVoices', {
          character_id: char.id,
          character_name: char.name,
          personality: char.personality || '',
          universe: char.universe || '',
        });

        if (voiceRes?.data?.voice_id) {
          // Update character with the assigned voice
          await base44.asServiceRole.entities.Character.update(char.id, {
            elevenlabs_voice_id: voiceRes.data.voice_id,
          });
          assigned++;
        }
      } catch (err) {
        console.error(`Error assigning voice to ${char.name}:`, err);
        skipped++;
      }
    }

    return Response.json({
      assigned,
      skipped,
      total: characters.length,
      message: `Voice profiles assigned to ${assigned} characters`,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});