import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get today's date range (midnight to midnight)
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
    const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);

    // Fetch all sessions updated today
    const allSessions = await base44.asServiceRole.entities.ChatSession.list('-updated_date', 500);
    const todaySessions = (allSessions || []).filter(session => {
      if (!session.updated_date) return false;
      const sessionDate = new Date(session.updated_date);
      return sessionDate >= todayStart && sessionDate <= todayEnd;
    });

    if (todaySessions.length === 0) {
      return Response.json({
        success: true,
        message: 'No sessions found for today',
        compiled_entry: null,
        reflections: {},
        emotional_progression: {},
        sessions_processed: 0,
      });
    }

    // Collect all characters involved across sessions
    const characterMap = new Map();
    const sessionDetails = [];

    todaySessions.forEach(session => {
      const charIds = session.mode === 'solo'
        ? [session.character_id]
        : (session.group_character_ids || []);

      charIds.forEach(charId => {
        if (!characterMap.has(charId)) {
          characterMap.set(charId, []);
        }
        characterMap.get(charId).push({
          sessionId: session.id,
          title: session.title,
          messageCount: (session.messages || []).length,
          lastMessage: session.last_message,
        });
      });

      sessionDetails.push({
        id: session.id,
        title: session.title,
        messages: session.messages || [],
        characters: charIds,
      });
    });

    // Generate thematic story recap using LLM
    const sessionSummaries = sessionDetails.map(s =>
      `[${s.title}]: ${s.messages.slice(-3).map(m => m.content).join(' ')}`
    ).join('\n\n');

    const recapPrompt = `Analyze these story sessions from today and generate a single thematic story recap that captures:
1. Overall narrative arc and major turning points
2. Character development patterns
3. Emotional climax or resolution
4. Lingering tensions or unresolved threads

Sessions from today:
${sessionSummaries}

Write a vivid, literary story recap (3-4 sentences) that weaves together all sessions into a cohesive daily narrative.`;

    const recapResult = await base44.integrations.Core.InvokeLLM({ prompt: recapPrompt });
    const thematicRecap = typeof recapResult === 'string' ? recapResult : recapResult.data || '';

    // Track emotional progression across the day
    const emotionalProgression = {};
    const reflections = {};

    // Generate and save journal entries for each character
    const journalEntries = [];

    for (const [charId, sessions] of characterMap.entries()) {
      try {
        // Get character details
        const character = await base44.asServiceRole.entities.Character.list('-created_date', 1);
        const char = character.find(c => c.id === charId);
        if (!char) continue;

        // Get all messages from character's sessions today
        const charMessages = sessionDetails
          .filter(s => s.characters.includes(charId))
          .flatMap(s => s.messages || []);

        // Generate character-specific journal entry
        const journalPrompt = `Create a first-person journal entry for ${char.name} reflecting on today's events:

Sessions:
${sessionDetails
  .filter(s => s.characters.includes(charId))
  .map(s => `[${s.title}]: ${s.messages.slice(-2).map(m => m.content).join(' ')}`)
  .join('\n\n')}

Write an introspective, emotional journal entry (200-300 words) that captures:
1. Key emotional moments and reactions
2. Character development or realization
3. Relationships and how they shifted
4. Personal goals or doubts

Make it intimate and authentic to the character's voice.`;

        const journalResult = await base44.integrations.Core.InvokeLLM({ prompt: journalPrompt });
        const journalText = typeof journalResult === 'string' ? journalResult : journalResult.data || '';

        // Analyze emotional tone
        const emotionPrompt = `Analyze ${char.name}'s emotional journey across these sessions today. Respond in JSON format only:
{
  "primary_emotion": "the most dominant emotion",
  "emotional_arc": "how their emotional state changed (e.g., hopeful → anxious → determined)",
  "intensity_peak": 1-10,
  "key_insight": "one sentence about their growth or realization"
}

Sessions: ${charMessages.slice(-5).map(m => m.content).join(' ')}`;

        const emotionResult = await base44.integrations.Core.InvokeLLM({ prompt: emotionPrompt });
        let emotionData = { primary_emotion: 'neutral', emotional_arc: 'stable', intensity_peak: 5, key_insight: 'A day of reflection.' };

        try {
          const parsed = typeof emotionResult === 'object' ? emotionResult : JSON.parse(emotionResult);
          emotionData = { ...emotionData, ...parsed };
        } catch (e) {
          // Keep defaults
        }

        emotionalProgression[char.name] = emotionData;
        reflections[char.name] = journalText;

        // Save as CharacterJournal entry
        await base44.asServiceRole.entities.CharacterJournal.create({
          character_id: charId,
          session_id: sessionDetails[0]?.id || null,
          perspective: 'first_person',
          title: `Daily Reflections - ${new Date().toLocaleDateString()}`,
          content: journalText,
          emotional_tone: emotionData.primary_emotion,
          key_moments: sessions.map(s => s.title),
          character_insights: emotionData.key_insight,
          relationships_affected: [],
        });

        journalEntries.push({
          characterId: charId,
          characterName: char.name,
          journalSaved: true,
        });
      } catch (err) {
        console.error(`Error processing character ${charId}:`, err);
        journalEntries.push({
          characterId: charId,
          error: err.message,
          journalSaved: false,
        });
      }
    }

    return Response.json({
      success: true,
      message: 'Daily journal compilation completed',
      compiled_entry: thematicRecap,
      reflections,
      emotional_progression: emotionalProgression,
      sessions_processed: todaySessions.length,
      characters_processed: journalEntries.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Daily compilation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});