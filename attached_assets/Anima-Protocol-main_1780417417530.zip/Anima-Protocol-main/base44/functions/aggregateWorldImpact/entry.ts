import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, recent_messages, character_emotions, relationships, lore_entries } = await req.json();

    if (!session_id || !recent_messages || recent_messages.length === 0) {
      return Response.json({ error: 'Missing required data' }, { status: 400 });
    }

    // Extract decision points from recent messages
    const decisions = extractDecisions(recent_messages);

    // Analyze ripple effects through relationships
    const rippleEffects = analyzeRippleEffects(decisions, relationships, character_emotions);

    // Generate world impact summary
    const impactSummary = generateImpactSummary(decisions, rippleEffects);

    // Create headlines that connect character actions to world state
    const headlines = await generateImpactHeadlines(
      decisions,
      rippleEffects,
      impactSummary,
      base44
    );

    // Track world state changes
    const worldStateChanges = identifyWorldStateChanges(
      decisions,
      rippleEffects,
      lore_entries || []
    );

    return Response.json({
      decisions: decisions.slice(0, 5),
      ripple_effects: rippleEffects.slice(0, 8),
      headlines: headlines.slice(0, 5),
      impact_summary: impactSummary,
      world_state_changes: worldStateChanges.slice(0, 4),
      affected_entities: aggregateAffectedEntities(rippleEffects),
    });
  } catch (error) {
    console.error('World impact aggregation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function extractDecisions(messages) {
  const decisions = [];
  const decisionPatterns = [
    /(?:decided|choose|chose to|went to|attacked|helped|refused|agreed to|betrayed)\s+([^.!?]+)/gi,
    /\*([^*]+)\*.*(?:caused|triggered|led to|changed)/gi,
    /\[(?:ACTION|EVENT|DECISION):\s*([^\]]+)\]/gi,
  ];

  messages.slice(-10).forEach((msg, idx) => {
    if (msg.role === 'assistant' && msg.character_name) {
      let decisionText = '';
      for (const pattern of decisionPatterns) {
        const match = msg.content.match(pattern);
        if (match) {
          decisionText = match[0];
          break;
        }
      }

      if (decisionText) {
        decisions.push({
          character_name: msg.character_name,
          decision: decisionText.substring(0, 100),
          message_index: idx,
          timestamp: msg.timestamp,
          impact_radius: calculateImpactRadius(decisionText),
          type: categorizeDecision(decisionText),
        });
      }
    }
  });

  return decisions;
}

function analyzeRippleEffects(decisions, relationships, character_emotions) {
  const effects = [];

  decisions.forEach((decision) => {
    // Direct effect on the deciding character
    effects.push({
      source_character: decision.character_name,
      effect_type: 'self_consequence',
      description: `${decision.character_name}'s decision to ${decision.decision}`,
      intensity: 5,
      affected_entities: [decision.character_name],
    });

    // Secondary effects on related characters
    Object.entries(relationships || {}).forEach(([charId, rel]) => {
      if (rel.score !== undefined && Math.abs(rel.delta || 0) > 5) {
        const direction = rel.delta > 0 ? 'strengthened' : 'strained';
        effects.push({
          source_character: decision.character_name,
          target_character: charId,
          effect_type: 'relationship_shift',
          description: `${decision.character_name}'s action ${direction} their bond with ${charId}`,
          intensity: Math.min(10, Math.abs(rel.delta || 0) / 5),
          score_delta: rel.delta,
          affected_entities: [decision.character_name, charId],
        });
      }
    });

    // Tertiary effects through emotional climate
    Object.entries(character_emotions || {}).forEach(([charId, emotion]) => {
      if (emotion.intensity > 6) {
        effects.push({
          source_character: decision.character_name,
          target_character: charId,
          effect_type: 'emotional_contagion',
          description: `${decision.character_name}'s decision escalated tensions; ${charId} is now ${emotion.emotion}`,
          intensity: emotion.intensity / 10,
          affected_entities: [decision.character_name, charId],
        });
      }
    });
  });

  return effects;
}

function generateImpactSummary(decisions, rippleEffects) {
  const totalAffected = new Set(rippleEffects.flatMap(e => e.affected_entities)).size;
  const avgIntensity =
    rippleEffects.length > 0
      ? rippleEffects.reduce((sum, e) => sum + e.intensity, 0) / rippleEffects.length
      : 0;

  const effectTypes = {};
  rippleEffects.forEach(e => {
    effectTypes[e.effect_type] = (effectTypes[e.effect_type] || 0) + 1;
  });

  return {
    total_decisions: decisions.length,
    total_ripple_effects: rippleEffects.length,
    entities_affected: totalAffected,
    average_intensity: avgIntensity.toFixed(2),
    effect_breakdown: effectTypes,
    world_stability: calculateWorldStability(rippleEffects),
  };
}

async function generateImpactHeadlines(decisions, rippleEffects, impactSummary, base44) {
  const headlines = [];

  // Major decision headlines
  for (const decision of decisions.slice(0, 3)) {
    const relatedEffects = rippleEffects.filter(e =>
      e.affected_entities.includes(decision.character_name)
    );

    const prompt = `Create a dramatic world headline (one sentence, max 15 words) about this character's decision and its ripple effects:

Character: ${decision.character_name}
Decision: ${decision.decision}
Related Effects: ${relatedEffects.length} cascading consequences
Impact Type: ${decision.type}

Format: "HEADLINE TEXT" (no quotes in output)`;

    try {
      const result = await base44.integrations.Core.InvokeLLM({ prompt });
      headlines.push({
        text: result.trim(),
        source_character: decision.character_name,
        impact_level: relatedEffects.length > 3 ? 'major' : 'moderate',
        affected_count: relatedEffects.length,
        timestamp: decision.timestamp,
      });
    } catch (e) {
      console.error('Headline generation failed:', e);
    }
  }

  return headlines;
}

function identifyWorldStateChanges(decisions, rippleEffects, loreEntries) {
  const changes = [];

  // Political shifts
  const politicalEffects = rippleEffects.filter(e => e.effect_type === 'relationship_shift');
  if (politicalEffects.length > 0) {
    changes.push({
      category: 'political',
      description: `${politicalEffects.length} alliance(s) shifted`,
      intensity: Math.min(10, politicalEffects.length),
    });
  }

  // Emotional climate shifts
  const emotionalEffects = rippleEffects.filter(e => e.effect_type === 'emotional_contagion');
  if (emotionalEffects.length > 0) {
    changes.push({
      category: 'emotional_climate',
      description: `Emotional intensity increased across ${new Set(emotionalEffects.map(e => e.target_character)).size} characters`,
      intensity: emotionalEffects.reduce((sum, e) => sum + e.intensity, 0) / emotionalEffects.length,
    });
  }

  // Lore impacts
  if (loreEntries?.length > 0) {
    const affectedLore = loreEntries.filter(l =>
      decisions.some(d => l.subject?.includes(d.character_name))
    );
    if (affectedLore.length > 0) {
      changes.push({
        category: 'established_lore',
        description: `${affectedLore.length} established fact(s) now relevant`,
        affected_entries: affectedLore.map(l => l.subject),
      });
    }
  }

  return changes;
}

function calculateWorldStability(rippleEffects) {
  const negativeEffects = rippleEffects.filter(
    e => e.intensity > 5 || e.effect_type === 'emotional_contagion'
  ).length;
  const stabilityScore = Math.max(0, 100 - negativeEffects * 15);
  return {
    score: stabilityScore,
    status: stabilityScore > 70 ? 'stable' : stabilityScore > 40 ? 'tense' : 'chaotic',
  };
}

function aggregateAffectedEntities(rippleEffects) {
  const entities = {};
  rippleEffects.forEach(effect => {
    effect.affected_entities?.forEach(entity => {
      if (!entities[entity]) {
        entities[entity] = { name: entity, effects: 0, intensity: 0 };
      }
      entities[entity].effects++;
      entities[entity].intensity += effect.intensity;
    });
  });

  return Object.values(entities).sort((a, b) => b.effects - a.effects);
}

function calculateImpactRadius(decisionText) {
  const keywords = {
    5: /(betray|kill|destroy|war|alliance)/i,
    4: /(help|support|agree|challenge|confront)/i,
    3: /(speak|suggest|think|believe)/i,
    2: /(small|minor|slight)/i,
  };

  for (const [radius, pattern] of Object.entries(keywords)) {
    if (pattern.test(decisionText)) return parseInt(radius);
  }
  return 1;
}

function categorizeDecision(decisionText) {
  if (/(betray|fight|attack|refuse|deny)/i.test(decisionText)) return 'conflict';
  if (/(help|support|agree|follow)/i.test(decisionText)) return 'alliance';
  if (/(reveal|discover|learn|realize)/i.test(decisionText)) return 'revelation';
  if (/(sacrifice|give|offer|surrender)/i.test(decisionText)) return 'sacrifice';
  return 'action';
}