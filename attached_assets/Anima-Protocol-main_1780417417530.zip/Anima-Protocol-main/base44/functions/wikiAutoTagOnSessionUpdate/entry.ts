import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Triggered by entity automation when a ChatSession is updated
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    const sessionId = payload?.event?.entity_id;
    const sessionData = payload?.data;

    if (!sessionId || !sessionData?.messages?.length) {
      return Response.json({ skipped: true });
    }

    // Only tag if there are enough messages
    if (sessionData.messages.length < 6) {
      return Response.json({ skipped: true, reason: 'too few messages' });
    }

    // Throttle: only process every ~10 messages (check if count is a multiple of 10)
    const count = sessionData.messages.length;
    if (count % 10 !== 0) {
      return Response.json({ skipped: true, reason: 'throttled' });
    }

    const result = await base44.asServiceRole.functions.invoke('autoTagWikiEntities', {
      session_id: sessionId,
      messages: sessionData.messages,
    });

    console.log(`Wiki auto-tag via automation: session ${sessionId}`, result?.data);
    return Response.json({ success: true, result: result?.data });
  } catch (error) {
    console.error('wikiAutoTagOnSessionUpdate error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});