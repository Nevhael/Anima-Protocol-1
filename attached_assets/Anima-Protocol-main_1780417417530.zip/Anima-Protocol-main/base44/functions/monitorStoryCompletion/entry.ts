import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { storypoint_id, session_id } = await req.json();

    if (!storypoint_id || !session_id) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Fetch the storypoint and session
    const storypoints = await base44.asServiceRole.entities.Storypoint.filter({ id: storypoint_id });
    const storypoint = storypoints?.[0];

    if (!storypoint) {
      return Response.json({ error: 'Storypoint not found' }, { status: 404 });
    }

    const sessions = await base44.asServiceRole.entities.ChatSession.filter({ id: session_id });
    const session = sessions?.[0];

    if (!session) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    // Get character emotions and recent lore for context
    const [emotions, lore] = await Promise.all([
      base44.asServiceRole.entities.CharacterEmotionalState.filter(
        { session_id, is_current: true },
        '-created_date',
        20
      ),
      base44.asServiceRole.entities.WorldState.filter(
        { session_id, is_active: true },
        '-created_date',
        10
      ),
    ]);

    // Build context for LLM
    const emotionSummary = emotions
      .map(e => `${e.character_id}: ${e.primary_emotion} (intensity: ${e.intensity})`)
      .join(', ');

    const loreSummary = lore
      .slice(0, 5)
      .map(l => `[${l.category}] ${l.subject}: ${l.fact}`)
      .join('\n');

    const prompt = `You are analyzing a completed story scene and need to suggest 2-3 follow-up narrative events.

Scene Summary: ${storypoint.summary}

Current Character Emotions: ${emotionSummary || 'None tracked'}

Recent Story Facts: ${loreSummary || 'None recorded'}

Generate follow-up narrative event suggestions that:
1. Build on the emotional states and lore established
2. Create natural progression for character development
3. Are specific and actionable (not generic)

Format as JSON array with objects containing: title, description, trigger_condition, impact_scale`;

    // Generate follow-up suggestions
    const suggestions = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          events: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                description: { type: 'string' },
                trigger_condition: { type: 'string' },
                impact_scale: { type: 'string', enum: ['minor', 'moderate', 'major'] },
              },
            },
          },
        },
      },
    });

    // Update character memories based on scene
    const characters = storypoint.characters_involved || [];
    const memoryUpdates = [];

    for (const charId of characters) {
      const memoryPrompt = `Based on this story beat: "${storypoint.summary}"
      
Generate 1-2 key memories or insights this character would retain. Be concise and character-specific.`;

      const memory = await base44.integrations.Core.InvokeLLM({ prompt: memoryPrompt });

      if (memory && memory.trim()) {
        memoryUpdates.push({
          character_id: charId,
          fact: memory,
          category: 'event',
          tags: ['scene_completion', 'auto_generated'],
        });
      }
    }

    // Batch create character memories
    if (memoryUpdates.length > 0) {
      await Promise.all(
        memoryUpdates.map(update =>
          base44.asServiceRole.entities.CharacterMemory.create(update)
        )
      );
    }

    // Update storypoint with generated suggestions metadata
    await base44.asServiceRole.entities.Storypoint.update(storypoint_id, {
      follow_up_suggestions: suggestions.events || [],
      last_analyzed_at: new Date().toISOString(),
    });

    return Response.json({
      success: true,
      suggestions: suggestions.events || [],
      memories_created: memoryUpdates.length,
    });
  } catch (error) {
    console.error('Error monitoring story completion:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});