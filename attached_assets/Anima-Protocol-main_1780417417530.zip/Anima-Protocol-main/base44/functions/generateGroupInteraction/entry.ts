import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      characters,
      relationships,
      character_emotions,
      recent_messages,
      session_context,
      last_speaker_id,
    } = await req.json();

    if (!characters || characters.length < 2) {
      return Response.json({ error: 'Need at least 2 characters' }, { status: 400 });
    }

    // Filter out last speaker to pick someone else
    const potentialSpeakers = characters.filter(c => c.id !== last_speaker_id);
    if (potentialSpeakers.length === 0) {
      return Response.json({ interactions: [] });
    }

    // Pick primary speaker (weighted by relationship strength with others)
    const speaker = potentialSpeakers[Math.floor(Math.random() * potentialSpeakers.length)];

    // Build relationship context for speaker
    const speakerRelationships = characters
      .filter(c => c.id !== speaker.id)
      .map(c => {
        const rel = relationships[speaker.id]?.[c.id];
        return `${c.name}: ${rel ? `tier ${rel.tier} (score ${rel.score}/100)` : 'unknown'}`;
      })
      .join(', ');

    // Get speaker's current emotional state
    const speakerEmotion = character_emotions[speaker.id];
    const emotionContext = speakerEmotion
      ? `Currently feeling ${speakerEmotion.emotion} (intensity ${speakerEmotion.intensity}/10). ${speakerEmotion.trigger ? `Triggered by: ${speakerEmotion.trigger}` : ''}`
      : 'Neutral mood';

    // Build context of other characters
    const otherCharacterContext = characters
      .filter(c => c.id !== speaker.id)
      .map(c => {
        const emotion = character_emotions[c.id];
        const emotionalState = emotion ? `${emotion.emotion} (${emotion.intensity}/10)` : 'unknown';
        return `${c.name} (${emotionalState}): ${c.personality || 'mysterious'}`;
      })
      .join('\n');

    // Recent conversation summary
    const conversationSummary = recent_messages
      .slice(-4)
      .map(m => `${m.character_name}: ${m.content.substring(0, 100)}`)
      .join('\n');

    const prompt = `You are orchestrating a group scene where multiple characters interact dynamically.

SPEAKER: ${speaker.name}
${speaker.personality ? `Personality: ${speaker.personality}` : ''}
${speaker.speaking_style ? `Speaking style: ${speaker.speaking_style}` : ''}
${speaker.backstory ? `Background: ${speaker.backstory}` : ''}

EMOTIONAL STATE: ${emotionContext}

RELATIONSHIPS WITH OTHERS:
${speakerRelationships}

OTHER CHARACTERS IN SCENE:
${otherCharacterContext}

RECENT CONVERSATION:
${conversationSummary}

${session_context ? `SESSION CONTEXT: ${session_context}` : ''}

Generate ${speaker.name}'s AUTHENTIC next action or dialogue. This character should:
- React to the current emotional and social dynamics
- Consider their relationship tiers and be influenced by them
- Stay true to their personality and speaking style
- Potentially address or interact with specific other characters based on relationship strength
- Show emotional authenticity based on their current state

Format: [CHARACTER_NAME]: dialogue or action

Make it natural, brief, and character-driven—NOT generic. Show personality and relationship awareness.`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });

    // Parse the response to extract character name and content
    const match = result.match(/\[(.+?)\]:\s*(.+)/s);
    
    if (!match) {
      return Response.json({
        interactions: [{
          character_id: speaker.id,
          character_name: speaker.name,
          content: result.replace(/\[.+?\]:\s*/, '').trim(),
          triggered_by: 'group_dynamics',
        }],
      });
    }

    const [, charName, content] = match;

    return Response.json({
      interactions: [{
        character_id: speaker.id,
        character_name: charName.trim(),
        content: content.trim(),
        triggered_by: 'group_dynamics',
      }],
    });
  } catch (error) {
    console.error('Group interaction error:', error);
    return Response.json(
      { error: error.message || 'Failed to generate group interaction' },
      { status: 500 }
    );
  }
});