import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, days_passed = 1, force_season = null } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    // Fetch or create calendar
    const calendars = await base44.asServiceRole.entities.Calendar.list('-created_date', 100);
    let calendar = calendars.find((c) => c.session_id === session_id);

    if (!calendar) {
      // Create new calendar for session
      calendar = await base44.asServiceRole.entities.Calendar.create({
        session_id,
        current_day: 1,
        current_season: 'spring',
        day_of_season: 1,
        year: 1,
        weather: 'clear',
        time_of_day: 'morning',
        world_events: [],
        holidays: [],
        character_birthdays: [],
      });
    }

    // Calculate new day
    let newDay = calendar.current_day + days_passed;
    let newYear = calendar.year;

    if (newDay > 365) {
      newYear += Math.floor(newDay / 365);
      newDay = newDay % 365 || 365;
    }

    // Determine season
    const getSeasonFromDay = (day) => {
      if (day <= 91) return 'spring';
      if (day <= 182) return 'summer';
      if (day <= 273) return 'autumn';
      return 'winter';
    };

    const getDayOfSeason = (day) => {
      const season = getSeasonFromDay(day);
      const seasonStarts = { spring: 1, summer: 92, autumn: 183, winter: 274 };
      return day - seasonStarts[season] + 1;
    };

    const newSeason = force_season || getSeasonFromDay(newDay);
    const newDayOfSeason = getDayOfSeason(newDay);
    const seasonProgression = newDayOfSeason / 91;

    // Generate weather based on season
    const getWeatherForSeason = (season) => {
      const seasonWeather = {
        spring: ['clear', 'cloudy', 'rainy'],
        summer: ['clear', 'cloudy', 'stormy'],
        autumn: ['cloudy', 'rainy', 'foggy'],
        winter: ['snowy', 'cloudy', 'foggy'],
      };
      const options = seasonWeather[season];
      return options[Math.floor(Math.random() * options.length)];
    };

    const newWeather = getWeatherForSeason(newSeason);

    // Get time of day (cycles every 12 hours in-game)
    const timeOfDayList = ['dawn', 'morning', 'midday', 'afternoon', 'evening', 'dusk', 'night', 'night'];
    const newTimeOfDay = timeOfDayList[Math.floor((newDay % 7) * (8 / 7))];

    // Check for holidays and character birthdays
    const todayEvents = (calendar.holidays || []).filter((h) => h.date === newDay);
    const todayBirthdays = (calendar.character_birthdays || []).filter((b) => b.birth_date === newDay);
    const scheduledEvents = (calendar.world_events || []).filter((e) => {
      if (e.is_recurring) return e.date === newDay;
      return e.date === newDay;
    });

    const updatedCalendar = await base44.asServiceRole.entities.Calendar.update(calendar.id, {
      current_day: newDay,
      current_season: newSeason,
      day_of_season: newDayOfSeason,
      year: newYear,
      season_progression: seasonProgression,
      weather: newWeather,
      time_of_day: newTimeOfDay,
      last_updated: new Date().toISOString(),
    });

    // Build context about today's events
    let eventContext = '';
    if (todayEvents.length > 0) {
      const eventNames = todayEvents.map((e) => e.name).join(', ');
      eventContext += `\n[CALENDAR: Today is ${eventNames}]`;
    }
    if (todayBirthdays.length > 0) {
      const birthdayNames = todayBirthdays.map((b) => `${b.character_name}'s birthday`).join(', ');
      eventContext += `\n[BIRTHDAYS: ${birthdayNames}]`;
    }
    if (scheduledEvents.length > 0) {
      const eventNames = scheduledEvents.map((e) => e.name).join(', ');
      eventContext += `\n[WORLD EVENTS: ${eventNames}]`;
    }

    return Response.json({
      calendar: updatedCalendar,
      event_context: eventContext,
      special_dates: {
        holidays: todayEvents,
        birthdays: todayBirthdays,
        events: scheduledEvents,
      },
    });
  } catch (error) {
    console.error('Calendar update error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});