import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    let { session_id } = {};
    try {
      const body = await req.json();
      session_id = body?.session_id;
    } catch {
      // If no JSON body, that's ok - we'll fetch active sessions
    }

    // Fetch all active sessions
    const sessions = await base44.asServiceRole.entities.ChatSession.list('-updated_date', 100);
    
    // If no session_id provided, find the most recently updated session with messages
    if (!session_id) {
      const activeSession = sessions.find(s => s.messages?.length > 0);
      if (!activeSession) {
        return Response.json({ 
          success: false,
          message: 'No active sessions found to evolve' 
        });
      }
      session_id = activeSession.id;
    }

    const currentSession = sessions.find(s => s.id === session_id);

    if (!currentSession || !currentSession.messages?.length) {
      return Response.json({ error: 'Session not found or empty' }, { status: 404 });
    }

    // Fetch current world state
    const worldState = await base44.asServiceRole.entities.WorldState.filter(
      { session_id, is_active: true },
      '-created_date',
      100
    );

    // Fetch locations to modify descriptions
    const locations = await base44.asServiceRole.entities.Location.list('-created_date', 100);

    // Fetch character relationships to detect major shifts
    const relationships = await base44.asServiceRole.entities.CharacterRelationship.filter(
      { session_id },
      '-created_date',
      100
    );

    // Analyze recent conversation for significant choices/events
    const recentMessages = currentSession.messages.slice(-20);
    const conversationText = recentMessages
      .map(m => `${m.character_name}: ${m.content}`)
      .join('\n');

    // Use LLM to detect world-changing decisions
    const analysisResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Analyze this narrative for world-changing events or significant character choices that should have persistent consequences:

${conversationText}

Identify:
1. Major plot developments (betrayals, alliances, discoveries)
2. Significant character actions that affect the world
3. Environmental/location changes mentioned
4. Relationship shifts that should ripple through the world

Respond with JSON:
{
  "world_events": [{"title": "", "description": "", "affected_locations": [], "persistence_level": "minor|moderate|major"}],
  "environmental_changes": [{"location": "", "change": "", "reason": ""}],
  "relationship_consequences": [{"characters": [], "consequence": "", "world_impact": ""}],
  "should_create_event": boolean
}`,
      response_json_schema: {
        type: "object",
        properties: {
          world_events: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                affected_locations: { type: "array", items: { type: "string" } },
                persistence_level: { type: "string" }
              }
            }
          },
          environmental_changes: {
            type: "array",
            items: {
              type: "object",
              properties: {
                location: { type: "string" },
                change: { type: "string" },
                reason: { type: "string" }
              }
            }
          },
          relationship_consequences: {
            type: "array",
            items: {
              type: "object",
              properties: {
                characters: { type: "array", items: { type: "string" } },
                consequence: { type: "string" },
                world_impact: { type: "string" }
              }
            }
          },
          should_create_event: { type: "boolean" }
        }
      }
    });

    const analysis = analysisResult;
    let createdCount = 0;

    // Store world events as persistent lore
    if (analysis.world_events && analysis.world_events.length > 0) {
      for (const event of analysis.world_events) {
        await base44.asServiceRole.entities.WorldState.create({
          session_id,
          category: 'event',
          subject: event.title,
          fact: event.description,
          importance: event.persistence_level === 'major' ? 'critical' : event.persistence_level === 'moderate' ? 'high' : 'medium',
          is_active: true,
          source_message_index: currentSession.messages.length - 1
        });
        createdCount++;
      }
    }

    // Update location descriptions with environmental changes
    if (analysis.environmental_changes && analysis.environmental_changes.length > 0) {
      for (const change of analysis.environmental_changes) {
        const location = locations.find(l => l.name.toLowerCase().includes(change.location.toLowerCase()));
        if (location) {
          const updatedDesc = `${location.description}\n\n[EVOLVED]: ${change.change}`;
          await base44.asServiceRole.entities.Location.update(location.id, {
            description: updatedDesc
          });
        }
      }
    }

    // Store relationship consequences as lore
    if (analysis.relationship_consequences && analysis.relationship_consequences.length > 0) {
      for (const consequence of analysis.relationship_consequences) {
        await base44.asServiceRole.entities.WorldState.create({
          session_id,
          category: 'relationship',
          subject: consequence.characters.join(' & '),
          fact: `${consequence.consequence} - World Impact: ${consequence.world_impact}`,
          importance: 'high',
          is_active: true,
          source_message_index: currentSession.messages.length - 1
        });
        createdCount++;
      }
    }

    return Response.json({
      success: true,
      world_events_created: createdCount,
      analysis_details: {
        events: analysis.world_events?.length || 0,
        env_changes: analysis.environmental_changes?.length || 0,
        rel_consequences: analysis.relationship_consequences?.length || 0
      }
    });
  } catch (error) {
    console.error('World evolution error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});