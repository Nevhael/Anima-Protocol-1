import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id } = await req.json();

    const [emotionalStates, relationships, messages, conflictRes] = await Promise.all([
      base44.entities.CharacterEmotionalState.filter({ session_id }, "-created_date", 500),
      base44.entities.CharacterRelationship.filter({ session_id }, "-created_date", 100),
      base44.entities.ChatSession.filter({ id: session_id }),
      base44.functions.invoke("analyzeConflictIntensity", { session_id }),
    ]);

    const session = messages?.[0];
    const sessionMessages = session?.messages || [];
    const conflictIntensity = conflictRes?.data?.intensity || 0;
    const conflictSpikes = conflictRes?.data?.spikes || [];

    // Group emotional states by character and timeline
    const emotionalTimelines = {};
    const contagionEvents = [];

    (emotionalStates || []).forEach(state => {
      if (!emotionalTimelines[state.character_id]) {
        emotionalTimelines[state.character_id] = [];
      }
      emotionalTimelines[state.character_id].push({
        timestamp: state.created_date,
        emotion: state.primary_emotion,
        intensity: state.intensity,
        secondary: state.secondary_emotion,
        trigger: state.trigger,
      });
    });

    // Detect emotional contagion (when one character's emotional shift causes others to shift)
    Object.entries(emotionalTimelines).forEach(([charId, timeline]) => {
      timeline.forEach((state, idx) => {
        if (idx > 0) {
          const prevState = timeline[idx - 1];
          // Check if emotion changed significantly
          if (state.emotion !== prevState.emotion && state.intensity > 6) {
            // Look for related character shifts within 2 states
            Object.entries(emotionalTimelines).forEach(([otherId, otherTimeline]) => {
              if (otherId !== charId) {
                const relatedShift = otherTimeline.find(os =>
                  Math.abs(new Date(os.timestamp) - new Date(state.timestamp)) < 5000
                );
                if (relatedShift && relatedShift.emotion === state.emotion) {
                  contagionEvents.push({
                    sourceCharacterId: charId,
                    targetCharacterId: otherId,
                    emotion: state.emotion,
                    intensity: Math.max(state.intensity, relatedShift.intensity),
                    timestamp: state.timestamp,
                  });
                }
              }
            });
          }
        }
      });
    });

    // Create sparkline data (max 52 data points for compact visualization)
    const sparklineData = {};
    Object.entries(emotionalTimelines).forEach(([charId, timeline]) => {
      if (timeline.length > 52) {
        // Compress to 52 buckets
        const compressed = [];
        const bucketSize = Math.ceil(timeline.length / 52);
        for (let i = 0; i < timeline.length; i += bucketSize) {
          const bucket = timeline.slice(i, i + bucketSize);
          const avgIntensity = bucket.reduce((sum, s) => sum + s.intensity, 0) / bucket.length;
          compressed.push({
            timestamp: bucket[0].timestamp,
            intensity: Math.round(avgIntensity),
            emotion: bucket[bucket.length - 1].emotion,
          });
        }
        sparklineData[charId] = compressed;
      } else {
        sparklineData[charId] = timeline.map(t => ({
          timestamp: t.timestamp,
          intensity: t.intensity,
          emotion: t.emotion,
        }));
      }
    });

    // Correlate emotional peaks with conflict spikes
    const correlations = [];
    Object.entries(sparklineData).forEach(([charId, data]) => {
      data.forEach(point => {
        const nearbySpike = conflictSpikes?.find(spike =>
          Math.abs(new Date(point.timestamp) - new Date(spike.timestamp)) < 10000
        );
        if (nearbySpike && point.intensity > 7) {
          correlations.push({
            characterId: charId,
            emotionalIntensity: point.intensity,
            emotion: point.emotion,
            conflictIntensity: nearbySpike.intensity,
            timestamp: point.timestamp,
          });
        }
      });
    });

    return Response.json({
      sparklineData,
      contagionEvents,
      correlations,
      conflictSpikes,
      overallConflictIntensity: conflictIntensity,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});