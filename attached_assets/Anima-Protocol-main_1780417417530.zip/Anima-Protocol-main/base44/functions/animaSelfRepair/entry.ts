import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { anima_id, repair_type = 'full' } = await req.json();

    if (!anima_id) {
      return Response.json({ error: 'anima_id required' }, { status: 400 });
    }

    const results = {
      timestamp: new Date().toISOString(),
      anima_id,
      repairs_completed: [],
      issues_found: [],
      health_score: 100,
    };

    // 1. Memory Recovery - check for corrupted cross-session memories
    if (repair_type === 'full' || repair_type === 'memory') {
      const memoryRepair = await repairMemories(base44, anima_id);
      results.repairs_completed.push('memory_recovery');
      results.issues_found.push(...memoryRepair.issues);
      results.memory_repair = memoryRepair;
    }

    // 2. State Reset - clear stuck emotional/conversation states
    if (repair_type === 'full' || repair_type === 'state') {
      const stateRepair = await repairStates(base44, anima_id);
      results.repairs_completed.push('state_reset');
      results.issues_found.push(...stateRepair.issues);
      results.state_repair = stateRepair;
    }

    // 3. Error Handling - validate recent interactions for errors
    if (repair_type === 'full' || repair_type === 'interactions') {
      const interactionRepair = await validateInteractions(base44, anima_id);
      results.repairs_completed.push('interaction_validation');
      results.issues_found.push(...interactionRepair.issues);
      results.interaction_repair = interactionRepair;
    }

    // 4. Health Check - diagnostic scan
    if (repair_type === 'full' || repair_type === 'health') {
      const healthCheck = await performHealthCheck(base44, anima_id);
      results.repairs_completed.push('health_check');
      results.issues_found.push(...healthCheck.issues);
      results.health_score = healthCheck.score;
      results.health_check = healthCheck;
    }

    // 5. Database Repair - data consistency checks
    if (repair_type === 'full' || repair_type === 'database') {
      const dbRepair = await repairDatabase(base44, anima_id);
      results.repairs_completed.push('database_repair');
      results.issues_found.push(...dbRepair.issues);
      results.database_repair = dbRepair;
    }

    // Mark anima as repaired
    await base44.entities.Anima.update(anima_id, {
      last_repair: new Date().toISOString(),
      repair_status: 'healthy',
    }).catch(() => {});

    return Response.json({
      success: true,
      results,
      summary: `Self-repair complete: ${results.repairs_completed.length} systems checked, ${results.issues_found.length} issues resolved`,
    });
  } catch (error) {
    console.error('Anima self-repair error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function repairMemories(base44, animaId) {
  const issues = [];
  let repaired = 0;

  try {
    // Fetch all cross-session memories for this anima
    const memories = await base44.entities.CrossSessionMemory.filter({
      character_id: animaId,
    }, '-last_reinforced', 1000);

    for (const memory of memories) {
      // Check for corrupted data
      if (!memory.subject || !memory.description) {
        issues.push(`Corrupted memory ${memory.id}: missing subject or description`);
        continue;
      }

      // Recalculate relevance score if missing
      if (!memory.relevance_score || memory.relevance_score < 0 || memory.relevance_score > 1) {
        const newScore = Math.max(0, Math.min(1, (memory.reinforcement_count || 1) / 10));
        await base44.entities.CrossSessionMemory.update(memory.id, {
          relevance_score: newScore,
        }).catch(() => {});
        repaired++;
      }
    }
  } catch (err) {
    console.error('Memory repair error:', err);
    issues.push(`Memory repair failed: ${err.message}`);
  }

  return { repaired, issues };
}

async function repairStates(base44, animaId) {
  const issues = [];
  let reset = 0;

  try {
    // Fetch current emotional states
    const states = await base44.entities.CharacterEmotionalState.filter({
      character_id: animaId,
      is_current: true,
    });

    for (const state of states) {
      // Check for stuck states (same state for too long)
      const lastUpdate = new Date(state.updated_date);
      const daysSinceUpdate = (Date.now() - lastUpdate) / (1000 * 60 * 60 * 24);

      if (daysSinceUpdate > 30) {
        // Reset to neutral if stuck
        await base44.entities.CharacterEmotionalState.update(state.id, {
          primary_emotion: 'neutral',
          intensity: 5,
          is_current: false,
        }).catch(() => {});
        issues.push(`Stuck state reset for emotion: ${state.primary_emotion}`);
        reset++;
      }

      // Validate intensity range
      if (state.intensity < 1 || state.intensity > 10) {
        await base44.entities.CharacterEmotionalState.update(state.id, {
          intensity: Math.max(1, Math.min(10, state.intensity || 5)),
        }).catch(() => {});
      }
    }
  } catch (err) {
    console.error('State repair error:', err);
    issues.push(`State repair failed: ${err.message}`);
  }

  return { reset, issues };
}

async function validateInteractions(base44, animaId) {
  const issues = [];
  let validated = 0;

  try {
    // Fetch recent chat sessions involving this anima
    const sessions = await base44.entities.ChatSession.filter({
      character_id: animaId,
    }, '-updated_date', 20);

    for (const session of sessions) {
      if (!session.messages || session.messages.length === 0) continue;

      validated++;

      // Check for malformed messages
      const malformed = session.messages.filter(m => !m.role || !m.content);
      if (malformed.length > 0) {
        issues.push(`Session ${session.id}: ${malformed.length} malformed messages detected`);
      }

      // Check for orphaned typing indicators
      const typing = session.messages.filter(m => m.character_name === '__typing__');
      if (typing.length > 0) {
        issues.push(`Session ${session.id}: ${typing.length} orphaned typing indicators`);
      }
    }
  } catch (err) {
    console.error('Interaction validation error:', err);
    issues.push(`Interaction validation failed: ${err.message}`);
  }

  return { validated, issues };
}

async function performHealthCheck(base44, animaId) {
  let score = 100;
  const issues = [];
  const checks = {};

  try {
    // 1. Check memory integrity
    const memories = await base44.entities.CrossSessionMemory.filter({
      character_id: animaId,
    });
    const memoryHealth = (memories.length > 0) ? 100 : 50;
    checks.memory = memoryHealth;
    if (memoryHealth < 100) score -= 10;

    // 2. Check relationship integrity
    const relationships = await base44.entities.CharacterRelationship.list('-created_date', 50);
    const relCount = relationships.filter(r => r.character_id === animaId || r.character_b_id === animaId).length;
    const relationshipHealth = (relCount > 0) ? 100 : 60;
    checks.relationships = relationshipHealth;
    if (relationshipHealth < 100) score -= 10;

    // 3. Check emotional state
    const emotionalStates = await base44.entities.CharacterEmotionalState.filter({
      character_id: animaId,
      is_current: true,
    });
    const emotionalHealth = (emotionalStates.length > 0) ? 100 : 70;
    checks.emotional = emotionalHealth;
    if (emotionalHealth < 100) score -= 10;

    // 4. Check active sessions
    const sessions = await base44.entities.ChatSession.filter({
      character_id: animaId,
    });
    const sessionHealth = (sessions.length > 0) ? 100 : 60;
    checks.sessions = sessionHealth;
    if (sessionHealth < 100) score -= 10;

    // 5. Check last activity
    const latestSession = sessions[0];
    if (latestSession) {
      const daysSinceActivity = (Date.now() - new Date(latestSession.updated_date)) / (1000 * 60 * 60 * 24);
      const activityHealth = (daysSinceActivity < 7) ? 100 : (daysSinceActivity < 30) ? 80 : 50;
      checks.activity = activityHealth;
      if (activityHealth < 100) score -= 5;
    }

    score = Math.max(0, Math.min(100, score));
  } catch (err) {
    console.error('Health check error:', err);
    issues.push(`Health check failed: ${err.message}`);
    score = 0;
  }

  return { score, checks, issues };
}

async function repairDatabase(base44, animaId) {
  const issues = [];
  let repaired = 0;

  try {
    // 1. Validate all entities reference valid characters
    const memories = await base44.entities.VectorMemory.filter({
      character_id: animaId,
    }, '-created_date', 1000);

    for (const memory of memories.slice(0, 100)) {
      // Validate related characters exist
      if (memory.related_characters && memory.related_characters.length > 0) {
        for (const charId of memory.related_characters) {
          const char = await base44.entities.Character.filter({ id: charId }).catch(() => null);
          if (!char || char.length === 0) {
            issues.push(`Dangling reference in memory ${memory.id}: character ${charId} not found`);
          }
        }
      }
    }

    // 2. Check for orphaned records (sessions with no character)
    const sessions = await base44.entities.ChatSession.filter({
      character_id: animaId,
    }, '-created_date', 100);

    const validSessions = [];
    for (const session of sessions) {
      const char = await base44.entities.Character.filter({ id: animaId }).catch(() => null);
      if (char && char.length > 0) {
        validSessions.push(session);
      } else {
        issues.push(`Orphaned session ${session.id}: character no longer exists`);
      }
    }

    repaired = memories.length + validSessions.length;
  } catch (err) {
    console.error('Database repair error:', err);
    issues.push(`Database repair failed: ${err.message}`);
  }

  return { repaired, issues };
}