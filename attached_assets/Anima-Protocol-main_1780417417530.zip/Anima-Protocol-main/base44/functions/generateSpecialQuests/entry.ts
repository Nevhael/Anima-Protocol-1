import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, type } = await req.json();

    const now = new Date();
    const dayOfWeek = now.getDay();
    const hour = now.getHours();

    // Determine quest type based on time
    const isDailyReset = hour === 0;
    const isWeeklyReset = dayOfWeek === 0 && hour === 0;

    const prompt = `Generate 2-3 special ${type === "daily_weekly" ? "daily/weekly challenge quests" : "quests"} for a narrative game.
These are time-limited bonus quests that offer extra XP rewards.

Format each quest as JSON:
{
  "title": "quest name",
  "description": "brief description",
  "bonus_xp": 50-150,
  "difficulty": "easy|moderate|hard",
  "expires_in": "${type === "daily_weekly" ? isWeeklyReset ? "7 days" : "24 hours" : "custom time"}",
  "type": "${isWeeklyReset ? "weekly" : "daily"}"
}

Make quests thematic, achievable within ${isWeeklyReset ? "a week" : "a day"}, and engaging.
Return a JSON array of quests.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          quests: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                bonus_xp: { type: "number" },
                difficulty: { type: "string" },
                expires_in: { type: "string" },
                type: { type: "string" },
              },
            },
          },
        },
      },
    });

    // Add IDs to quests
    const quests = result.quests?.map((q, idx) => ({
      ...q,
      id: `special-${now.toISOString().split("T")[0]}-${idx}`,
    })) || [];

    return Response.json({ quests });
  } catch (error) {
    console.error("Special quests error:", error);
    return Response.json({ quests: [] });
  }
});