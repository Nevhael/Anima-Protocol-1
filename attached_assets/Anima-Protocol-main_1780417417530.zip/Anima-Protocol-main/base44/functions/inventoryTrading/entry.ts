import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { action, session_id, initiator_id, recipient_id, initiator_items, recipient_items } = await req.json();

    if (action === 'initiate_trade') {
      // Create a pending trade offer
      const trade = await base44.entities.Trade.create({
        session_id,
        initiator_id,
        recipient_id,
        initiator_items: initiator_items || [],
        recipient_items: [],
        status: 'pending',
      });

      // Cache character names
      const initiator = await base44.entities.Character.list().then(chars => chars.find(c => c.id === initiator_id));
      const recipient = await base44.entities.Character.list().then(chars => chars.find(c => c.id === recipient_id));

      if (initiator?.name) trade.initiator_name = initiator.name;
      if (recipient?.name) trade.recipient_name = recipient.name;
      await base44.entities.Trade.update(trade.id, { initiator_name: trade.initiator_name, recipient_name: trade.recipient_name });

      return Response.json({ success: true, trade });
    }

    if (action === 'counter_offer') {
      const { trade_id, counter_items } = await req.json();
      await base44.entities.Trade.update(trade_id, { recipient_items: counter_items });
      return Response.json({ success: true });
    }

    if (action === 'accept_trade') {
      const { trade_id } = await req.json();
      const trade = await base44.entities.Trade.list().then(trades => trades.find(t => t.id === trade_id));

      if (!trade) return Response.json({ error: 'Trade not found' }, { status: 404 });

      // Validate both sides still have items
      const initiatorItems = await Promise.all(
        (trade.initiator_items || []).map(item => base44.entities.Inventory.list().then(inv => inv.find(i => i.id === item.inventory_id)))
      );
      const recipientItems = await Promise.all(
        (trade.recipient_items || []).map(item => base44.entities.Inventory.list().then(inv => inv.find(i => i.id === item.inventory_id)))
      );

      if (initiatorItems.some(i => !i) || recipientItems.some(i => !i)) {
        return Response.json({ error: 'One or more items no longer available' }, { status: 400 });
      }

      // Execute trade: transfer items
      for (const item of trade.initiator_items) {
        const inv = initiatorItems.find(i => i.id === item.inventory_id);
        if (inv) {
          inv.quantity -= item.quantity;
          if (inv.quantity <= 0) {
            await base44.entities.Inventory.delete(inv.id);
          } else {
            await base44.entities.Inventory.update(inv.id, { quantity: inv.quantity });
          }
          // Add to recipient
          const recipientInv = await base44.entities.Inventory.filter({
            character_id: trade.recipient_id,
            name: inv.name,
          }).then(items => items?.[0]);

          if (recipientInv) {
            await base44.entities.Inventory.update(recipientInv.id, { quantity: recipientInv.quantity + item.quantity });
          } else {
            await base44.entities.Inventory.create({
              character_id: trade.recipient_id,
              name: inv.name,
              description: inv.description,
              type: inv.type,
              quantity: item.quantity,
              rarity: inv.rarity,
              trade_value: inv.trade_value,
            });
          }
        }
      }

      // Same for recipient items going to initiator
      for (const item of trade.recipient_items) {
        const inv = recipientItems.find(i => i.id === item.inventory_id);
        if (inv) {
          inv.quantity -= item.quantity;
          if (inv.quantity <= 0) {
            await base44.entities.Inventory.delete(inv.id);
          } else {
            await base44.entities.Inventory.update(inv.id, { quantity: inv.quantity });
          }
          const initiatorInv = await base44.entities.Inventory.filter({
            character_id: trade.initiator_id,
            name: inv.name,
          }).then(items => items?.[0]);

          if (initiatorInv) {
            await base44.entities.Inventory.update(initiatorInv.id, { quantity: initiatorInv.quantity + item.quantity });
          } else {
            await base44.entities.Inventory.create({
              character_id: trade.initiator_id,
              name: inv.name,
              description: inv.description,
              type: inv.type,
              quantity: item.quantity,
              rarity: inv.rarity,
              trade_value: inv.trade_value,
            });
          }
        }
      }

      // Mark trade as completed
      await base44.entities.Trade.update(trade_id, { status: 'completed', completed_at: new Date().toISOString() });

      return Response.json({ success: true, message: 'Trade completed' });
    }

    if (action === 'reject_trade') {
      const { trade_id } = await req.json();
      await base44.entities.Trade.update(trade_id, { status: 'rejected' });
      return Response.json({ success: true });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    console.error('Trading error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});