/**
 * syncWorldState — Entity automation handler
 * Triggered whenever a ChatSession is created or updated.
 * Performs a full-session deep scan to extract and persist global plot events
 * into the WorldState database, ensuring the AI always has an accurate world picture.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    // Accept both direct calls (session_id) and entity automation payloads
    let session_id = body.session_id;
    let sessionData = body.session;

    if (!session_id && body.event?.entity_id) {
      session_id = body.event.entity_id;
    }

    if (!session_id && body.data?.id) {
      session_id = body.data.id;
      sessionData = body.data;
    }

    if (!session_id) {
      return Response.json({ error: 'No session_id found in payload' }, { status: 400 });
    }

    // Fetch session data if not provided
    if (!sessionData) {
      const sessions = await base44.asServiceRole.entities.ChatSession.filter({ id: session_id });
      sessionData = sessions?.[0];
    }

    if (!sessionData) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    const messages = (sessionData.messages || []).filter(
      m => m.role !== undefined && m.character_name !== '__typing__' && m.type !== 'event'
    );

    // Need at least a few messages to be worth scanning
    if (messages.length < 2) {
      return Response.json({ skipped: true, reason: 'Too few messages' });
    }

    // Only scan the last 20 messages to keep prompt focused and cost-efficient
    const recentMessages = messages.slice(-20);
    const transcript = recentMessages
      .map(m => {
        const speaker = m.role === 'user' ? 'Player' : (m.character_name || 'Character');
        return `${speaker}: ${m.content}`;
      })
      .join('\n');

    // Fetch already-known facts for this session to avoid duplication
    const existingFacts = await base44.asServiceRole.entities.WorldState.filter(
      { session_id, is_active: true },
      '-created_date',
      100
    );

    const existingList = (existingFacts || [])
      .map((f, i) => `${i + 1}. [${f.category}] ${f.subject}: ${f.fact}`)
      .join('\n');

    const analysis = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are a world-state tracker for a persistent collaborative roleplay story. Your job is to extract ALL globally significant plot events from the conversation that should be remembered across future sessions.

SESSION TRANSCRIPT (recent):
${transcript}

ALREADY TRACKED FACTS (do NOT duplicate these):
${existingList || '(none yet)'}

INSTRUCTIONS:
Scan the transcript and identify NEW facts that represent lasting changes to the story world. Be thorough — look for:
- Character revelations (true identities, hidden powers, backstory disclosures)
- Key items acquired, lost, destroyed, or gifted
- Locations discovered, destroyed, or changed
- Alliances, betrayals, vows, contracts formed or broken
- Deaths, resurrections, transformations
- World rules, laws, prophecies, or curses established
- Political or factional power shifts
- Secrets revealed or buried deeper

For each new fact, also flag whether it INVALIDATES any existing fact (provide the existing fact text if so).

Return JSON:
{
  "entries": [
    {
      "category": "character_fact"|"item"|"location"|"event"|"relationship"|"secret"|"rule",
      "subject": "exact name of person/place/thing",
      "fact": "precise, specific statement (max 30 words)",
      "importance": "low"|"medium"|"high"|"critical",
      "invalidates": "exact text of an existing fact this replaces, or null"
    }
  ]
}

Return empty entries array if nothing new and significant is found.`,
      response_json_schema: {
        type: 'object',
        properties: {
          entries: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                category: { type: 'string' },
                subject: { type: 'string' },
                fact: { type: 'string' },
                importance: { type: 'string' },
                invalidates: { type: 'string' }
              }
            }
          }
        }
      }
    });

    const entries = (analysis.entries || []).filter(e => e.fact?.trim());
    const created = [];
    const invalidated = [];

    for (const entry of entries) {
      // Dedup: skip near-identical facts
      const similar = (existingFacts || []).some(e => {
        if (e.subject?.toLowerCase() !== entry.subject?.toLowerCase()) return false;
        const aWords = new Set(e.fact.toLowerCase().split(/\W+/).filter(w => w.length > 3));
        const bWords = entry.fact.toLowerCase().split(/\W+/).filter(w => w.length > 3);
        const overlap = bWords.filter(w => aWords.has(w)).length;
        return overlap / Math.max(bWords.length, 1) > 0.65;
      });
      if (similar) continue;

      // Handle invalidation: mark old facts inactive
      if (entry.invalidates) {
        const toInvalidate = (existingFacts || []).filter(e =>
          e.fact?.toLowerCase().includes(entry.invalidates.toLowerCase().slice(0, 30))
        );
        for (const old of toInvalidate) {
          await base44.asServiceRole.entities.WorldState.update(old.id, { is_active: false });
          invalidated.push(old.id);
        }
      }

      const record = await base44.asServiceRole.entities.WorldState.create({
        session_id,
        category: entry.category || 'event',
        subject: entry.subject || 'Unknown',
        fact: entry.fact,
        importance: entry.importance || 'medium',
        is_active: true,
        source_message_index: messages.length - 1
      });
      created.push(record);
    }

    return Response.json({
      created: created.length,
      invalidated: invalidated.length,
      entries: created
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});