/**
 * updateCharacterEmotion — Analyzes character dialogue and player decisions to detect
 * emotional state shifts, then persists them to the CharacterEmotionalState entity.
 * Fired after each message in a session.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { character_id, session_id, character_name, user_message, ai_response, message_index } = body;

    if (!character_id || !session_id || !ai_response) {
      return Response.json({ skipped: true, reason: 'Missing required fields' });
    }

    // Analyze the dialogue to detect emotional shifts
    const analysis = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are an emotional state analyzer for a character in a collaborative roleplay. Analyze this character's response and infer what emotions they are experiencing based on the dialogue, tone, and context.

CHARACTER: ${character_name}
Player said: "${user_message}"
Character responded: "${ai_response.slice(0, 800)}"

Based on this exchange, determine:
1. What is the character's PRIMARY emotional state right now?
2. Is there a secondary/mixed emotion?
3. How intense is this emotion (0-100)?
4. What specifically triggered this emotional shift?
5. Was the emotion caused by the player or by external circumstances?

EMOTION OPTIONS: joyful, calm, sad, angry, afraid, disgusted, surprised, hopeful, conflicted, desperate

Return JSON:
{
  "primary_emotion": "one of the emotions above",
  "secondary_emotion": "optional mixed emotion or null",
  "intensity": 0-100,
  "trigger": "brief description of what caused this emotion",
  "affected_by_actor": "player or character name"
}

Be specific and grounded in the actual dialogue. Only flag emotions that are clearly present.`,
      response_json_schema: {
        type: 'object',
        properties: {
          primary_emotion: { type: 'string' },
          secondary_emotion: { type: 'string' },
          intensity: { type: 'number' },
          trigger: { type: 'string' },
          affected_by_actor: { type: 'string' }
        }
      }
    });

    if (!analysis?.primary_emotion) {
      return Response.json({ skipped: true, reason: 'No clear emotion detected' });
    }

    // Mark any previous "current" state as non-current
    const previous = await base44.asServiceRole.entities.CharacterEmotionalState.filter({
      character_id,
      session_id,
      is_current: true
    });

    for (const prev of previous || []) {
      await base44.asServiceRole.entities.CharacterEmotionalState.update(prev.id, {
        is_current: false
      });
    }

    // Create new emotional state record
    const record = await base44.asServiceRole.entities.CharacterEmotionalState.create({
      character_id,
      session_id,
      primary_emotion: analysis.primary_emotion,
      secondary_emotion: analysis.secondary_emotion || null,
      intensity: Math.min(100, Math.max(0, analysis.intensity || 50)),
      trigger: analysis.trigger || 'Unspecified',
      message_index: message_index || 0,
      is_current: true,
      affected_by_actor: analysis.affected_by_actor || 'unknown'
    });

    return Response.json({
      created: true,
      emotion: record.primary_emotion,
      intensity: record.intensity,
      trigger: record.trigger
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});