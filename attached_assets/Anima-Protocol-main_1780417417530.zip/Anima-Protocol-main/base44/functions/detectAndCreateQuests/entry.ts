import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const sessionId = body.session_id;
    const userMessage = body.user_message;
    const aiResponse = body.ai_response;
    const characterName = body.character_name;

    if (!sessionId || !userMessage) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Quest detection patterns
    const questPatterns = [
      { pattern: /find|search|locate|discover/i, type: 'exploration', verb: 'Find' },
      { pattern: /help|assist|support|aid/i, type: 'assistance', verb: 'Help' },
      { pattern: /defeat|kill|destroy|fight|battle/i, type: 'combat', verb: 'Defeat' },
      { pattern: /retrieve|fetch|get|obtain|acquire/i, type: 'retrieval', verb: 'Retrieve' },
      { pattern: /protect|guard|defend|keep safe/i, type: 'protection', verb: 'Protect' },
      { pattern: /investigate|learn|understand|figure out|uncover/i, type: 'investigation', verb: 'Investigate' },
      { pattern: /reach|go to|travel to|arrive at|journey/i, type: 'journey', verb: 'Reach' },
      { pattern: /solve|fix|repair|resolve|restore/i, type: 'repair', verb: 'Solve' },
    ];

    const detectedQuests = [];

    // Parse user message for quest triggers
    for (const { pattern, type, verb } of questPatterns) {
      if (pattern.test(userMessage)) {
        // Extract the object/goal from the message
        const messageLower = userMessage.toLowerCase();
        const goalMatch = userMessage.match(/(?:to\s+)?(?:help|find|defeat|protect|reach|solve)\s+([^,.!?]+)/i);
        const goal = goalMatch ? goalMatch[1].trim() : 'Unnamed objective';

        // Check if similar quest already exists
        const existingQuests = await base44.entities.Quest.filter({
          session_id: sessionId,
          title: { $regex: goal, $options: 'i' },
          status: { $in: ['active', 'available'] },
        });

        if (existingQuests.length === 0) {
          detectedQuests.push({
            type,
            verb,
            goal,
            confidence: pattern.test(userMessage) ? 0.9 : 0.7,
          });
        }
      }
    }

    // Create Quest entities for detected quests
    const createdQuests = [];
    for (const questData of detectedQuests) {
      try {
        const newQuest = await base44.entities.Quest.create({
          session_id: sessionId,
          title: `${questData.verb} ${questData.goal}`,
          description: `User intention: ${questData.verb} ${questData.goal}. Detected in conversation with ${characterName || 'companion'}.`,
          objectives: [
            {
              id: `obj_${Date.now()}`,
              description: questData.goal,
              completed: false,
            },
          ],
          status: 'active',
          difficulty: 'moderate',
          narrative_context: `Emerged from player request: "${userMessage.slice(0, 100)}..."`,
        });

        createdQuests.push({
          id: newQuest.id,
          title: newQuest.title,
          type: questData.type,
          confidence: questData.confidence,
        });
      } catch (err) {
        console.warn(`Failed to create quest for "${questData.goal}":`, err.message);
      }
    }

    // Generate character acknowledgment if quests were created
    let acknowledgment = '';
    if (createdQuests.length > 0) {
      const questTitles = createdQuests.map(q => q.title).join(', ');
      acknowledgment = `✓ Understood. I've noted your objective${createdQuests.length > 1 ? 's' : ''}: ${questTitles}`;
    }

    return Response.json({
      success: true,
      detectedCount: detectedQuests.length,
      createdCount: createdQuests.length,
      quests: createdQuests,
      acknowledgment,
    });
  } catch (error) {
    console.error('Quest detection error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});