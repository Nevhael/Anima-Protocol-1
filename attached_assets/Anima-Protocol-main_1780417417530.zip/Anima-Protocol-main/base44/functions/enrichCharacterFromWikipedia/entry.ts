import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { character_id, character_name, universe } = await req.json();

    if (!character_name) {
      return Response.json({ error: 'Missing character_name' }, { status: 400 });
    }

    // Search Wikipedia for character
    const searchQuery = universe ? `${character_name} ${universe}` : character_name;
    const wikiData = await fetchWikipediaData(searchQuery);

    if (!wikiData) {
      return Response.json({
        success: false,
        enriched: false,
        reason: 'Character not found on Wikipedia',
      });
    }

    // Extract personality traits from Wikipedia content
    const extracted = extractPersonalityTraits(wikiData.content, character_name);
    const speaking_style = generateSpeakingStyle(wikiData.content, character_name);
    const backstory = wikiData.content.slice(0, 500); // First 500 chars as backstory

    // Update character with enriched data
    if (character_id) {
      try {
        await base44.entities.Character.update(character_id, {
          personality: extracted.personality,
          backstory,
          speaking_style,
          _wikipedia_source: wikiData.url,
          _enriched_at: new Date().toISOString(),
        });
      } catch (err) {
        console.log('Could not update character entity, returning enriched data only');
      }
    }

    return Response.json({
      success: true,
      enriched: true,
      character_name,
      enrichment: {
        personality: extracted.personality,
        backstory,
        speaking_style,
        traits: extracted.traits,
        wikipedia_url: wikiData.url,
      },
    });
  } catch (error) {
    console.error('Wikipedia enrichment error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function fetchWikipediaData(query) {
  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(query)}&utf8=1`;
    const searchRes = await fetch(searchUrl);
    const searchData = await searchRes.json();

    if (!searchData.query.search.length) return null;

    const pageTitle = searchData.query.search[0].title;
    const contentUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&titles=${encodeURIComponent(pageTitle)}&prop=extracts&exintro=true&explaintext=true`;
    const contentRes = await fetch(contentUrl);
    const contentData = await contentRes.json();

    const pages = contentData.query.pages;
    const pageId = Object.keys(pages)[0];
    const extract = pages[pageId].extract || '';

    return {
      title: pageTitle,
      content: extract,
      url: `https://en.wikipedia.org/wiki/${encodeURIComponent(pageTitle)}`,
    };
  } catch (err) {
    console.error('Wikipedia fetch error:', err);
    return null;
  }
}

function extractPersonalityTraits(content, characterName) {
  const traits = [];
  const personality = [];

  // Keywords for personality extraction
  const personalityKeywords = {
    brave: ['brave', 'courageous', 'fearless', 'valiant', 'heroic'],
    intelligent: ['intelligent', 'wise', 'clever', 'smart', 'intellectual'],
    kind: ['kind', 'compassionate', 'caring', 'empathetic', 'gentle'],
    cunning: ['cunning', 'sly', 'manipulative', 'strategic', 'scheming'],
    stoic: ['stoic', 'calm', 'composed', 'collected', 'serene'],
    passionate: ['passionate', 'fiery', 'intense', 'emotional', 'fervent'],
    mysterious: ['mysterious', 'enigmatic', 'secretive', 'hidden', 'obscure'],
    noble: ['noble', 'honorable', 'dignified', 'refined', 'aristocratic'],
  };

  const contentLower = content.toLowerCase();

  Object.entries(personalityKeywords).forEach(([trait, keywords]) => {
    if (keywords.some(kw => contentLower.includes(kw))) {
      traits.push(trait);
      personality.push(`${trait.charAt(0).toUpperCase() + trait.slice(1)}: ${keyword} nature`);
    }
  });

  return {
    traits: traits.slice(0, 5),
    personality: personality.slice(0, 3).join('. ') || `${characterName} is a complex character.`,
  };
}

function generateSpeakingStyle(content, characterName) {
  const contentLower = content.toLowerCase();

  // Detect speech patterns from biography
  const patterns = {
    formal: contentLower.includes('diplomat') || contentLower.includes('royal') || contentLower.includes('noble'),
    sarcastic: contentLower.includes('wit') || contentLower.includes('humor') || contentLower.includes('irony'),
    poetic: contentLower.includes('artist') || contentLower.includes('poet') || contentLower.includes('muse'),
    technical: contentLower.includes('scientist') || contentLower.includes('inventor') || contentLower.includes('academic'),
    casual: contentLower.includes('adventurer') || contentLower.includes('rogue') || contentLower.includes('free'),
  };

  const detected = Object.entries(patterns)
    .filter(([_, match]) => match)
    .map(([style]) => style)[0] || 'conversational';

  const styles = {
    formal: `${characterName} speaks with refined eloquence and measured precision. Their words carry weight and authority, often employing sophisticated vocabulary and articulate phrasing.`,
    sarcastic: `${characterName} communicates with wit and irony, often employing clever wordplay and sharp observations. They have a tendency toward sarcasm and dark humor.`,
    poetic: `${characterName} speaks in vivid, evocative language, painting scenes with metaphor and symbolism. Their dialogue flows with lyrical cadence.`,
    technical: `${characterName} speaks methodically, favoring precise terminology and logical explanations. They break down complex ideas into understandable components.`,
    casual: `${characterName} speaks conversationally and informally, with natural charm and spontaneity. They favor directness over formality.`,
    conversational: `${characterName} communicates in a balanced, approachable manner, adapting their speech to their audience while maintaining authenticity.`,
  };

  return styles[detected] || styles.conversational;
}