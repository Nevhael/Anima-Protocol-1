import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { emotion, intensity } = await req.json();

    if (!emotion) {
      return Response.json({ error: 'Emotion parameter required' }, { status: 400 });
    }

    // ElevenLabs voice settings mapped to emotional states
    const emotionVoiceMap = {
      joyful: {
        stability: 0.4,        // Lower stability = more variation, energy
        similarity: 0.75,      // Good clarity while varying
        style_exaggeration: 1.5, // Higher exaggeration for joy
        speaking_rate: 1.15,   // Slightly faster
        pitch_shift: 15,       // Higher pitch
        emotional_intent: 'cheerful'
      },
      calm: {
        stability: 0.7,        // Higher stability = smooth, steady
        similarity: 0.85,
        style_exaggeration: 0.8,
        speaking_rate: 0.95,   // Slightly slower
        pitch_shift: 0,        // Neutral pitch
        emotional_intent: 'relaxed'
      },
      peaceful: {
        stability: 0.8,        // Very smooth
        similarity: 0.9,
        style_exaggeration: 0.6,
        speaking_rate: 0.85,   // Slower, meditative
        pitch_shift: -10,      // Slightly lower pitch
        emotional_intent: 'calm'
      },
      sad: {
        stability: 0.6,        // Moderate variation = melancholic
        similarity: 0.75,
        style_exaggeration: 1.2,
        speaking_rate: 0.8,    // Slower, drawn out
        pitch_shift: -15,      // Lower, heavier tone
        emotional_intent: 'sad'
      },
      anxious: {
        stability: 0.3,        // Low stability = jittery, uncertain
        similarity: 0.7,
        style_exaggeration: 1.8, // High exaggeration for tension
        speaking_rate: 1.25,   // Faster, rushed
        pitch_shift: 10,       // Slightly higher, tense
        emotional_intent: 'nervous'
      },
      angry: {
        stability: 0.5,        // Variable but controlled
        similarity: 0.8,
        style_exaggeration: 2.0, // Maximum exaggeration for intensity
        speaking_rate: 1.2,    // Faster, sharp
        pitch_shift: 12,       // Higher, sharp tone
        emotional_intent: 'aggressive'
      },
      conflicted: {
        stability: 0.45,       // Moderate variation = inner struggle
        similarity: 0.75,
        style_exaggeration: 1.3,
        speaking_rate: 1.0,    // Normal pace but thoughtful pauses
        pitch_shift: 5,        // Slight pitch variation
        emotional_intent: 'uncertain'
      },
      hopeful: {
        stability: 0.5,        // Moderate variation = cautious optimism
        similarity: 0.8,
        style_exaggeration: 1.1,
        speaking_rate: 1.05,   // Slightly brighter
        pitch_shift: 8,        // Slightly elevated
        emotional_intent: 'optimistic'
      },
      neutral: {
        stability: 0.75,       // Balanced
        similarity: 0.85,
        style_exaggeration: 1.0,
        speaking_rate: 1.0,
        pitch_shift: 0,
        emotional_intent: 'neutral'
      }
    };

    // Get base parameters for the emotion
    const baseParams = emotionVoiceMap[emotion] || emotionVoiceMap.neutral;

    // Adjust intensity scaling (1-10 scale)
    const intensityScale = intensity ? (intensity / 5) : 1.0; // Normalize to 0.2-2.0 range for 1-10 input

    // Scale parameters by intensity
    const adjustedParams = {
      stability: Math.max(0.2, Math.min(1.0, baseParams.stability / intensityScale)),
      similarity: Math.max(0.6, Math.min(1.0, baseParams.similarity)),
      style_exaggeration: Math.max(0.5, Math.min(3.0, baseParams.style_exaggeration * intensityScale)),
      speaking_rate: Math.max(0.5, Math.min(2.0, baseParams.speaking_rate * intensityScale)),
      pitch_shift: baseParams.pitch_shift * intensityScale,
      emotional_intent: baseParams.emotional_intent
    };

    return Response.json({
      voice_params: adjustedParams,
      emotion: emotion,
      intensity: intensity || 5,
      description: `Voice adjusted for ${emotion} emotion (intensity: ${intensity || 5}/10)`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});