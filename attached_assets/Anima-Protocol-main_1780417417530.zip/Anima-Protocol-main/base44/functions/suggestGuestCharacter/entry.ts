import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, recent_messages, calendar_data } = await req.json();
    
    if (!session_id || !recent_messages || recent_messages.length === 0) {
      return Response.json({ error: 'Missing required data' }, { status: 400 });
    }

    // Fetch guest characters that are enabled
    const guestChars = await base44.entities.GuestCharacter.filter({ is_enabled: true }, "-created_date", 50);
    
    if (guestChars.length === 0) {
      return Response.json({ suggested: null });
    }

    // Build context from recent messages
    const conversationContext = recent_messages
      .slice(-6)
      .map(m => `${m.character_name}: ${m.content}`)
      .join('\n');

    const timelineContext = calendar_data ? `Current story time: ${calendar_data.current_season}, Day ${calendar_data.day_of_season}` : '';

    // Use LLM to analyze which guest character would fit the narrative
    const prompt = `Given this narrative context and guest characters, determine which guest character (if any) would naturally appear next in the story.

RECENT CONVERSATION:
${conversationContext}

${timelineContext}

AVAILABLE GUEST CHARACTERS:
${guestChars.map(g => `[${g.name}] - From ${g.universe}
Description: ${g.description}
Triggers: ${g.trigger_keywords?.join(', ') || 'None'}
Timeline: ${g.timeline_appearance || 'Flexible'}
Relationships: ${g.relationship_context?.join(', ') || 'Independent'}
`).join('\n')}

Respond with ONLY the character name if one should appear, or "NONE" if no character fits the moment. One word/name response only.`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });
    const suggestion = result.trim();

    if (suggestion === 'NONE' || suggestion.includes('none')) {
      return Response.json({ suggested: null });
    }

    // Find the suggested character
    const selectedChar = guestChars.find(g => g.name.toLowerCase() === suggestion.toLowerCase());
    
    if (!selectedChar) {
      return Response.json({ suggested: null });
    }

    // Create a temporary character object for injection
    const guestCharForChat = {
      id: `guest_${selectedChar.id}`,
      name: selectedChar.name,
      personality: selectedChar.personality,
      backstory: selectedChar.description,
      speaking_style: selectedChar.speaking_style,
      universe: selectedChar.universe,
      is_guest: true,
    };

    return Response.json({
      suggested: guestCharForChat,
      reason: `${selectedChar.name} appears at this moment in the story`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});