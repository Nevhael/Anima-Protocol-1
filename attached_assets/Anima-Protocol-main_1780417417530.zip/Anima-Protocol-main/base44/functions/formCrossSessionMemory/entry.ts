import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_id,
      session_id,
      related_character_id,
      recent_messages,
      relationship_score,
      character_emotions,
    } = await req.json();

    if (!character_id || !session_id || !recent_messages || recent_messages.length === 0) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Use LLM to extract memory-worthy moments from conversation
    const messagesContext = recent_messages
      .slice(-20)
      .map(m => `${m.character_name || 'User'}: ${m.content}`)
      .join('\n');

    const extractionPrompt = `You are a memory extraction system. Analyze this conversation and identify 1-3 significant memory-worthy moments that should be remembered across future sessions.

Conversation:
${messagesContext}

For each memory, provide:
1. memory_type: one of [relationship_milestone, shared_event, character_development, interaction_pattern, personal_growth, conflict_resolution]
2. subject: brief title
3. description: 1-2 sentences capturing the essence
4. emotional_weight: 1-10 (how emotionally significant)
5. relationship_impact: -10 to +10 (how it affected the relationship)
6. tags: 3-5 searchable keywords

IMPORTANT: Only extract genuinely significant moments. Not every exchange is memorable.

Return as JSON array: [{ memory_type, subject, description, emotional_weight, relationship_impact, tags }]`;

    const extractionResult = await base44.integrations.Core.InvokeLLM({
      prompt: extractionPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          memories: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                memory_type: { type: 'string' },
                subject: { type: 'string' },
                description: { type: 'string' },
                emotional_weight: { type: 'number' },
                relationship_impact: { type: 'number' },
                tags: { type: 'array', items: { type: 'string' } }
              }
            }
          }
        }
      }
    });

    if (!extractionResult?.memories || extractionResult.memories.length === 0) {
      return Response.json({ created: 0, memories: [] });
    }

    const createdMemories = [];
    for (const mem of extractionResult.memories) {
      // Check if similar memory exists
      const existingMemories = await base44.entities.CrossSessionMemory.filter({
        character_id,
        subject: mem.subject,
      });

      if (existingMemories?.length > 0) {
        // Reinforce existing memory
        const existing = existingMemories[0];
        await base44.entities.CrossSessionMemory.update(existing.id, {
          reinforcement_count: (existing.reinforcement_count || 1) + 1,
          last_reinforced: new Date().toISOString(),
          session_ids: [...(existing.session_ids || []), session_id].filter((v, i, a) => a.indexOf(v) === i),
          emotional_weight: Math.max(existing.emotional_weight || 5, mem.emotional_weight),
          tags: Array.from(new Set([...(existing.tags || []), ...mem.tags])),
        });
        createdMemories.push({ ...existing, reinforced: true });
      } else {
        // Create new memory
        const newMemory = await base44.entities.CrossSessionMemory.create({
          character_id,
          related_character_id: related_character_id || null,
          memory_type: mem.memory_type,
          subject: mem.subject,
          description: mem.description,
          emotional_weight: mem.emotional_weight,
          relationship_impact: mem.relationship_impact,
          session_ids: [session_id],
          tags: mem.tags,
          last_reinforced: new Date().toISOString(),
          reinforcement_count: 1,
          relevance_score: calculateRelevance(mem.emotional_weight, 1),
        });
        createdMemories.push(newMemory);
      }
    }

    return Response.json({
      created: createdMemories.length,
      memories: createdMemories,
    });
  } catch (error) {
    console.error('Memory formation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function calculateRelevance(emotionalWeight, reinforcementCount) {
  // Higher emotional weight + reinforcement = higher relevance
  return Math.min((emotionalWeight / 10) * (1 + Math.log(reinforcementCount + 1)), 1);
}