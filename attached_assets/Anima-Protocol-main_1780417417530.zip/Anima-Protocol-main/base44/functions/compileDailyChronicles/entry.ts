import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * compileDailyChronicles
 * Runs daily (or on-demand) — finds all active characters with interactions
 * in the last 24 hours and generates a journal entry for each.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow admin-only or scheduler invocation
    let user = null;
    try {
      user = await base44.auth.me();
    } catch (_) { /* scheduled calls have no user */ }

    if (user && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const forceSessionId = body.session_id || null; // optional: compile for a specific session only

    // Find sessions updated in the last 24 hours
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const recentSessions = await base44.asServiceRole.entities.ChatSession.list('-updated_date', 50);

    const activeSessions = (recentSessions || []).filter(s => {
      if (forceSessionId && s.id !== forceSessionId) return false;
      return s.updated_date >= cutoff && (s.messages || []).length >= 4;
    });

    if (activeSessions.length === 0) {
      return Response.json({ compiled: 0, reason: 'No active sessions in last 24h' });
    }

    const results = [];

    for (const session of activeSessions) {
      const messages = session.messages || [];
      if (messages.length < 4) continue;

      // Determine characters involved
      const charIds = [];
      if (session.mode === 'solo' && session.character_id) {
        charIds.push(session.character_id);
      } else if (session.mode === 'group' && session.group_character_ids?.length) {
        charIds.push(...session.group_character_ids.slice(0, 4)); // max 4 in group
      }

      if (charIds.length === 0) continue;

      // Get recent messages from the last 24h window
      const recentMessages = messages.filter(m => {
        if (!m.timestamp) return true;
        return m.timestamp >= cutoff;
      });

      if (recentMessages.length < 2) continue;

      // Build a summary of user ↔ AI exchanges for the journal
      const exchanges = [];
      for (let i = 0; i < recentMessages.length - 1; i++) {
        const m = recentMessages[i];
        const next = recentMessages[i + 1];
        if (m.role === 'user' && next?.role === 'assistant') {
          exchanges.push({ user: m.content, ai: next.content, char: next.character_name });
        }
      }

      for (const charId of charIds) {
        // Check if a chronicle already exists for today
        const today = new Date().toISOString().split('T')[0];
        const existing = await base44.asServiceRole.entities.CharacterJournal.filter({
          character_id: charId,
          session_id: session.id,
        }, '-created_date', 5);

        const alreadyToday = (existing || []).some(j => {
          const jDate = j.created_date?.split('T')[0];
          return jDate === today;
        });

        if (alreadyToday) {
          results.push({ charId, session_id: session.id, skipped: true, reason: 'Already compiled today' });
          continue;
        }

        // Find the most relevant exchange for this character
        const charExchanges = exchanges.filter(e => {
          const charName = e.char?.toLowerCase() || '';
          return charExchanges?.length
            ? charName === charName
            : true;
        });

        const lastExchange = exchanges[exchanges.length - 1] || exchanges[0];
        if (!lastExchange) continue;

        // Look up character name
        const charData = await base44.asServiceRole.entities.Character.filter({ id: charId });
        const charName = charData?.[0]?.name;
        if (!charName) continue;

        // Call generateCharacterJournal
        const journalResult = await base44.asServiceRole.functions.invoke('generateCharacterJournal', {
          character_id: charId,
          session_id: session.id,
          character_name: charName,
          user_message: lastExchange.user?.slice(0, 400) || '',
          ai_response: lastExchange.ai?.slice(0, 600) || '',
        });

        results.push({
          charId,
          charName,
          session_id: session.id,
          created: journalResult?.created || false,
          journal_id: journalResult?.journal_id,
          title: journalResult?.title,
          skipped: journalResult?.skipped || false,
          reason: journalResult?.reason,
        });
      }
    }

    const created = results.filter(r => r.created).length;
    const skipped = results.filter(r => r.skipped).length;

    console.log(`Chronicles compiled: ${created} created, ${skipped} skipped`);
    return Response.json({ compiled: created, skipped, results });

  } catch (error) {
    console.error('compileDailyChronicles error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});