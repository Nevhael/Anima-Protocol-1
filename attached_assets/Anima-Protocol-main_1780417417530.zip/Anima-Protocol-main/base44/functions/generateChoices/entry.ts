import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, character_name, recent_context } = await req.json();
    
    if (!session_id || !character_name) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const prompt = `Generate 3 meaningful narrative choices for the player character facing this situation:

CHARACTER: ${character_name}
CONTEXT: ${recent_context}

Create choices that:
1. Are distinct and meaningful (not trivial differences)
2. Could realistically affect character relationships or emotions
3. Show different approaches (aggressive, diplomatic, clever, cautious, etc.)
4. Advance the narrative in different directions

Each choice can affect 1-2 other characters' relationships (+5 to +30 or -5 to -30) and emotions.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          choices: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: {
                  type: "string",
                  description: "Unique choice ID"
                },
                text: {
                  type: "string",
                  description: "The player's action or dialogue"
                },
                consequence: {
                  type: "string",
                  description: "Brief description of likely outcome"
                },
                affects_relationships: {
                  type: "object",
                  description: "Map of character_id to relationship delta (-100 to 100)"
                },
                affects_emotions: {
                  type: "object",
                  description: "Map of character_id to {emotion, intensity}"
                }
              }
            }
          }
        }
      }
    });

    return Response.json({
      success: true,
      choices: result.choices || []
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});