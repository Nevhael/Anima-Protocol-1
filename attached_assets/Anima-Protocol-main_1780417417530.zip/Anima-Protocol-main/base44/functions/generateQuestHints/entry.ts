import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { quests, session_id } = await req.json();

    if (!quests || quests.length === 0) {
      return Response.json({ hints: {} });
    }

    // Fetch session context for narrative hints
    const session = session_id ? await base44.entities.ChatSession.list("-updated_date", 1).then(s => s?.[0]) : null;
    const recentMessages = session?.messages?.slice(-5) || [];

    const hints = {};
    for (const quest of quests) {
      const prompt = `You are a quest guide AI. Given this quest, provide a brief, helpful hint (1-2 sentences max) that nudges the player without spoiling the solution.

Quest: ${quest.title}
Description: ${quest.description}
Objectives: ${quest.objectives?.map(o => o.description).join(", ") || "Unknown"}
${recentMessages.length > 0 ? `Recent story context: ${recentMessages.map(m => m.content).join(" ").slice(0, 200)}` : ""}

Provide only the hint, no other text.`;

      try {
        const result = await base44.integrations.Core.InvokeLLM({ prompt });
        hints[quest.id] = result;
      } catch (err) {
        console.error(`Hint generation error for quest ${quest.id}:`, err);
        hints[quest.id] = "Continue progressing through the narrative to uncover your path forward.";
      }
    }

    return Response.json({ hints });
  } catch (error) {
    console.error("Quest hints error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});