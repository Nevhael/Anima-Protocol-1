import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { quest_id, character_id, session_id } = await req.json();

    if (!quest_id || !character_id) {
      return Response.json({ error: 'Missing quest_id or character_id' }, { status: 400 });
    }

    // Fetch the quest
    const quest = await base44.entities.Quest.list().then(quests => 
      quests.find(q => q.id === quest_id)
    );

    if (!quest) {
      return Response.json({ error: 'Quest not found' }, { status: 404 });
    }

    if (quest.status === 'completed') {
      return Response.json({ error: 'Quest already completed' }, { status: 400 });
    }

    const rewards = quest.rewards || {};
    const xpReward = rewards.xp || 0;
    const itemRewards = rewards.items || [];
    const relationshipBonuses = rewards.relationship_bonuses || {};

    // Update quest status
    await base44.entities.Quest.update(quest.id, {
      status: 'completed',
      completed_at: new Date().toISOString(),
    });

    // Update character XP and check for rank up
    const resonanceProfiles = await base44.entities.ResonanceProfile.filter({
      user_email: user.email,
    });

    let updatedProfile = null;
    if (resonanceProfiles.length > 0) {
      const profile = resonanceProfiles[0];
      const newXP = (profile.resonance_xp || 0) + xpReward;
      const rankThresholds = { Initiate: 0, Harmonic: 100, Seraphic: 250, Ascendant: 500 };
      const ranks = ['Initiate', 'Harmonic', 'Seraphic', 'Ascendant'];
      
      let newRank = profile.resonance_rank || 'Initiate';
      for (const rank of ranks) {
        if (newXP >= rankThresholds[rank]) {
          newRank = rank;
        }
      }

      await base44.entities.ResonanceProfile.update(profile.id, {
        resonance_xp: newXP,
        resonance_rank: newRank,
        total_sessions: (profile.total_sessions || 0) + (session_id ? 1 : 0),
      });

      updatedProfile = { xp: newXP, rank: newRank };
    }

    // Add items to inventory
    const addedItems = [];
    for (const item of itemRewards) {
      const newItem = await base44.entities.Inventory.create({
        character_id,
        name: item.name || item,
        type: item.type || 'reward',
        quantity: item.quantity || 1,
        rarity: item.rarity || 'common',
        equipped: false,
      });
      addedItems.push(newItem);
    }

    // Update character relationships based on bonuses
    const relationshipUpdates = [];
    for (const [charId, bonus] of Object.entries(relationshipBonuses)) {
      const rels = await base44.entities.CharacterRelationship.filter({
        session_id: session_id || '',
        character_a_id: character_id,
        character_b_id: charId,
      });

      if (rels.length > 0) {
        const rel = rels[0];
        const newScore = Math.min(100, (rel.score || 0) + bonus);
        await base44.entities.CharacterRelationship.update(rel.id, {
          score: newScore,
        });
        relationshipUpdates.push({ character: charId, bonus, newScore });
      }
    }

    return Response.json({
      success: true,
      quest_id,
      rewards: {
        xp: xpReward,
        items: addedItems,
        relationships: relationshipUpdates,
      },
      profile: updatedProfile,
    });
  } catch (error) {
    console.error('Error processing quest rewards:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});