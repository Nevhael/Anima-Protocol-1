import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      user_message,
      ai_response,
      character_id,
      session_id,
      character_emotions,
    } = await req.json();

    if (!user_message || !ai_response || !character_id) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Analyze dialogue for relationship signals
    const affinity = analyzeAffinity(user_message, ai_response, character_emotions);
    const updates = [];

    if (affinity.delta !== 0) {
      // Get all other characters in the session
      const rels = await base44.entities.CharacterRelationship.filter({
        session_id: session_id || '',
        character_a_id: character_id,
      });

      if (rels.length === 0) return Response.json({ updates: [] });

      // Update primary character's relationships based on affinity
      for (const rel of rels) {
        const newScore = Math.max(-100, Math.min(100, (rel.score || 0) + affinity.delta));
        
        // Determine tier based on score
        const tier = getTier(newScore);

        await base44.entities.CharacterRelationship.update(rel.id, {
          score: newScore,
          tier,
          last_delta: affinity.delta,
          interaction_count: (rel.interaction_count || 0) + 1,
        });

        updates.push({
          character_b_id: rel.character_b_id,
          old_score: rel.score,
          new_score: newScore,
          tier,
          delta: affinity.delta,
          reason: affinity.reason,
        });
      }
    }

    return Response.json({
      success: true,
      affinity_delta: affinity.delta,
      reason: affinity.reason,
      updates,
    });
  } catch (error) {
    console.error('Error analyzing dialogue:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function analyzeAffinity(userMessage, aiResponse, characterEmotions) {
  const msg = (userMessage + ' ' + aiResponse).toLowerCase();
  
  // Positive signals
  const positivePatterns = [
    /thank/i, /appreciate/i, /love/i, /adore/i, /amazing/i, /wonderful/i,
    /help/i, /support/i, /care/i, /trust/i, /believe/i, /proud/i,
  ];
  
  // Negative signals
  const negativePatterns = [
    /hate/i, /despise/i, /awful/i, /terrible/i, /betray/i, /lie/i,
    /deceive/i, /hurt/i, /angry/i, /furious/i, /disgusted/i, /pathetic/i,
  ];

  let delta = 0;
  let reason = 'neutral interaction';

  const positiveMatches = positivePatterns.filter(p => p.test(msg)).length;
  const negativeMatches = negativePatterns.filter(p => p.test(msg)).length;

  if (positiveMatches > negativeMatches) {
    delta = 5 + Math.min(5, positiveMatches - negativeMatches);
    reason = 'positive dialogue';
  } else if (negativeMatches > positiveMatches) {
    delta = -(5 + Math.min(5, negativeMatches - positiveMatches));
    reason = 'negative dialogue';
  }

  // Emotional context modifiers
  if (characterEmotions) {
    const emotion = characterEmotions.emotion?.toLowerCase() || '';
    const intensity = characterEmotions.intensity || 5;
    
    if (['joy', 'love', 'gratitude'].includes(emotion)) {
      delta += Math.ceil(intensity / 2);
    } else if (['anger', 'disgust', 'sadness'].includes(emotion)) {
      delta -= Math.ceil(intensity / 2);
    }
  }

  return { delta: Math.max(-10, Math.min(10, delta)), reason };
}

function getTier(score) {
  if (score >= 75) return 'devoted';
  if (score >= 50) return 'close';
  if (score >= 25) return 'warm';
  if (score >= 0) return 'neutral';
  if (score >= -50) return 'cold';
  return 'hostile';
}