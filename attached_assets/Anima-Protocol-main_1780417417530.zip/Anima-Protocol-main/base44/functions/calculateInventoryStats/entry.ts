import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id, session_id } = await req.json();

    if (!character_id) {
      return Response.json({ error: 'character_id required' }, { status: 400 });
    }

    // Fetch all inventory items for this character
    const inventoryItems = await base44.entities.Inventory.filter({
      character_id,
      ...(session_id && { session_id }),
    });

    // Calculate aggregate stats from equipped items
    const stats = {
      strength: 0,
      dexterity: 0,
      constitution: 0,
      intelligence: 0,
      wisdom: 0,
      charisma: 0,
    };

    const effects = new Set();
    let totalTradeValue = 0;
    const equippedItems = [];

    (inventoryItems || []).forEach((item) => {
      // Only equipped items modify stats
      if (item.equipped && item.stat_modifiers) {
        Object.entries(item.stat_modifiers).forEach(([stat, value]) => {
          if (stats.hasOwnProperty(stat)) stats[stat] += value;
        });
      }

      // Collect all effects regardless of equipped status
      if (item.effects && Array.isArray(item.effects)) {
        item.effects.forEach(eff => effects.add(eff));
      }

      totalTradeValue += (item.trade_value || 0) * item.quantity;

      if (item.equipped) {
        equippedItems.push({ name: item.name, type: item.type, rarity: item.rarity });
      }
    });

    // Cap stats to reasonable limits
    Object.keys(stats).forEach(key => {
      stats[key] = Math.max(-20, Math.min(20, stats[key]));
    });

    return Response.json({
      success: true,
      stats,
      effects: Array.from(effects),
      equipped_items: equippedItems,
      total_value: totalTradeValue,
      item_count: inventoryItems?.length || 0,
    });
  } catch (error) {
    console.error('Stats calculation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});