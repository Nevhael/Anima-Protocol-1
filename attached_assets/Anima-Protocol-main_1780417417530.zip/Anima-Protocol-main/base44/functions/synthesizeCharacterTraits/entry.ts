import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id } = await req.json();

    if (!character_id) {
      return Response.json({ error: 'character_id required' }, { status: 400 });
    }

    // Fetch character data
    const character = await base44.entities.Character.list('-created_date', 1).then(chars => 
      chars.find(c => c.id === character_id)
    );

    if (!character) {
      return Response.json({ error: 'Character not found' }, { status: 404 });
    }

    // Fetch related data to research
    const [memories, relationships, journals] = await Promise.all([
      base44.entities.CharacterMemory?.filter?.({ character_id }, '-created_date', 20).catch(() => []),
      base44.entities.CharacterRelationship?.filter?.({ character_id }, '-created_date', 20).catch(() => []),
      base44.entities.CharacterJournal?.filter?.({ character_id }, '-created_date', 10).catch(() => []),
    ]);

    // Build research context
    const researchContext = `
CHARACTER: ${character.name}
Universe: ${character.universe || 'Original'}
Category: ${character.category || 'companion'}

PERSONALITY: ${character.personality || 'Unknown'}
BACKSTORY: ${character.backstory || 'Unknown'}
SPEAKING STYLE: ${character.speaking_style || 'Unknown'}

MEMORIES (Last 5):
${(memories || []).slice(0, 5).map(m => `- ${m.fact}`).join('\n')}

RELATIONSHIPS (Top 5):
${(relationships || []).slice(0, 5).map(r => `- Affinity: ${r.tier || 'neutral'} (${r.score || 0}/100)`).join('\n')}

JOURNAL ENTRIES (Last 3):
${(journals || []).slice(0, 3).map(j => `- [${j.emotional_tone}] ${j.title}`).join('\n')}
`;

    // Use LLM to synthesize traits
    const synthesis = await base44.integrations.Core.InvokeLLM({
      prompt: `Based on the following character research, synthesize their key personality traits, emotional drivers, and behavioral patterns. Be concise and specific.

${researchContext}

Provide a JSON object with these exact fields (array of strings for each):
- dominant_emotions: [list of primary emotions this character feels]
- speech_patterns: [list of distinctive speech patterns or verbal tics]
- motivations: [list of core driving motivations]
- vulnerabilities: [list of emotional or behavioral vulnerabilities]
- key_relationships: [list of important relationship dynamics]

Return ONLY the JSON object, no other text.`,
      response_json_schema: {
        type: 'object',
        properties: {
          dominant_emotions: { type: 'array', items: { type: 'string' } },
          speech_patterns: { type: 'array', items: { type: 'string' } },
          motivations: { type: 'array', items: { type: 'string' } },
          vulnerabilities: { type: 'array', items: { type: 'string' } },
          key_relationships: { type: 'array', items: { type: 'string' } },
        },
      },
    });

    return Response.json({
      traits: synthesis,
      character_id,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});