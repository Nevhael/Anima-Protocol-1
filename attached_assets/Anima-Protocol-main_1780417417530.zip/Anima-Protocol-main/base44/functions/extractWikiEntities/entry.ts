import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, recent_messages = [] } = await req.json();

    if (!session_id || recent_messages.length === 0) {
      return Response.json({ extracted: [] });
    }

    // Use LLM to extract entities from messages
    const messageText = recent_messages
      .map(m => `${m.character_name || 'User'}: ${m.content}`)
      .join('\n\n');

    const extractionPrompt = `Analyze this conversation and extract key entities, locations, events, and concepts for a world-building wiki.

Conversation:
${messageText}

Extract entities in JSON format. For each entity:
- name: the entity name
- entry_type: character, location, event, item, faction, concept, creature, or lore
- summary: 1-2 sentence description
- tags: 2-4 relevant tags
- lore_facts: 1-3 facts about this entity
- importance: minor, notable, major, or central

Return ONLY a valid JSON array. Example:
[
  {
    "name": "The Crystal Spire",
    "entry_type": "location",
    "summary": "An ancient magical tower of unknown origin",
    "tags": ["magic", "ancient", "tower"],
    "lore_facts": ["said to contain forbidden knowledge"],
    "importance": "major"
  }
]

Extract only new entities not yet mentioned in previous parts. Be selective - focus on named entities and significant concepts.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: extractionPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          entities: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                entry_type: {
                  type: 'string',
                  enum: ['character', 'location', 'event', 'item', 'faction', 'concept', 'creature', 'lore'],
                },
                summary: { type: 'string' },
                tags: { type: 'array', items: { type: 'string' } },
                lore_facts: { type: 'array', items: { type: 'string' } },
                importance: {
                  type: 'string',
                  enum: ['minor', 'notable', 'major', 'central'],
                },
              },
              required: ['name', 'entry_type'],
            },
          },
        },
        required: ['entities'],
      },
    });

    const entities = result?.entities || [];

    if (entities.length === 0) {
      return Response.json({ extracted: [] });
    }

    // Save extracted entities to WikiCodex
    const savedEntities = [];
    for (const entity of entities) {
      try {
        // Check if entry already exists
        const existing = await base44.entities.WikiCodex.filter({
          name: entity.name,
          entry_type: entity.entry_type,
        });

        if (existing?.length === 0) {
          // Only save if new
          const entry = await base44.entities.WikiCodex.create({
            name: entity.name,
            entry_type: entity.entry_type,
            summary: entity.summary,
            tags: entity.tags || [],
            lore_facts: entity.lore_facts || [],
            importance: entity.importance || 'notable',
            mention_count: 1,
            session_ids: [session_id],
            first_session_id: session_id,
            related_entries: [],
          });
          savedEntities.push(entry);
        } else {
          // Update mention count
          const existing_entry = existing[0];
          await base44.entities.WikiCodex.update(existing_entry.id, {
            mention_count: (existing_entry.mention_count || 0) + 1,
            session_ids: [...new Set([...(existing_entry.session_ids || []), session_id])],
          });
          savedEntities.push(existing_entry);
        }
      } catch (err) {
        console.error(`Error saving entity ${entity.name}:`, err);
      }
    }

    return Response.json({
      extracted: savedEntities,
      count: savedEntities.length,
    });
  } catch (error) {
    console.error('Wiki extraction error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});