import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_id,
      related_character_id,
      memory_types,
      limit = 10,
      session_id,
    } = await req.json();

    if (!character_id) {
      return Response.json({ error: 'character_id required' }, { status: 400 });
    }

    // Build query filter
    const filter = { character_id };
    if (memory_types?.length > 0) {
      filter.memory_type = { $in: memory_types };
    }
    if (related_character_id) {
      filter.related_character_id = related_character_id;
    }
    if (session_id) {
      // Exclude memories from current session for true "long-term" recall
      filter.session_ids = { $nin: [session_id] };
    }

    // Fetch memories
    const allMemories = await base44.entities.CrossSessionMemory.filter(filter, '-last_reinforced', 100);

    if (!allMemories || allMemories.length === 0) {
      return Response.json({ memories: [], total: 0 });
    }

    // Sort by relevance score and emotional weight
    const sorted = allMemories.sort((a, b) => {
      const relevanceDiff = (b.relevance_score || 0) - (a.relevance_score || 0);
      if (relevanceDiff !== 0) return relevanceDiff;
      return (b.emotional_weight || 0) - (a.emotional_weight || 0);
    });

    const memories = sorted.slice(0, limit);

    return Response.json({
      memories,
      total: allMemories.length,
      retrieved: memories.length,
    });
  } catch (error) {
    console.error('Memory retrieval error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});