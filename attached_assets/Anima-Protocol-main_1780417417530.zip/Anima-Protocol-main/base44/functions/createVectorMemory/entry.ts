import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_id,
      session_id,
      memory_type,
      title,
      content,
      related_characters,
      related_events,
      emotional_signature,
      relationship_deltas,
      narrative_significance,
    } = await req.json();

    if (!character_id || !session_id || !memory_type || !title || !content) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Generate embedding using LLM (semantic representation)
    const embeddingPrompt = `Generate a semantic embedding summary for this memory narrative. Return 5 key semantic dimensions as a JSON array of numbers (0-1 scale):
[emotional_intensity, narrative_importance, relationship_significance, character_growth, temporal_weight]

Memory:
${content}

Return only the JSON array.`;

    let embedding = null;
    try {
      const embeddingResult = await base44.integrations.Core.InvokeLLM({
        prompt: embeddingPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            dimensions: {
              type: 'array',
              items: { type: 'number' },
              minItems: 5,
              maxItems: 5
            }
          }
        }
      });
      embedding = embeddingResult?.dimensions || generateSimpleEmbedding(content);
    } catch {
      embedding = generateSimpleEmbedding(content);
    }

    // Create the vector memory
    const vectorMemory = await base44.entities.VectorMemory.create({
      character_id,
      session_id,
      memory_type,
      title,
      content,
      embedding,
      embedding_model: 'text-embedding-3-small',
      related_characters: related_characters || [],
      related_events: related_events || [],
      emotional_signature: emotional_signature || { primary_emotion: 'neutral', intensity: 5 },
      relationship_deltas: relationship_deltas || {},
      narrative_significance: narrative_significance || 0.5,
      last_recalled: new Date().toISOString(),
      recall_count: 0,
      similarity_matches: [],
    });

    // Find similar memories for cross-linking
    const allMemories = await base44.entities.VectorMemory.filter({
      character_id,
    }, '-created_date', 50);

    const similarMemories = [];
    if (allMemories && allMemories.length > 0) {
      for (const otherMem of allMemories) {
        if (otherMem.id !== vectorMemory.id && otherMem.embedding) {
          const similarity = calculateCosineSimilarity(embedding, otherMem.embedding);
          if (similarity > 0.6) {
            similarMemories.push({
              memory_id: otherMem.id,
              similarity_score: similarity,
            });
          }
        }
      }
    }

    // Update with similarity matches
    if (similarMemories.length > 0) {
      await base44.entities.VectorMemory.update(vectorMemory.id, {
        similarity_matches: similarMemories.slice(0, 5),
      });
    }

    return Response.json({
      memory: vectorMemory,
      similar_memories_found: similarMemories.length,
    });
  } catch (error) {
    console.error('Vector memory creation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function generateSimpleEmbedding(text) {
  // Fallback: simple TF-IDF-like embedding
  const words = text.toLowerCase().split(/\s+/);
  const freq = {};
  words.forEach(w => freq[w] = (freq[w] || 0) + 1);
  
  const dimensions = [
    Math.min(freq['love'] || freq['care'] || 0, 10) / 10,
    Math.min(freq['conflict'] || freq['fight'] || 0, 5) / 10,
    Math.min(freq['trust'] || freq['believe'] || 0, 10) / 10,
    Math.min(freq['grow'] || freq['learn'] || 0, 10) / 10,
    Math.min(text.length, 1000) / 1000,
  ];
  return dimensions;
}

function calculateCosineSimilarity(vec1, vec2) {
  const dotProduct = vec1.reduce((sum, val, i) => sum + val * (vec2[i] || 0), 0);
  const magnitude1 = Math.sqrt(vec1.reduce((sum, val) => sum + val * val, 0));
  const magnitude2 = Math.sqrt(vec2.reduce((sum, val) => sum + val * val, 0));
  return magnitude1 && magnitude2 ? dotProduct / (magnitude1 * magnitude2) : 0;
}