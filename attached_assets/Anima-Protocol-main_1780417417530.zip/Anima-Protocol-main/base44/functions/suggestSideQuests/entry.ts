import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const { session_id, character_id, recent_messages = [], inventory_items = [], lore_entries = [] } = await req.json();

    if (!session_id) return Response.json({ error: "Missing session_id" }, { status: 400 });

    // Pull unresolved lore mysteries (facts that hint at unanswered questions)
    const mysteries = lore_entries.filter(e =>
      e.fact && (
        /\?|unknown|mystery|hidden|secret|lost|forgotten|missing|rumor|legend|prophecy|curse/i.test(e.fact) ||
        e.importance === "critical"
      )
    ).slice(0, 8);

    // Pull notable inventory items (artifacts, keys, quest items, rare things)
    const notableItems = inventory_items.filter(i =>
      i.type === "artifact" || i.type === "key" || i.rarity === "rare" ||
      i.rarity === "legendary" || i.rarity === "epic" ||
      /key|map|scroll|relic|shard|fragment|stone|seal|tome|crystal/i.test(i.name || "")
    ).slice(0, 6);

    const narrativeSnippet = recent_messages
      .slice(-8)
      .map(m => `${m.character_name || (m.role === "user" ? "You" : "Character")}: ${(m.content || "").slice(0, 200)}`)
      .join("\n");

    const mysteryContext = mysteries.length > 0
      ? `\nUNRESOLVED LORE MYSTERIES:\n${mysteries.map(m => `- [${m.category}] ${m.subject}: ${m.fact}`).join("\n")}`
      : "";

    const inventoryContext = notableItems.length > 0
      ? `\nNOTABLE INVENTORY ITEMS:\n${notableItems.map(i => `- ${i.name} (${i.type || "item"}${i.rarity ? `, ${i.rarity}` : ""}): ${i.description || "no description"}`).join("\n")}`
      : "";

    const prompt = `You are a narrative game master analyzing an ongoing story to suggest compelling side quests.

RECENT NARRATIVE:
${narrativeSnippet}
${mysteryContext}
${inventoryContext}

Based on the narrative flow, unresolved mysteries, and the player's inventory, generate 2-3 side quest suggestions that would feel organic and rewarding right now.

Each side quest should:
- Connect directly to at least one lore mystery OR one inventory item (or both)
- Feel emergent from the current story moment, not random
- Have a clear hook that makes the player want to pursue it
- Be achievable within 1-3 story exchanges

Return a JSON object with this exact shape:
{
  "suggestions": [
    {
      "id": "sq_<unique 6 char hex>",
      "title": "Side quest title",
      "hook": "One compelling sentence that draws the player in",
      "description": "What this quest involves (2-3 sentences)",
      "trigger_source": "inventory" | "lore" | "both",
      "trigger_detail": "The specific item name or lore mystery that triggered this",
      "difficulty": "easy" | "moderate" | "hard",
      "estimated_exchanges": 2,
      "reward_hint": "Brief hint at what completing this might yield",
      "objectives": ["objective 1", "objective 2"]
    }
  ]
}`;

    const { InvokeLLM } = base44.asServiceRole.integrations.Core;
    const result = await InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          suggestions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "string" },
                title: { type: "string" },
                hook: { type: "string" },
                description: { type: "string" },
                trigger_source: { type: "string" },
                trigger_detail: { type: "string" },
                difficulty: { type: "string" },
                estimated_exchanges: { type: "number" },
                reward_hint: { type: "string" },
                objectives: { type: "array", items: { type: "string" } }
              }
            }
          }
        }
      }
    });

    const suggestions = result?.suggestions || [];

    return Response.json({ success: true, suggestions, count: suggestions.length });
  } catch (error) {
    console.error("suggestSideQuests error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});