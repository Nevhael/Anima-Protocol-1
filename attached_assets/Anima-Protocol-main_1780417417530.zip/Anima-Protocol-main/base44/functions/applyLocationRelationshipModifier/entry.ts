import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, character_id, with_character_id, current_location } = await req.json();

    if (!session_id || !character_id || !with_character_id) {
      return Response.json({ modifier: 0 });
    }

    // Get location significance
    let locationBonus = 0;
    if (current_location) {
      const locations = await base44.asServiceRole.entities.Location.filter({
        session_id,
        name: current_location,
      });

      if (locations && locations.length > 0) {
        const loc = locations[0];
        // Significant/intimate locations boost relationship changes
        if (loc.significance === 'critical' || loc.significance === 'major') {
          locationBonus = 1.5; // 50% boost to relationship deltas
        } else if (loc.significance === 'important') {
          locationBonus = 1.2; // 20% boost
        }
      }
    }

    // Get shared location history
    const char1Memories = await base44.asServiceRole.entities.CharacterMemory.filter({
      character_id,
      category: 'location_knowledge',
    }, '-created_date', 50);

    const char2Memories = await base44.asServiceRole.entities.CharacterMemory.filter({
      character_id: with_character_id,
      category: 'location_knowledge',
    }, '-created_date', 50);

    // Find shared locations
    const char1Locations = new Set((char1Memories || []).map(m => {
      const match = m.fact.match(/At (.*?):/);
      return match ? match[1] : null;
    }).filter(Boolean));

    const char2Locations = new Set((char2Memories || []).map(m => {
      const match = m.fact.match(/At (.*?):/);
      return match ? match[1] : null;
    }).filter(Boolean));

    const sharedLocations = Array.from(char1Locations).filter(loc =>
      char2Locations.has(loc)
    ).length;

    // Shared location history bonus: +0.1 per shared location (up to +0.5)
    const historyBonus = Math.min(sharedLocations * 0.1, 0.5);

    const totalModifier = 1 + historyBonus + (locationBonus - 1);

    return Response.json({
      success: true,
      location_significance_bonus: locationBonus - 1,
      shared_history_bonus: historyBonus,
      total_modifier: totalModifier,
      shared_locations: sharedLocations,
    });
  } catch (error) {
    console.error('Location relationship modifier error:', error);
    return Response.json({ modifier: 1, error: error.message });
  }
});