import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id } = await req.json();

    const [characters, locations, memories, relationships, worldState, events] = await Promise.all([
      base44.entities.Character.list("-created_date", 100),
      base44.entities.Location.list("-created_date", 100),
      base44.entities.VectorMemory.filter({ session_id }, "-created_date", 200),
      base44.entities.CharacterRelationship.filter({ session_id }, "-created_date", 100),
      base44.entities.WorldState.filter({ session_id }, "-created_date", 100),
      base44.entities.WorldSnapshot.filter({ session_id }, "-created_date", 50),
    ]);

    // Calculate influence scores
    const characterInfluence = {};
    (characters || []).forEach(char => {
      const charMemories = (memories || []).filter(m => m.character_id === char.id).length;
      const charRelationships = (relationships || []).filter(r => r.character_id === char.id).length;
      const charEvents = (worldState || []).filter(e => e.fact?.includes(char.name || '')).length;
      characterInfluence[char.id] = Math.min(100, (charMemories * 5) + (charRelationships * 10) + (charEvents * 8));
    });

    const locationInfluence = {};
    (locations || []).forEach(loc => {
      const locEvents = (worldState || []).filter(e => e.subject?.toLowerCase() === loc.name?.toLowerCase()).length;
      const locSnapshots = (events || []).filter(e => e.location_states?.some(ls => ls.name === loc.name)).length;
      locationInfluence[loc.id] = Math.min(100, (locEvents * 10) + (locSnapshots * 5));
    });

    // Build nodes
    const nodes = [
      ...(characters || []).map(char => ({
        id: char.id,
        label: char.name,
        type: 'character',
        influenceScore: characterInfluence[char.id] || 0,
        avatar: char.avatar_url,
      })),
      ...(locations || []).map(loc => ({
        id: loc.id,
        label: loc.name,
        type: 'location',
        influenceScore: locationInfluence[loc.id] || 0,
        category: loc.category,
        significantEvents: (worldState || []).filter(e => e.subject?.toLowerCase() === loc.name?.toLowerCase()),
      })),
    ];

    // Build edges
    const edges = [];
    (relationships || []).forEach(rel => {
      edges.push({
        id: `${rel.character_id}-${rel.id}`,
        source: rel.character_id,
        target: rel.id,
        weight: rel.score || 0,
        tier: rel.tier,
      });
    });

    // Character-location edges (if character visited/interacted with location)
    (memories || []).forEach(mem => {
      const relatedLoc = (locations || []).find(l => mem.title?.includes(l.name));
      if (relatedLoc) {
        edges.push({
          id: `${mem.character_id}-${relatedLoc.id}-mem`,
          source: mem.character_id,
          target: relatedLoc.id,
          weight: 50,
          type: 'memory',
        });
      }
    });

    return Response.json({
      nodes,
      edges,
      characterInfluence,
      locationInfluence,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});