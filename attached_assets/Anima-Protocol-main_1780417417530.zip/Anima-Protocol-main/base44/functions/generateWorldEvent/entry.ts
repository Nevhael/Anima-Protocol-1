import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { session_id, character_emotions, relationships } = await req.json();
    if (!session_id) return Response.json({ error: 'session_id required' }, { status: 400 });

    // Build context from emotions and relationships
    const emotionContext = Object.entries(character_emotions || {})
      .map(([charId, state]) => `- Character feeling ${state.emotion} (intensity ${state.intensity}%): ${state.trigger || 'unknown cause'}`)
      .join('\n');

    const relationshipContext = Object.entries(relationships || {})
      .map(([charId, rel]) => `- Relationship tier: ${rel.tier} (score ${rel.score}/100)`)
      .slice(0, 5) // Limit to 5 for context
      .join('\n');

    const eventPrompt = `You are a world event generator for a collaborative roleplay. Based on the current emotional atmosphere and character dynamics, generate ONE random world-altering event that will impact the story. The event should be:
- Unexpected but plausible given the current emotional state
- Dramatic enough to shift the narrative
- Tied to character relationships or emotional triggers
- A single sentence or two describing what happens

Current Character Emotions:
${emotionContext || '(none detected)'}

Current Relationships:
${relationshipContext || '(none detected)'}

Event Categories (pick one):
- Environmental: weather change, natural disaster, location shift
- Social: NPC arrival/departure, rumor spread, alliance offer
- Supernatural: premonition, strange phenomenon, magical effect
- Personal: betrayal revealed, secret exposed, realization hit
- External: threat emerges, opportunity appears, rescue arrives
- Temporal: time skip forward, flashback moment, prophecy triggered

Respond with JSON:
{
  "event_title": "short dramatic title (max 8 words)",
  "event_description": "1-2 sentence narrative description",
  "event_type": "one of the categories above",
  "urgency": "low|medium|high",
  "affects_all": true|false
}`;

    const event = await base44.integrations.Core.InvokeLLM({
      prompt: eventPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          event_title: { type: 'string' },
          event_description: { type: 'string' },
          event_type: { type: 'string' },
          urgency: { type: 'string' },
          affects_all: { type: 'boolean' }
        }
      }
    });

    return Response.json({
      event_title: event.event_title || 'World Shift',
      event_description: event.event_description || 'Something changes...',
      event_type: event.event_type || 'external',
      urgency: event.urgency || 'medium',
      affects_all: event.affects_all || false,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});