import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      agent_manifest,
      user_input,
      session_state,
      debug_mode = false,
    } = await req.json();

    if (!agent_manifest || !user_input) {
      return Response.json({ error: 'Missing agent_manifest or user_input' }, { status: 400 });
    }

    // Shadow Execution: Simulate agent without burning tokens
    const executionId = `shadow_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    const startTime = Date.now();

    // Step 1: Simulate PACT Propose phase
    const propose = {
      phase: 'propose',
      status: 'simulated',
      timestamp: new Date().toISOString(),
      input: user_input,
      capabilities_required: agent_manifest.capabilities || {},
    };

    // Step 2: Simulate Accept phase (no escrow lock)
    const accept = {
      phase: 'accept',
      status: 'simulated',
      escrow_locked: false, // Shadow mode: no real escrow
      confirmation_required: false,
    };

    // Step 3: Simulate Confirm phase (verifier check skipped)
    const confirm = {
      phase: 'confirm',
      status: 'simulated',
      verifier_network_called: false, // No real verifier calls
      consensus_required: false,
    };

    // Step 4: Simulate Act phase (execute logic without state mutations)
    const agentResponse = simulateAgentLogic(agent_manifest, user_input, session_state || {});

    const act = {
      phase: 'act',
      status: 'simulated',
      token_burned: 0, // Shadow mode: no tokens burned
      result: agentResponse,
      state_mutations: [], // No actual state changes
    };

    const executionTime = Date.now() - startTime;

    const shadowExecution = {
      execution_id: executionId,
      agent_name: agent_manifest.name,
      mode: 'shadow',
      duration_ms: executionTime,
      pact_phases: [propose, accept, confirm, act],
      telemetry: {
        user_input_tokens: user_input.split(' ').length,
        response_tokens: agentResponse.split(' ').length,
        latency_ms: executionTime,
      },
      debug: debug_mode ? {
        manifest_validated: validateManifest(agent_manifest),
        capabilities_available: Object.keys(agent_manifest.capabilities || {}),
        warnings: [],
      } : null,
    };

    return Response.json({
      success: true,
      execution: shadowExecution,
      ready_for_mainnet: executionTime < 5000 && agentResponse.length > 0,
    });
  } catch (error) {
    console.error('Shadow execution error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function simulateAgentLogic(manifest, userInput, sessionState) {
  const archetype = manifest.archetype || 'companion';
  const intent = manifest.intent || 'companion';

  // Simulate archetype-specific responses
  const responses = {
    serenity: `I sense your intention: "${userInput}". Let me reflect on this carefully and find peace in the response.`,
    wisdom: `This question aligns with the principle of ${intent}. My analysis suggests a thoughtful approach.`,
    warrior: `Challenge accepted. Your intention drives forward momentum toward ${intent}.`,
    muse: `Ah, how creative! Your words spark inspiration around "${intent}".`,
  };

  return responses[archetype] || `I understand: "${userInput}". How can I assist with ${intent}?`;
}

function validateManifest(manifest) {
  const required = ['name', 'archetype', 'intent'];
  const missingFields = required.filter(f => !manifest[f]);
  
  return {
    valid: missingFields.length === 0,
    missing: missingFields,
    has_pact_config: !!manifest.pactProtocol,
    has_security_config: !!manifest.security,
  };
}