import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_name,
      character_description,
      emotion,
      intensity,
      existing_avatar_url,
    } = await req.json();

    if (!character_name || !emotion) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    const emotionDescriptions = {
      joyful: "bright smile, sparkling eyes, relaxed posture, warm glow",
      calm: "serene expression, closed or peaceful eyes, steady gaze",
      sad: "downturned mouth, watery eyes, slumped shoulders, dim lighting",
      angry: "furrowed brows, clenched jaw, intense stare, red tones",
      afraid: "wide eyes, open mouth, trembling expression, tense posture",
      disgusted: "wrinkled nose, turned-away gaze, grimace",
      surprised: "wide eyes, raised eyebrows, open mouth, expressive",
      hopeful: "upward gaze, subtle smile, forward-leaning posture, soft light",
      conflicted: "divided expression, questioning eyes, hand to chin",
      desperate: "pleading eyes, reaching gesture, anguished expression",
    };

    const emotionDesc = emotionDescriptions[emotion] || emotionDescriptions.calm;
    const intensityLevel = intensity >= 7 ? "extremely" : intensity >= 4 ? "moderately" : "subtly";

    const prompt = `Generate a detailed character portrait for ${character_name}.

Character Background: ${character_description || 'A mysterious character'}
Current Emotional State: ${emotionDesc}
Intensity: ${intensityLevel}

${existing_avatar_url ? "This character already has an established visual style. Maintain consistency with their previous appearance while expressing the current emotion." : "Create a distinctive and memorable character design."}

Style: Detailed fantasy/game character portrait, expressive facial features, professional digital art quality.
Focus on conveying the emotional state clearly through facial expression, body language, and color/lighting.`;

    const result = await base44.integrations.Core.GenerateImage({
      prompt,
      existing_image_urls: existing_avatar_url ? [existing_avatar_url] : undefined,
    });

    return Response.json({
      success: true,
      portrait_url: result.url,
      emotion,
      intensity,
      character_name,
    });
  } catch (error) {
    console.error('Portrait generation error:', error);
    return Response.json(
      { error: error.message || 'Failed to generate portrait' },
      { status: 500 }
    );
  }
});