import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, recent_messages = [], character_emotions = {}, relationships = {}, world_state = {} } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    // Fetch current world state data
    const [loreEntries, factions, locations, calendar] = await Promise.all([
      base44.entities.WorldState.filter({ session_id, is_active: true }, "-created_date", 50),
      base44.entities.Faction.filter({ origin_session: session_id }, "-created_date", 20),
      base44.entities.Location.filter({}, "-created_date", 30),
      base44.entities.Calendar.filter({ session_id }, "-created_date", 1),
    ]);

    // Build context for headline generation
    const context = {
      recent_events: loreEntries?.slice(0, 5)?.map(e => `[${e.category}] ${e.subject}: ${e.fact}`) || [],
      active_factions: factions?.slice(0, 3)?.map(f => `${f.name} (${f.status})`) || [],
      key_locations: locations?.slice(0, 3)?.map(l => l.name) || [],
      season: calendar?.[0]?.current_season || "unknown",
      message_count: recent_messages?.length || 0,
      emotion_states: Object.entries(character_emotions || {})
        .slice(0, 3)
        .map(([charId, state]) => `${charId}: ${state.emotion} (intensity ${state.intensity})`)
        .join(", "),
      high_tension_relationships: Object.entries(relationships || {})
        .filter(([_, rel]) => Math.abs(rel.score) > 50)
        .slice(0, 2)
        .map(([charId, rel]) => `${charId}: ${rel.score > 0 ? 'positive' : 'negative'} (${Math.abs(rel.score)})`)
        .join(", "),
    };

    // Generate headlines using LLM
    const prompt = `Generate 3-5 procedural world pulse news headlines based on this world state. Each headline should:
1. Reference actual game events or emotional shifts
2. Sound like a news broadcast or narrative update
3. Include impact on the world (relationships, factions, locations)
4. Be brief (under 150 chars)
5. Use dramatic but fitting language

WORLD STATE:
- Recent Events: ${context.recent_events.join("; ") || "None recorded"}
- Active Factions: ${context.active_factions.join(", ") || "None"}
- Key Locations: ${context.key_locations.join(", ") || "None"}
- Current Season: ${context.season}
- Character Emotions: ${context.emotion_states || "Neutral"}
- Relationship Tensions: ${context.high_tension_relationships || "Stable"}
- Messages in Session: ${context.message_count}

Generate headlines as JSON array with objects containing:
{
  "type": "event|faction|landmark|conflict|discovery",
  "headline": "Short news headline",
  "description": "1-2 sentence impact description",
  "impact": "How this affects the world (1 line)"
}`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          headlines: {
            type: "array",
            items: {
              type: "object",
              properties: {
                type: { type: "string" },
                headline: { type: "string" },
                description: { type: "string" },
                impact: { type: "string" }
              }
            }
          }
        }
      }
    });

    const headlines = result?.headlines?.map((h, idx) => ({
      id: `pulse-${Date.now()}-${idx}`,
      ...h
    })) || [];

    return Response.json({ 
      success: true,
      headlines,
      generated_at: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error generating world pulse headlines:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});