import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, messages, force = false } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'session_id required' }, { status: 400 });
    }

    // Get all wiki entries for the user
    const allWikiEntries = await base44.asServiceRole.entities.WikiCodex.list('-updated_date', 1000);
    
    if (!allWikiEntries || allWikiEntries.length === 0) {
      return Response.json({ linked_messages: [], total_keywords: 0 });
    }

    // Build keyword index from wiki entries
    const keywordIndex = {};
    allWikiEntries.forEach(entry => {
      const names = [entry.name, ...(entry.related_entries || [])];
      names.forEach(name => {
        if (name && name.length > 2) {
          const key = name.toLowerCase();
          if (!keywordIndex[key]) {
            keywordIndex[key] = [];
          }
          keywordIndex[key].push({
            wiki_id: entry.id,
            wiki_name: entry.name,
            wiki_type: entry.entry_type,
            wiki_summary: entry.summary,
          });
        }
      });
    });

    // Process messages
    const messagesToProcess = messages || [];
    const linkedMessages = [];
    const foundKeywords = new Map();

    messagesToProcess.forEach((msg, idx) => {
      if (!msg.content || msg.role === 'system') return;

      const content = msg.content;
      const loreLinks = [];

      // Search for keywords (case-insensitive word boundary match)
      Object.entries(keywordIndex).forEach(([keyword, entries]) => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
        let match;
        
        while ((match = regex.exec(content)) !== null) {
          entries.forEach(entry => {
            loreLinks.push({
              keyword: match[0],
              position: match.index,
              wiki_id: entry.wiki_id,
              wiki_name: entry.wiki_name,
              wiki_type: entry.wiki_type,
              wiki_summary: entry.wiki_summary,
            });

            // Track found keywords
            const key = `${entry.wiki_id}`;
            if (!foundKeywords.has(key)) {
              foundKeywords.set(key, entry);
            }
          });
        }
      });

      // Deduplicate lore links by position and wiki_id
      const uniqueLinks = [];
      const seenPositions = new Set();
      
      loreLinks.sort((a, b) => a.position - b.position);
      loreLinks.forEach(link => {
        const linkKey = `${link.position}-${link.wiki_id}`;
        if (!seenPositions.has(linkKey)) {
          seenPositions.add(linkKey);
          uniqueLinks.push(link);
        }
      });

      if (uniqueLinks.length > 0) {
        linkedMessages.push({
          message_index: idx,
          character_name: msg.character_name,
          lore_links: uniqueLinks,
        });
      }
    });

    // Store lore link metadata on session
    await base44.asServiceRole.entities.ChatSession.update(session_id, {
      lore_links: {
        last_scanned: new Date().toISOString(),
        message_links: linkedMessages,
        unique_keywords: Array.from(foundKeywords.values()).map(e => ({
          wiki_id: e.wiki_id,
          wiki_name: e.wiki_name,
          wiki_type: e.wiki_type,
        })),
      },
    }).catch(err => console.error('Failed to update session with lore links:', err));

    return Response.json({
      success: true,
      linked_messages: linkedMessages,
      total_keywords: foundKeywords.size,
      keywords: Array.from(foundKeywords.values()),
    });
  } catch (error) {
    console.error('Error scanning lore keywords:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});