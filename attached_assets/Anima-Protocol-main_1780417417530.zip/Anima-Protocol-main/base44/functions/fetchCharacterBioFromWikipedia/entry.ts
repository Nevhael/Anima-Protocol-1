import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { character_name, character_universe } = await req.json();
    
    if (!character_name) {
      return Response.json({ error: 'character_name required' }, { status: 400 });
    }

    // Search for character information on Wikipedia
    const prompt = `Search for information about the character "${character_name}"${character_universe ? ` from ${character_universe}` : ''} on Wikipedia. Provide:
1. A brief personality description (2-3 sentences)
2. Key backstory elements (2-3 sentences)
3. Notable characteristics or quirks (1-2 sentences)
4. How they speak or communicate (1-2 sentences)

Format the response as a structured summary that can be used to populate character profile fields.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          personality: {
            type: "string",
            description: "Personality traits and characteristics"
          },
          backstory: {
            type: "string",
            description: "Key background information"
          },
          traits: {
            type: "string",
            description: "Notable characteristics or quirks"
          },
          speaking_style: {
            type: "string",
            description: "How the character communicates"
          },
          source: {
            type: "string",
            description: "Where the information came from (e.g., Wikipedia)"
          }
        }
      }
    });

    return Response.json({
      success: true,
      character_name,
      data: result
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});