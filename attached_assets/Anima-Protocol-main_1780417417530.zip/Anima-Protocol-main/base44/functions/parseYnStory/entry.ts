import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { content } = await req.json();

    if (!content || typeof content !== 'string') {
      return Response.json({ error: 'No content provided' }, { status: 400 });
    }

    // Parse the Y/n story format
    // Expected format: title at top, then narrative text
    // Can include [character]: dialogue or character-specific sections
    const lines = content.split('\n').map(l => l.trim()).filter(Boolean);
    
    if (lines.length === 0) {
      return Response.json({ error: 'Story content is empty' }, { status: 400 });
    }

    const title = lines[0].replace(/^#+\s*/, '').slice(0, 100) || 'Imported Y/n Story';
    
    // Extract character names from dialogue patterns like [Character]: text
    const characterPattern = /^\[([^\]]+)\]:/;
    const mentionedChars = new Set();
    
    lines.forEach(line => {
      const match = line.match(characterPattern);
      if (match) {
        mentionedChars.add(match[1]);
      }
    });

    // Convert story text into chat messages
    const messages = [];
    let currentSpeaker = 'Narrator';

    lines.forEach((line, idx) => {
      if (idx === 0) return; // Skip title

      const charMatch = line.match(characterPattern);
      
      if (charMatch) {
        currentSpeaker = charMatch[1];
        const dialogue = line.replace(characterPattern, '').trim();
        if (dialogue) {
          messages.push({
            role: 'assistant',
            character_name: currentSpeaker,
            content: dialogue,
            timestamp: new Date(Date.now() + idx * 1000).toISOString(),
          });
        }
      } else if (line) {
        // Narrative text
        messages.push({
          role: 'assistant',
          character_name: 'Narrator',
          content: line,
          timestamp: new Date(Date.now() + idx * 1000).toISOString(),
        });
      }
    });

    if (messages.length === 0) {
      return Response.json({ error: 'No parseable content found' }, { status: 400 });
    }

    // Create a new ChatSession with the parsed content
    const session = await base44.entities.ChatSession.create({
      title: title,
      mode: 'solo',
      messages: messages,
      last_message: messages[messages.length - 1]?.content.slice(0, 60) || '',
    });

    return Response.json({
      session_id: session.id,
      title: session.title,
      message_count: messages.length,
      characters_found: Array.from(mentionedChars),
    });
  } catch (error) {
    console.error('Error parsing Y/n story:', error);
    return Response.json(
      { error: error.message || 'Failed to parse story' },
      { status: 500 }
    );
  }
});