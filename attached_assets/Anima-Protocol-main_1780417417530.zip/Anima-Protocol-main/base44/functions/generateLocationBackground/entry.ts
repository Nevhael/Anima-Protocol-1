import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { location_name, world_state, character_name } = await req.json();
    
    if (!location_name) {
      return Response.json({ error: 'location_name required' }, { status: 400 });
    }

    // Build a rich visual prompt from the location and world context
    const loreContext = world_state?.loreEntries?.slice(0, 3).map(e => e.fact).join('. ') || '';
    const seasonContext = world_state?.calendar?.current_season ? `It's ${world_state.calendar.current_season}. ` : '';
    const weatherContext = world_state?.calendar?.weather ? `Weather: ${world_state.calendar.weather}. ` : '';

    const prompt = `A cinematic, atmospheric scene of: ${location_name}. ${seasonContext}${weatherContext}${loreContext ? `Context: ${loreContext}. ` : ''}Immersive fantasy/storytelling art style, moody lighting, rich colors, high detail, suitable as an immersive chat background. Do not include text.`;

    // Generate the image
    const imageRes = await base44.integrations.Core.GenerateImage({
      prompt,
    });

    if (!imageRes?.url) {
      return Response.json({ error: 'Failed to generate image' }, { status: 500 });
    }

    return Response.json({
      success: true,
      location: location_name,
      background_url: imageRes.url,
      prompt: prompt,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});