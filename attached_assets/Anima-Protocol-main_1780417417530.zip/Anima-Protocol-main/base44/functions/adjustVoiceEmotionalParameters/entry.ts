import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Dynamically adjusts ElevenLabs voice parameters (pitch, stability) based on character's emotional state.
 * Maps emotions to voice profile adjustments for natural emotional expression.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id, emotion, intensity = 5 } = await req.json();

    if (!character_id || !emotion) {
      return Response.json({ error: 'Missing character_id or emotion' }, { status: 400 });
    }

    // Get character and their voice settings
    const character = await base44.asServiceRole.entities.Character.list()
      .then(chars => chars.find(c => c.id === character_id));

    if (!character || !character.elevenlabs_voice_id) {
      return Response.json({ error: 'Character or voice ID not found' }, { status: 404 });
    }

    // Emotional voice profiles: adjust pitch and stability based on emotion
    const emotionalProfiles = {
      calm: { pitch: 1.0, stability: 0.85, energy: 0.6 },
      joyful: { pitch: 1.15, stability: 0.92, energy: 0.9 },
      anxious: { pitch: 1.25, stability: 0.65, energy: 0.75 }, // Higher pitch, less stable
      excited: { pitch: 1.3, stability: 0.7, energy: 1.0 }, // Much higher pitch, dynamic
      sad: { pitch: 0.85, stability: 0.75, energy: 0.4 },
      angry: { pitch: 0.9, stability: 0.7, energy: 0.95 },
      peaceful: { pitch: 0.95, stability: 0.88, energy: 0.5 },
      hopeful: { pitch: 1.1, stability: 0.85, energy: 0.8 },
      conflicted: { pitch: 1.0, stability: 0.6, energy: 0.65 },
      neutral: { pitch: 1.0, stability: 0.75, energy: 0.6 },
    };

    const baseProfile = emotionalProfiles[emotion] || emotionalProfiles.neutral;

    // Scale adjustments by intensity (1-10)
    const intensityFactor = intensity / 5; // Normalize to 0.2-2.0

    // Apply intensity scaling to pitch and stability variance
    const pitch = 1 + ((baseProfile.pitch - 1) * intensityFactor);
    const stability = Math.max(0.3, Math.min(1, baseProfile.stability - (0.1 * intensityFactor)));
    const energy = baseProfile.energy * (0.7 + (intensityFactor * 0.3));

    return Response.json({
      voice_id: character.elevenlabs_voice_id,
      character_name: character.name,
      emotion,
      intensity,
      voice_settings: {
        pitch: Math.round(pitch * 100) / 100, // Normalize to 2 decimals
        stability: Math.round(stability * 100) / 100,
        speaker_boost: energy > 0.8,
        style: intensity > 7 ? 0.5 : 0, // Add style intensity for high emotions
      },
      metadata: {
        emotion_profile: baseProfile,
        applied_intensity: intensityFactor,
      },
    });
  } catch (error) {
    console.error('Voice emotional parameter adjustment error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});