import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { character_id, session_id, character_name, user_message, ai_response, existing_journals } = body;

    if (!character_id || !session_id || !character_name) {
      return Response.json({ skipped: true, reason: 'Missing required fields' });
    }

    // Fetch the character to get personality context
    const char = await base44.asServiceRole.entities.Character.filter({ id: character_id });
    const character = char?.[0];

    // Don't create a journal on every message — only periodically (check existing count per session)
    const journalsThisSession = await base44.asServiceRole.entities.CharacterJournal.filter({
      character_id,
      session_id
    });

    // Allow max 2 journals per session (e.g., one at midpoint, one at end)
    if ((journalsThisSession || []).length >= 2) {
      return Response.json({ skipped: true, reason: 'Journal limit reached for this session' });
    }

    // Fetch recent world state facts to give context
    const worldFacts = await base44.asServiceRole.entities.WorldState.filter(
      { session_id, is_active: true },
      '-created_date',
      15
    );

    const worldContext = (worldFacts || [])
      .map(f => `[${f.category}] ${f.subject}: ${f.fact}`)
      .join('\n');

    const prompt = `You are ${character_name}. Based on recent story events, write a personal journal entry from this character's perspective.

CHARACTER CONTEXT:
${character?.personality ? `Personality: ${character.personality}` : ''}
${character?.backstory ? `Backstory: ${character.backstory}` : ''}

RECENT WORLD EVENTS:
${worldContext || '(no major events logged)'}

LATEST EXCHANGE:
Player: "${user_message}"
${character_name}: "${ai_response.slice(0, 500)}"

Write an introspective, first-person journal entry (2-3 paragraphs) as if ${character_name} is reflecting privately on:
1. What just happened and how they feel about it
2. How this affected their relationships with others
3. What they've realized or learned
4. Their concerns or hopes for the future

The entry should feel personal and authentic to this character's voice. Use their unique vocabulary, concerns, and worldview.

Return JSON:
{
  "title": "Brief, poetic title (max 8 words)",
  "emotional_tone": "one of: hopeful, melancholic, angry, reflective, anxious, peaceful, confused",
  "content": "Full 2-3 paragraph journal entry",
  "key_moments": ["moment 1", "moment 2", "moment 3"],
  "character_insights": "One sentence: what this character learned",
  "relationships_affected": [
    { "character_name": "other char", "change": "how relationship shifted" }
  ]
}`;

    const analysis = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          emotional_tone: { type: 'string' },
          content: { type: 'string' },
          key_moments: { type: 'array', items: { type: 'string' } },
          character_insights: { type: 'string' },
          relationships_affected: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                character_name: { type: 'string' },
                change: { type: 'string' }
              }
            }
          }
        }
      }
    });

    if (!analysis?.content) {
      return Response.json({ skipped: true, reason: 'No content generated' });
    }

    // Resolve character names to IDs for relationships
    const relationships_affected = [];
    if (analysis.relationships_affected?.length) {
      const allChars = await base44.asServiceRole.entities.Character.list('-created_date', 100);
      for (const rel of analysis.relationships_affected) {
        const targetChar = allChars.find(c => c.name?.toLowerCase() === rel.character_name?.toLowerCase());
        if (targetChar) {
          relationships_affected.push({
            character_id: targetChar.id,
            change: rel.change
          });
        }
      }
    }

    const record = await base44.asServiceRole.entities.CharacterJournal.create({
      character_id,
      session_id,
      title: analysis.title || 'Untitled Entry',
      content: analysis.content,
      emotional_tone: analysis.emotional_tone || 'reflective',
      key_moments: analysis.key_moments || [],
      character_insights: analysis.character_insights || '',
      perspective: 'first_person',
      relationships_affected
    });

    return Response.json({
      created: true,
      journal_id: record.id,
      title: record.title,
      emotional_tone: record.emotional_tone
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});