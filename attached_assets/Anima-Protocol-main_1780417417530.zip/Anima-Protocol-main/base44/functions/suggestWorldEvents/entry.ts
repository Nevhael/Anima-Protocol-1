import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id } = await req.json();
    
    if (!session_id) {
      return Response.json({ error: 'session_id required' }, { status: 400 });
    }

    // Fetch session data
    const sessions = await base44.entities.ChatSession.filter({ id: session_id });
    if (!sessions || sessions.length === 0) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    const session = sessions[0];
    const messages = session.messages || [];
    
    if (messages.length < 5) {
      return Response.json({ success: true, suggestions: [] });
    }

    // Get recent context
    const recentMessages = messages.slice(-15);
    const messageText = recentMessages
      .map(m => `${m.character_name || 'User'}: ${m.content}`)
      .join('\n');

    // Fetch character emotions and relationships for context
    const [emotionalStates, relationships, loreEntries] = await Promise.all([
      base44.entities.CharacterEmotionalState.filter({ session_id, is_current: true }),
      base44.entities.CharacterRelationship.filter({ session_id }),
      base44.entities.WorldState.filter({ session_id, is_active: true }, "-created_date", 20),
    ]);

    // Build context for event generation
    const emotionSummary = emotionalStates
      .map(e => `${e.character_id}: ${e.primary_emotion} (${e.intensity}%)`)
      .join(', ');

    const relationshipSummary = relationships
      .slice(0, 5)
      .map(r => `Character ${r.character_id}: ${r.tier} (${r.score})`)
      .join(', ');

    const loreContext = loreEntries
      .slice(0, 5)
      .map(l => `${l.subject}: ${l.fact}`)
      .join('; ');

    const prompt = `Analyze this roleplay narrative and suggest 3 distinct world-shaping events that would create meaningful consequences.

RECENT NARRATIVE:
${messageText}

CHARACTER EMOTIONAL STATES:
${emotionSummary || 'None recorded'}

CHARACTER RELATIONSHIPS:
${relationshipSummary || 'None recorded'}

ESTABLISHED LORE:
${loreContext || 'None yet'}

Generate 3 different world events that:
1. Respond naturally to character actions and emotions
2. Create narrative tension or new opportunities
3. Have different impact scales (personal, faction-level, world-level)
4. Feel organic to the established story

Each event should feel like a natural consequence of the narrative flow, not random chaos.`;

    const eventSuggestions = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          events: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: {
                  type: "string",
                  description: "Short event title"
                },
                description: {
                  type: "string",
                  description: "Full event description and consequences"
                },
                event_type: {
                  type: "string",
                  enum: ["environmental", "social", "supernatural", "personal", "external", "temporal"],
                  description: "Type of event"
                },
                impact_scale: {
                  type: "string",
                  enum: ["personal", "faction", "world"],
                  description: "Who/what is affected"
                },
                urgency: {
                  type: "string",
                  enum: ["low", "medium", "high"],
                  description: "How urgent is this event"
                },
                affected_characters: {
                  type: "array",
                  items: { type: "string" },
                  description: "Character IDs affected by this event"
                },
                narrative_hook: {
                  type: "string",
                  description: "How to introduce this into the story"
                }
              }
            }
          }
        }
      }
    });

    return Response.json({
      success: true,
      session_id,
      suggestions: eventSuggestions.events || [],
      count: (eventSuggestions.events || []).length
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});