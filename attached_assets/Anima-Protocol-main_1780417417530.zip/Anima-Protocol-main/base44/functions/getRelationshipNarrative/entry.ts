import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { character_a_id, character_b_id } = await req.json();

    if (!character_a_id || !character_b_id) {
      return Response.json({ error: 'Both character IDs required' }, { status: 400 });
    }

    // Normalize IDs
    const [charA, charB] = [character_a_id, character_b_id].sort();

    // Fetch relationship history
    const relHistory = await base44.entities.RelationshipHistory.filter({
      character_a_id: charA,
      character_b_id: charB,
    });

    if (!relHistory || relHistory.length === 0) {
      return Response.json({
        narrative: 'No relationship history found.',
        has_history: false,
      });
    }

    const rel = relHistory[0];
    const charAName = character_a_id === charA ? 'They' : 'They';
    const charBName = character_b_id === charA ? 'They' : 'They';

    // Build narrative from relationship data
    let narrative = '';

    // Arc summary
    narrative += `\n=== RELATIONSHIP ARC ===\n`;
    narrative += `Status: ${rel.relationship_arc || 'Unknown'}\n`;
    narrative += `Current Score: ${rel.current_score}/100\n`;
    narrative += `Trust Level: ${((rel.trust_level || 0) * 100).toFixed(0)}%\n`;
    narrative += `Sessions Together: ${rel.session_ids?.length || 0}\n\n`;

    // Recent trajectory
    if (rel.score_history && rel.score_history.length > 0) {
      narrative += `=== TRAJECTORY ===\n`;
      const recent = rel.score_history.slice(-3);
      recent.forEach((entry, idx) => {
        const sign = entry.delta > 0 ? '+' : '';
        narrative += `Session ${idx + 1}: ${sign}${entry.delta} (${entry.catalyst || 'interaction'})\n`;
      });
      narrative += '\n';
    }

    // Turning points
    if (rel.key_turning_points && rel.key_turning_points.length > 0) {
      narrative += `=== PIVOTAL MOMENTS ===\n`;
      rel.key_turning_points.forEach(point => {
        const sign = point.impact > 0 ? '+' : '';
        narrative += `[${point.description}] Impact: ${sign}${point.impact}\n`;
      });
      narrative += '\n';
    }

    // Recurring themes
    if (rel.recurring_themes && rel.recurring_themes.length > 0) {
      narrative += `=== PATTERNS IN THEIR BOND ===\n`;
      narrative += rel.recurring_themes.map(t => `• ${t.replace(/-/g, ' ')}`).join('\n');
      narrative += '\n\n';
    }

    // Generate emotional context using AI
    try {
      const contextPrompt = `Generate a brief (2-3 sentences) emotional narrative summary of this relationship:
      
Arc: ${rel.relationship_arc}
Score: ${rel.current_score}
Trust: ${(rel.trust_level * 100).toFixed(0)}%
Themes: ${(rel.recurring_themes || []).join(', ')}
Turning Points: ${(rel.key_turning_points || []).slice(0, 2).map(p => p.description).join(', ')}

Make it personal and emotionally resonant. Format as dialogue from one character's perspective.`;

      const contextResult = await base44.integrations.Core.InvokeLLM({
        prompt: contextPrompt,
      });

      narrative += `=== EMOTIONAL REALITY ===\n${contextResult}\n`;
    } catch (e) {
      console.error('Context generation failed:', e);
    }

    return Response.json({
      narrative: narrative.trim(),
      metadata: {
        relationship_id: rel.id,
        current_score: rel.current_score,
        arc: rel.relationship_arc,
        trust_level: rel.trust_level,
        interaction_count: rel.interaction_count,
        turning_points_count: rel.key_turning_points?.length || 0,
        themes: rel.recurring_themes || [],
      },
    });
  } catch (error) {
    console.error('Relationship narrative error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});