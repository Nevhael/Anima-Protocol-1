import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();
  if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const { character_id, session_id, user_message, ai_response, existing_items, message_index } = await req.json();

  if (!character_id) return Response.json({ error: 'character_id required' }, { status: 400 });

  const existingList = (existing_items || [])
    .map(i => `- ${i.name} (${i.type}, qty: ${i.quantity}${i.equipped ? ', equipped' : ''})`)
    .join('\n') || 'None';

  const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
    prompt: `You are an inventory tracker for a roleplay session. Analyze this exchange and determine if any items were gained, lost, consumed, equipped, or unequipped.

CURRENT INVENTORY:
${existingList}

USER: ${user_message}
CHARACTER RESPONSE: ${ai_response}

Extract ONLY clearly mentioned inventory changes. Do not invent items not referenced in the text.

Return a JSON object with an "events" array. Each event has:
- action: "add" | "remove" | "consume" | "equip" | "unequip" | "update_qty"
- name: item name (string)
- type: "gear" | "consumable" | "weapon" | "armor" | "artifact" | "misc"
- quantity: number (default 1)
- description: brief item description (only for new adds)
- rarity: "common" | "uncommon" | "rare" | "legendary" (only for new adds, default "common")
- slot: "head"|"chest"|"hands"|"feet"|"weapon"|"offhand"|"accessory"|"none" (for gear/weapons only)

If nothing changed, return {"events": []}.`,
    response_json_schema: {
      type: 'object',
      properties: {
        events: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              action: { type: 'string' },
              name: { type: 'string' },
              type: { type: 'string' },
              quantity: { type: 'number' },
              description: { type: 'string' },
              rarity: { type: 'string' },
              slot: { type: 'string' }
            }
          }
        }
      }
    }
  });

  const events = result?.events || [];
  if (!events.length) return Response.json({ applied: 0 });

  // Fetch current inventory for this character
  const currentItems = await base44.asServiceRole.entities.Inventory.filter({ character_id });

  let applied = 0;

  for (const ev of events) {
    const existing = currentItems.find(i => i.name.toLowerCase() === ev.name.toLowerCase());

    if (ev.action === 'add') {
      if (!existing) {
        await base44.asServiceRole.entities.Inventory.create({
          character_id,
          session_id: session_id || null,
          name: ev.name,
          type: ev.type || 'misc',
          quantity: ev.quantity || 1,
          description: ev.description || '',
          rarity: ev.rarity || 'common',
          slot: ev.slot || 'none',
          equipped: false,
          source_message_index: message_index || 0
        });
        applied++;
      } else {
        await base44.asServiceRole.entities.Inventory.update(existing.id, {
          quantity: (existing.quantity || 1) + (ev.quantity || 1)
        });
        applied++;
      }
    } else if (ev.action === 'remove' && existing) {
      await base44.asServiceRole.entities.Inventory.delete(existing.id);
      applied++;
    } else if (ev.action === 'consume' && existing) {
      const newQty = (existing.quantity || 1) - (ev.quantity || 1);
      if (newQty <= 0) {
        await base44.asServiceRole.entities.Inventory.delete(existing.id);
      } else {
        await base44.asServiceRole.entities.Inventory.update(existing.id, { quantity: newQty });
      }
      applied++;
    } else if (ev.action === 'equip' && existing) {
      await base44.asServiceRole.entities.Inventory.update(existing.id, { equipped: true });
      applied++;
    } else if (ev.action === 'unequip' && existing) {
      await base44.asServiceRole.entities.Inventory.update(existing.id, { equipped: false });
      applied++;
    } else if (ev.action === 'update_qty' && existing) {
      await base44.asServiceRole.entities.Inventory.update(existing.id, { quantity: ev.quantity || existing.quantity });
      applied++;
    }
  }

  return Response.json({ applied, events });
});