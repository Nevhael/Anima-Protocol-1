import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { recent_messages, session_context, character_emotions } = await req.json();

    if (!recent_messages || recent_messages.length === 0) {
      return Response.json({ world_elements: [], event_suggestions: [] });
    }

    const conversationText = recent_messages
      .slice(-6)
      .map((m) => `${m.character_name || 'User'}: ${m.content}`)
      .join('\n');

    // Detect world-building elements
    const worldPrompt = `Analyze this narrative for NEW world-building details (locations, objects, concepts, factions, rules, history):

${conversationText}

${character_emotions ? `Character Emotional Context: ${JSON.stringify(character_emotions)}` : ''}

List ONLY truly new discoveries (not things already established). For each:
1. Category (location/item/faction/concept/rule/history)
2. Subject (the name/concept)
3. Fact (what we learned about it)

Format as JSON array: [{"category": "...", "subject": "...", "fact": "..."}]`;

    // Suggest next narrative events
    const eventPrompt = `Based on this narrative moment, suggest 1-2 compelling next story events that would naturally follow:

${conversationText}

${session_context ? `Story Context: ${session_context}` : ''}

For each event suggest:
1. Title (short, dramatic)
2. Description (what happens)
3. Type (action/discovery/conflict/mystery/revelation)
4. Impact scale (minor/moderate/major)
5. Narrative hook (how to introduce it)

Format as JSON: [{"title": "...", "description": "...", "type": "...", "impact_scale": "...", "narrative_hook": "..."}]`;

    const [worldResult, eventResult] = await Promise.all([
      base44.integrations.Core.InvokeLLM({
        prompt: worldPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            discoveries: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  category: { type: 'string' },
                  subject: { type: 'string' },
                  fact: { type: 'string' },
                },
              },
            },
          },
        },
      }),
      base44.integrations.Core.InvokeLLM({
        prompt: eventPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            suggestions: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  description: { type: 'string' },
                  type: { type: 'string' },
                  impact_scale: { type: 'string' },
                  narrative_hook: { type: 'string' },
                },
              },
            },
          },
        },
      }),
    ]);

    return Response.json({
      world_elements: worldResult.discoveries || [],
      event_suggestions: eventResult.suggestions || [],
    });
  } catch (error) {
    console.error('Narrative analysis error:', error);
    return Response.json({
      world_elements: [],
      event_suggestions: [],
    });
  }
});