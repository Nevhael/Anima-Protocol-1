import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      session_id,
      user_action,
      characters,
      current_world_state,
      recent_events,
    } = await req.json();

    if (!session_id || !user_action) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    const worldState = current_world_state || {};
    const recentContext = recent_events?.slice(-3).map(e => e.subject).join(', ') || 'early game';

    const prompt = `Based on user action and current world state, procedurally generate new game content:

User Action: ${user_action}
Recent World Events: ${recentContext}
Current Characters: ${characters?.map(c => c.name).join(', ') || 'none yet'}

Generate ALL THREE of the following as JSON:

1. **NEW LORE ENTRY** - A world fact/history/rule discovered
2. **NEW FACTION** - A group, organization, or power structure
3. **NEW LANDMARK** - A location of significance

Each should:
- Be inspired by user action and existing world elements
- Be concise but vivid
- Feel organic to the narrative
- Include interconnections with existing elements

Return ONLY this JSON structure (no markdown):
{
  "lore": {
    "subject": "What is this fact about",
    "fact": "The actual lore fact/description",
    "category": "history|rule|artifact|civilization",
    "importance": "low|medium|high|critical"
  },
  "faction": {
    "name": "Faction Name",
    "description": "Who they are and what they do",
    "goals": ["goal1", "goal2"],
    "power_level": 5,
    "status": "emerging|established|rising|declining"
  },
  "landmark": {
    "name": "Landmark Name",
    "description": "Visual and atmospheric description",
    "category": "city|dungeon|wilderness|building|sacred_site|settlement",
    "x_coord": 45,
    "y_coord": 60,
    "significance": "minor|important|major|critical"
  }
}`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          lore: {
            type: "object",
            properties: {
              subject: { type: "string" },
              fact: { type: "string" },
              category: { type: "string" },
              importance: { type: "string" },
            },
          },
          faction: {
            type: "object",
            properties: {
              name: { type: "string" },
              description: { type: "string" },
              goals: { type: "array", items: { type: "string" } },
              power_level: { type: "number" },
              status: { type: "string" },
            },
          },
          landmark: {
            type: "object",
            properties: {
              name: { type: "string" },
              description: { type: "string" },
              category: { type: "string" },
              x_coord: { type: "number" },
              y_coord: { type: "number" },
              significance: { type: "string" },
            },
          },
        },
      },
    });

    const generated = { lore: null, faction: null, landmark: null };

    try {
      // Save lore entry
      if (result?.lore) {
        generated.lore = await base44.entities.WorldState.create({
          session_id,
          category: result.lore.category,
          subject: result.lore.subject,
          fact: result.lore.fact,
          importance: result.lore.importance,
          is_active: true,
          source_message_index: 0,
        });
      }

      // Save faction
      if (result?.faction) {
        generated.faction = await base44.entities.Faction.create({
          name: result.faction.name,
          description: result.faction.description,
          origin_session: session_id,
          goals: result.faction.goals || [],
          power_level: result.faction.power_level,
          status: result.faction.status,
          generated: true,
        });
      }

      // Save landmark
      if (result?.landmark) {
        generated.landmark = await base44.entities.Location.create({
          name: result.landmark.name,
          description: result.landmark.description,
          x_coord: result.landmark.x_coord,
          y_coord: result.landmark.y_coord,
          category: result.landmark.category,
          significance: result.landmark.significance,
          visited: false,
          icon_emoji: "🏛️",
        });
      }
    } catch (err) {
      console.error('Error saving generated content:', err);
    }

    return Response.json({
      success: true,
      lore: generated.lore,
      faction: generated.faction,
      landmark: generated.landmark,
    });
  } catch (error) {
    console.error('World generation error:', error);
    return Response.json(
      { error: error.message || 'Failed to generate world content' },
      { status: 500 }
    );
  }
});