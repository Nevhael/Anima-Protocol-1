import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { session_id, character_id, message_content, ai_response } = await req.json();

    if (!session_id || !character_id) {
      return Response.json({
        error: "Missing session_id or character_id",
      }, { status: 400 });
    }

    // Keywords that trigger item acquisition
    const itemKeywords = {
      // Equipment acquisition
      "found": { type: "gear", pattern: /found\s+(?:a\s+)?(.+?)(?:\s+(?:in|on|at|near))/ },
      "discovered": { type: "artifact", pattern: /discovered\s+(?:a\s+)?(.+?)(?:\s+in|$)/ },
      "acquired": { type: "gear", pattern: /acquired\s+(?:a\s+)?(.+?)(?:\s+from)/ },
      "received": { type: "gear", pattern: /received\s+(?:a\s+)?(.+?)(?:\s+(?:from|as))/ },
      "obtained": { type: "gear", pattern: /obtained\s+(?:a\s+)?(.+?)(?:\s+from)/ },
      "picked up": { type: "gear", pattern: /picked\s+up\s+(?:a\s+)?(.+?)(?:\s+(?:in|from|at))/ },
      "sword": { type: "weapon", pattern: /(?:wield|grab|draw)(?:s)?\s+(?:a\s+)?(.+?\s+sword)/ },
      "shield": { type: "armor", pattern: /(?:equip|raise|take)(?:s)?\s+(?:a\s+)?(.+?\s+shield)/ },
      "potion": { type: "consumable", pattern: /(?:drink|consume|take)(?:s)?\s+(?:a\s+)?(.+?\s+potion)/ },
      "artifact": { type: "artifact", pattern: /(?:wielding|holding|carrying)\s+(?:a\s+)?(.+?\s+artifact)/ },
    };

    // Scan both the user message and AI response for item acquisition
    const fullText = `${message_content} ${ai_response}`.toLowerCase();
    const acquiredItems = [];

    for (const [keyword, { type, pattern }] of Object.entries(itemKeywords)) {
      if (fullText.includes(keyword)) {
        const matches = fullText.matchAll(pattern);
        for (const match of matches) {
          const itemName = match[1]?.trim();
          if (itemName && itemName.length < 100) {
            // Avoid false positives
            acquiredItems.push({
              name: itemName.charAt(0).toUpperCase() + itemName.slice(1),
              type,
              rarity: "common",
              quantity: 1,
              description: `Acquired during the narrative`,
              equipped: false,
              slot: type === "weapon" ? "weapon" : type === "armor" ? "chest" : "none",
            });
          }
        }
      }
    }

    // Check for special patterns (e.g., "gained 3 gold coins")
    const quantityMatch = fullText.match(/(?:gained|found|received|looted)\s+(\d+)\s+([a-zA-Z\s]+)(?:\s+(?:coin|item))?/);
    if (quantityMatch) {
      acquiredItems.push({
        name: quantityMatch[2].trim(),
        type: "consumable",
        rarity: "common",
        quantity: parseInt(quantityMatch[1]),
        description: "Looted during adventure",
        equipped: false,
        slot: "none",
      });
    }

    // Deduplicate items by name
    const uniqueItems = [];
    const seen = new Set();
    for (const item of acquiredItems) {
      const key = item.name.toLowerCase();
      if (!seen.has(key)) {
        uniqueItems.push(item);
        seen.add(key);
      }
    }

    // Create inventory entries
    const created = [];
    for (const itemData of uniqueItems) {
      try {
        const newItem = await base44.entities.Inventory.create({
          ...itemData,
          character_id,
          session_id,
        });
        created.push(newItem);
      } catch (err) {
        console.error("Error creating item:", err);
      }
    }

    return Response.json({
      success: true,
      items_acquired: uniqueItems.length,
      created: created,
      detected_items: uniqueItems,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});