import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { session_id, user_message, ai_response, message_index, existing_facts } = await req.json();
    if (!session_id) return Response.json({ error: 'session_id required' }, { status: 400 });

    const existingList = (existing_facts || [])
      .map((f, i) => `${i + 1}. [${f.category}] ${f.subject}: ${f.fact}`)
      .join("\n");

    const analysis = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a narrative lore extractor for a collaborative roleplay story. Analyze the latest exchange and extract NEW facts that should be remembered for future sessions.

Latest player message: "${user_message}"
Character's reply: "${(ai_response || '').slice(0, 600)}"

Already known facts (do NOT repeat or paraphrase these):
${existingList || "(none yet)"}

Extract only NEW, story-critical facts worth remembering:
- Named items introduced, acquired, or destroyed
- Locations visited or revealed
- Secrets or revelations disclosed
- Alliances formed or broken
- Major character decisions with lasting consequences
- Relationship changes (bonds, betrayals, vows)
- Rules or laws of the world established
- Deaths, births, transformations

SKIP mundane conversational exchanges. SKIP anything already in the known facts list.

Return JSON:
{
  "entries": [
    {
      "category": "character_fact"|"item"|"location"|"event"|"relationship"|"secret"|"rule",
      "subject": "name of person/place/thing",
      "fact": "concise specific statement (max 25 words)",
      "importance": "low"|"medium"|"high"|"critical"
    }
  ]
}

Return empty entries array if nothing new and significant happened.`,
      response_json_schema: {
        type: "object",
        properties: {
          entries: {
            type: "array",
            items: {
              type: "object",
              properties: {
                category: { type: "string" },
                subject: { type: "string" },
                fact: { type: "string" },
                importance: { type: "string" }
              }
            }
          }
        }
      }
    });

    const entries = (analysis.entries || []).filter(e => e.fact && e.fact.trim());
    const created = [];

    for (const entry of entries) {
      // Dedup check: skip if a very similar fact already exists for this session
      const existing = await base44.asServiceRole.entities.WorldState.filter({
        session_id,
        subject: entry.subject,
        category: entry.category
      });

      // Simple string similarity: skip if fact shares >60% words with an existing one
      const isDuplicate = (existing || []).some(e => {
        const aWords = new Set(e.fact.toLowerCase().split(/\W+/));
        const bWords = entry.fact.toLowerCase().split(/\W+/);
        const overlap = bWords.filter(w => w.length > 3 && aWords.has(w)).length;
        return overlap / Math.max(bWords.length, 1) > 0.6;
      });

      if (isDuplicate) continue;

      const record = await base44.asServiceRole.entities.WorldState.create({
        session_id,
        category: entry.category || "event",
        subject: entry.subject || "Unknown",
        fact: entry.fact,
        importance: entry.importance || "medium",
        is_active: true,
        source_message_index: message_index || 0
      });
      created.push(record);
    }

    return Response.json({ created: created.length, entries: created });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});