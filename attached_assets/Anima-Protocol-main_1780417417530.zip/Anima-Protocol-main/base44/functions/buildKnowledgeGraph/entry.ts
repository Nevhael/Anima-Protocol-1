import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch all active UserContext documents for this user
    const contexts = await base44.entities.UserContext.filter({
      user_email: user.email,
      is_active: true,
    }, '-created_date', 100);

    if (!contexts || contexts.length === 0) {
      return Response.json({ 
        message: 'No documents to build graph from',
        graph: null 
      });
    }

    // Extract entities from all documents using LLM
    const allNodes = {};
    const allEdges = {};
    const docReferences = {};

    for (const context of contexts) {
      const extractionPrompt = `Extract all important entities from this document and their relationships. Return JSON with:
{
  "entities": [
    {"label": "string", "type": "character|place|concept|event|object|theme", "description": "string"}
  ],
  "relationships": [
    {"from": "entity label", "to": "entity label", "relation": "related_to|causes|opposes|supports|similar_to|part_of|knows"}
  ]
}

Document: "${context.extracted_summary || context.title}"`;

      let extraction;
      try {
        extraction = await base44.integrations.Core.InvokeLLM({
          prompt: extractionPrompt,
          response_json_schema: {
            type: "object",
            properties: {
              entities: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    label: { type: "string" },
                    type: { type: "string" },
                    description: { type: "string" }
                  }
                }
              },
              relationships: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    from: { type: "string" },
                    to: { type: "string" },
                    relation: { type: "string" }
                  }
                }
              }
            }
          }
        });
      } catch (err) {
        console.warn(`Failed to extract entities from ${context.title}:`, err);
        continue;
      }

      // Process extracted entities
      if (extraction?.entities) {
        for (const entity of extraction.entities) {
          const nodeId = `${entity.type}:${entity.label.toLowerCase().replace(/\s+/g, '_')}`;
          
          if (!allNodes[nodeId]) {
            allNodes[nodeId] = {
              id: nodeId,
              label: entity.label,
              type: entity.type,
              description: entity.description || '',
              source_documents: [context.id],
              frequency: 1,
              first_appearance: context.title
            };
            docReferences[nodeId] = { [context.id]: true };
          } else {
            allNodes[nodeId].source_documents = [...new Set([...allNodes[nodeId].source_documents, context.id])];
            allNodes[nodeId].frequency += 1;
            docReferences[nodeId][context.id] = true;
          }
        }
      }

      // Process relationships
      if (extraction?.relationships) {
        for (const rel of extraction.relationships) {
          const fromId = `${rel.from.toLowerCase().replace(/\s+/g, '_')}`;
          const toId = `${rel.to.toLowerCase().replace(/\s+/g, '_')}`;
          const edgeId = `${fromId}--${rel.relation}--${toId}`;

          if (!allEdges[edgeId]) {
            allEdges[edgeId] = {
              id: edgeId,
              from_node_id: Object.keys(allNodes).find(nid => allNodes[nid].label.toLowerCase().replace(/\s+/g, '_') === fromId) || fromId,
              to_node_id: Object.keys(allNodes).find(nid => allNodes[nid].label.toLowerCase().replace(/\s+/g, '_') === toId) || toId,
              relation_type: rel.relation,
              strength: 0.5,
              contexts: [context.title]
            };
          } else {
            allEdges[edgeId].contexts = [...new Set([...allEdges[edgeId].contexts, context.title])];
            allEdges[edgeId].strength = Math.min(allEdges[edgeId].strength + 0.2, 1);
          }
        }
      }
    }

    // Create or update the knowledge graph
    const nodeArray = Object.values(allNodes);
    const edgeArray = Object.values(allEdges);

    let existingGraph;
    try {
      const graphs = await base44.entities.KnowledgeGraph.filter({
        user_email: user.email
      });
      existingGraph = graphs?.[0];
    } catch (err) {
      console.warn('Could not fetch existing graph:', err);
    }

    let graphId;
    if (existingGraph) {
      await base44.entities.KnowledgeGraph.update(existingGraph.id, {
        nodes: nodeArray,
        edges: edgeArray,
        document_count: contexts.length,
        total_entities: nodeArray.length,
        last_updated: new Date().toISOString()
      });
      graphId = existingGraph.id;
    } else {
      const newGraph = await base44.entities.KnowledgeGraph.create({
        user_email: user.email,
        graph_name: `${user.full_name}'s Knowledge Graph`,
        nodes: nodeArray,
        edges: edgeArray,
        document_count: contexts.length,
        total_entities: nodeArray.length,
        is_active: true
      });
      graphId = newGraph.id;
    }

    return Response.json({
      success: true,
      graph_id: graphId,
      stats: {
        documents: contexts.length,
        entities: nodeArray.length,
        relationships: edgeArray.length
      }
    });
  } catch (error) {
    console.error('Knowledge graph build error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});