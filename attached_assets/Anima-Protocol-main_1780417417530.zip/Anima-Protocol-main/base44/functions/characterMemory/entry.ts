import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Handles cross-session character memory:
 *   GET (action="get"):  returns top memories for a character
 *   POST (action="save"): extracts and persists new memories from an exchange
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { action, character_id } = body;

    if (!character_id) return Response.json({ error: 'character_id required' }, { status: 400 });

    // ── GET: fetch existing memories ──────────────────────────────────────────
    if (action === 'get') {
      const memories = await base44.entities.CharacterMemory.filter(
        { character_id },
        '-created_date',
        40
      );
      return Response.json({ memories: memories || [] });
    }

    // ── SAVE: extract new memories from the latest exchange ───────────────────
    if (action === 'save') {
      const { session_id, user_message, ai_response, existing_memories } = body;

      const existingList = (existing_memories || [])
        .map((m, i) => `${i + 1}. [${m.category}] ${m.fact}`)
        .join('\n');

      const analysis = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a long-term memory curator for an AI roleplay character. Analyze this exchange and extract facts the CHARACTER should remember about the PLAYER across future sessions.

Player said: "${user_message}"
Character replied: "${(ai_response || '').slice(0, 500)}"

Already remembered (do NOT repeat):
${existingList || '(none yet)'}

Extract only durable, cross-session facts: the player's name/nickname, personal details they revealed, strong preferences/dislikes, secrets they shared, promises made, emotional moments, or key relationship milestones.

Return JSON with:
- memories: array of objects, each with:
  - category: one of "personal", "secret", "interaction", "relationship", "event", "preference"
  - fact: a concise statement (max 20 words) written from the character's perspective, e.g. "Player told me their real name is Alex"
  - tags: array of 1-3 short keyword strings

Return an empty memories array if nothing durable and personal was revealed.`,
        response_json_schema: {
          type: 'object',
          properties: {
            memories: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  category: { type: 'string' },
                  fact: { type: 'string' },
                  tags: { type: 'array', items: { type: 'string' } }
                }
              }
            }
          }
        }
      });

      const entries = (analysis.memories || []).filter(m => m.fact && m.fact.trim());
      const created = [];

      for (const entry of entries) {
        const record = await base44.entities.CharacterMemory.create({
          character_id,
          fact: entry.fact,
          category: entry.category || 'interaction',
          session_id: session_id || null,
          tags: entry.tags || []
        });
        created.push(record);
      }

      return Response.json({ created: created.length, memories: created });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});