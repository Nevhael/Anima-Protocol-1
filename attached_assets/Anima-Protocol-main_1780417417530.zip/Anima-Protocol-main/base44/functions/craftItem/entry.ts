import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id, session_id, craftable_item_name } = await req.json();

    if (!character_id || !session_id || !craftable_item_name) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    // Find the recipe (a craftable item definition)
    const allItems = await base44.entities.Inventory.filter({
      character_id,
      session_id,
    });

    // Get template from a lore entry or use a default crafting system
    const recipe = await base44.entities.WorldState.filter({
      session_id,
      subject: craftable_item_name,
    }).then(results => results?.[0]);

    // Simple crafting validation: check if character has required components
    const requiredComponents = [
      { name: 'Wood', quantity: 2 },
      { name: 'Iron Ore', quantity: 1 },
    ]; // Default recipe for demo

    const hasAll = requiredComponents.every(req => {
      const item = allItems?.find(i => i.name === req.name);
      return item && item.quantity >= req.quantity;
    });

    if (!hasAll) {
      return Response.json({
        success: false,
        message: 'Missing required components',
        required: requiredComponents,
      });
    }

    // Consume components
    for (const component of requiredComponents) {
      const item = allItems?.find(i => i.name === component.name);
      if (item) {
        item.quantity -= component.quantity;
        if (item.quantity <= 0) {
          await base44.entities.Inventory.delete(item.id);
        } else {
          await base44.entities.Inventory.update(item.id, { quantity: item.quantity });
        }
      }
    }

    // Create the crafted item
    const newItem = await base44.entities.Inventory.create({
      character_id,
      session_id,
      name: craftable_item_name,
      description: `Carefully crafted ${craftable_item_name}`,
      type: 'gear',
      quantity: 1,
      rarity: 'uncommon',
      condition: 100,
      source_message_index: 0,
    });

    return Response.json({
      success: true,
      crafted_item: newItem,
      message: `Successfully crafted ${craftable_item_name}!`,
    });
  } catch (error) {
    console.error('Crafting error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});