import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, character_id } = await req.json();

    // Fetch all quests for the session
    const allQuests = await base44.entities.Quest.filter({
      session_id,
      ...(character_id ? { related_characters: character_id } : {}),
    }, "-created_date", 100);

    const completed = allQuests.filter(q => q.status === "completed");
    const totalXp = allQuests.reduce((sum, q) => sum + (q.rewards?.xp || 0), 0);
    const completionRate = allQuests.length > 0 ? Math.round((completed.length / allQuests.length) * 100) : 0;

    // Get recent quests with XP earned
    const recentQuests = completed
      .sort((a, b) => new Date(b.completed_at) - new Date(a.completed_at))
      .slice(0, 5)
      .map(q => ({
        title: q.title,
        xp_earned: q.rewards?.xp || 0,
        completed_at: q.completed_at,
      }));

    // Calculate streaks and bonuses
    const questsByDay = {};
    allQuests.forEach(q => {
      const date = q.created_date?.split("T")[0];
      if (date) questsByDay[date] = (questsByDay[date] || 0) + 1;
    });

    const currentStreak = Object.keys(questsByDay).length;
    const avgQuestsPerDay = currentStreak > 0 ? Math.round(allQuests.length / currentStreak) : 0;

    return Response.json({
      stats: {
        total_quests: allQuests.length,
        completed_quests: completed.length,
        active_quests: allQuests.filter(q => q.status === "active").length,
        abandoned_quests: allQuests.filter(q => q.status === "abandoned").length,
        total_xp: totalXp,
        completion_rate: completionRate,
        current_streak: currentStreak,
        avg_quests_per_day: avgQuestsPerDay,
        recent_quests: recentQuests,
      },
    });
  } catch (error) {
    console.error("Quest statistics error:", error);
    return Response.json({
      stats: {
        total_quests: 0,
        completed_quests: 0,
        active_quests: 0,
        abandoned_quests: 0,
        total_xp: 0,
        completion_rate: 0,
        current_streak: 0,
        avg_quests_per_day: 0,
        recent_quests: [],
      },
    });
  }
});