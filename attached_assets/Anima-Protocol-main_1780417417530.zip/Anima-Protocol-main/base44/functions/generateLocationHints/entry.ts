import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, character_id, current_location, recent_context } = await req.json();

    if (!session_id || !character_id || !current_location) {
      return Response.json({ hints: [] });
    }

    // Get location details
    const locations = await base44.asServiceRole.entities.Location.filter({
      session_id,
      name: current_location,
    });

    if (!locations || locations.length === 0) {
      return Response.json({ hints: [] });
    }

    const location = locations[0];

    // Get character's previous interactions at this location
    const memories = await base44.asServiceRole.entities.CharacterMemory.filter({
      character_id,
      category: 'location_knowledge',
    }, '-created_date', 20);

    const relevantMemories = (memories || [])
      .filter(m => m.fact.includes(location.name))
      .map(m => m.fact);

    // Generate dialogue hints using LLM
    const hintPrompt = `${recent_context}

Current location: ${location.name}
Description: ${location.description}
${relevantMemories.length > 0 ? `Previous interactions here: ${relevantMemories.join('; ')}` : ''}

Generate 2-3 subtle dialogue hints (not instructions) that the character might naturally use based on:
1. Their familiarity with this location
2. Previous events that happened here
3. Sensory details they'd notice returning

Return as JSON: { "hints": ["hint1", "hint2", "hint3"] }`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: hintPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          hints: {
            type: 'array',
            items: { type: 'string' }
          }
        }
      }
    });

    const hints = (result?.hints || []).slice(0, 3);

    return Response.json({
      success: true,
      location: location.name,
      hints,
      previous_interactions: relevantMemories.length,
    });
  } catch (error) {
    console.error('Location hints generation error:', error);
    return Response.json({ hints: [], error: error.message });
  }
});