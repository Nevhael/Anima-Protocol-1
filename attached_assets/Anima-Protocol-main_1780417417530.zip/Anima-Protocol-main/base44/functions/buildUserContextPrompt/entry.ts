import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Fetch all active user context documents
    const contexts = await base44.entities.UserContext.filter({
      user_email: user.email,
      is_active: true,
      processing_complete: true,
    });

    if (!contexts || contexts.length === 0) {
      return Response.json({
        success: true,
        context_prompt: '',
        context_count: 0,
      });
    }

    // Build a consolidated context prompt for the Anima
    let contextLines = [];
    contextLines.push('CONTEXT ABOUT THE USER (from their uploaded documents):');
    contextLines.push('');

    contexts.forEach((ctx, idx) => {
      contextLines.push(`[${ctx.document_type.toUpperCase()}] ${ctx.title}`);
      if (ctx.extracted_summary) {
        contextLines.push(`Summary: ${ctx.extracted_summary}`);
      }
      if (ctx.key_themes?.length > 0) {
        contextLines.push(`Themes: ${ctx.key_themes.join(', ')}`);
      }
      if (ctx.personal_values?.length > 0) {
        contextLines.push(`Values: ${ctx.personal_values.join(', ')}`);
      }
      contextLines.push('');
    });

    contextLines.push('Use this context to understand the user deeply when responding as the Anima.');

    const contextPrompt = contextLines.join('\n');

    return Response.json({
      success: true,
      context_prompt: contextPrompt,
      context_count: contexts.length,
      documents: contexts.map(c => ({
        title: c.title,
        type: c.document_type,
        themes: c.key_themes,
        values: c.personal_values,
      })),
    });
  } catch (error) {
    console.error('Context prompt building error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});