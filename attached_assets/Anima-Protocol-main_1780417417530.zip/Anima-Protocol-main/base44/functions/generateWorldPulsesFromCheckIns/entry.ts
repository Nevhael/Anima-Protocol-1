import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, check_in_id } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    // Fetch recent check-ins (last 7 days)
    const today = new Date();
    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const dateStr = sevenDaysAgo.toISOString().split('T')[0];

    const recentCheckIns = await base44.entities.CheckIn.filter({
      session_id,
      user_email: user.email,
    });

    if (!recentCheckIns || recentCheckIns.length === 0) {
      return Response.json({ error: 'No check-ins found', pulse: null });
    }

    // Analyze emotional trends
    const moods = recentCheckIns.map(ci => ci.mood);
    const emotionalTrend = analyzeEmotionalTrend(moods);
    const trendIntensity = calculateTrendIntensity(moods);

    // Generate world changes based on emotional arc
    const worldChanges = generateWorldChanges(emotionalTrend, trendIntensity, recentCheckIns);

    // Build narrative summary
    const narrativeSummary = buildNarrativeSummary(emotionalTrend, recentCheckIns, worldChanges);

    // Create WorldPulse record
    const pulse = await base44.entities.WorldPulse.create({
      session_id,
      user_email: user.email,
      pulse_date: new Date().toISOString().split('T')[0],
      emotional_trend: emotionalTrend.trend,
      trend_intensity: trendIntensity,
      world_changes: worldChanges,
      check_in_period: {
        start_date: sevenDaysAgo.toISOString().split('T')[0],
        end_date: today.toISOString().split('T')[0],
        check_in_count: recentCheckIns.length,
      },
      emotional_arc: recentCheckIns.map(ci => ({
        date: ci.check_in_date,
        mood: ci.mood,
        intensity: estimateIntensity(ci),
      })),
      narrative_summary: narrativeSummary,
      applied_to_world: false,
    });

    // Apply changes to world state (non-blocking)
    applyWorldChanges(base44, session_id, worldChanges, pulse.id).catch(err => {
      console.error('Error applying world changes:', err);
    });

    return Response.json({
      success: true,
      pulse: {
        id: pulse.id,
        emotional_trend: emotionalTrend.trend,
        trend_intensity: trendIntensity,
        world_changes_count: worldChanges.length,
        narrative_summary,
      },
    });
  } catch (error) {
    console.error('WorldPulse generation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

// Analyze emotional trend from a sequence of moods
function analyzeEmotionalTrend(moods) {
  if (moods.length < 2) {
    return { trend: 'stable', direction: 'neutral' };
  }

  // Emotion value mapping
  const emotionValues = {
    joyful: 8,
    energized: 7,
    calm: 5,
    focused: 6,
    contemplative: 4,
    anxious: 3,
    scattered: 2,
    weary: 2,
  };

  const values = moods.map(m => emotionValues[m] || 4);
  const firstHalf = values.slice(0, Math.ceil(values.length / 2));
  const secondHalf = values.slice(Math.ceil(values.length / 2));
  const firstAvg = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length;
  const secondAvg = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length;
  const delta = secondAvg - firstAvg;

  // Volatility check
  const variance = values.reduce((sum, val) => sum + Math.pow(val - (values.reduce((a, b) => a + b) / values.length), 2), 0) / values.length;
  const isVolatile = variance > 2.5;

  if (isVolatile) {
    return { trend: 'emotional_turbulence', direction: delta > 0 ? 'resolving' : 'intensifying' };
  } else if (delta > 1.5) {
    return { trend: 'ascending_growth', direction: 'upward' };
  } else if (delta < -1.5) {
    return { trend: 'introspective_descent', direction: 'inward' };
  } else {
    return { trend: 'grounded_stability', direction: 'steady' };
  }
}

// Calculate intensity 0-10
function calculateTrendIntensity(moods) {
  const emotionValues = {
    joyful: 8,
    energized: 7,
    calm: 5,
    focused: 6,
    contemplative: 4,
    anxious: 3,
    scattered: 2,
    weary: 2,
  };

  const values = moods.map(m => emotionValues[m] || 4);
  const avg = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, val) => sum + Math.pow(val - avg, 2), 0) / values.length;
  const intensity = Math.min(10, 3 + variance * 1.5);
  return Math.round(intensity * 10) / 10;
}

// Estimate single check-in intensity
function estimateIntensity(checkIn) {
  const emotionValues = {
    joyful: 8,
    energized: 7,
    calm: 5,
    focused: 6,
    contemplative: 4,
    anxious: 3,
    scattered: 2,
    weary: 2,
  };
  return emotionValues[checkIn.mood] || 5;
}

// Generate world state changes based on emotional trend
function generateWorldChanges(emotionalTrend, intensity, checkIns) {
  const changes = [];

  if (emotionalTrend.trend === 'ascending_growth') {
    changes.push({
      type: 'opportunity_creation',
      description: 'New opportunities emerge as the world recognizes your growing confidence and capability.',
      affected_entity: 'world_opportunities',
      narrative_hook: 'Doors that were previously closed now open. People respond to your newfound clarity.',
    });
    changes.push({
      type: 'faction_shift',
      description: 'Allies and neutral parties become more receptive to your goals.',
      affected_entity: 'faction_sentiment',
      narrative_hook: 'Your inner strength resonates outward, shifting political landscapes.',
    });
  }

  if (emotionalTrend.trend === 'emotional_turbulence') {
    changes.push({
      type: 'npc_reaction',
      description: 'Characters notice your inner conflict and respond with empathy or challenge.',
      affected_entity: 'character_relationships',
      narrative_hook: 'Your struggle does not go unnoticed. Allies either draw closer or test your resolve.',
    });
    if (emotionalTrend.direction === 'resolving') {
      changes.push({
        type: 'environmental_change',
        description: 'The world itself seems to calm alongside your inner resolution.',
        affected_entity: 'environmental_stability',
        narrative_hook: 'Storms pass. Chaos settles into meaning.',
      });
    }
  }

  if (emotionalTrend.trend === 'introspective_descent') {
    changes.push({
      type: 'location_evolution',
      description: 'Quiet places deepen with mystery. Hidden things reveal themselves.',
      affected_entity: 'location_mysteries',
      narrative_hook: 'In silence, truths emerge. The world honors your inward journey.',
    });
    changes.push({
      type: 'npc_reaction',
      description: 'Wise NPCs seek you out, recognizing your readiness for deeper knowledge.',
      affected_entity: 'character_encounters',
      narrative_hook: 'Teachers appear when the student is ready.',
    });
  }

  if (emotionalTrend.trend === 'grounded_stability') {
    changes.push({
      type: 'faction_shift',
      description: 'Your steady presence builds trust with factions and communities.',
      affected_entity: 'faction_trust',
      narrative_hook: 'Reliability becomes your strength. Others begin to depend on you.',
    });
  }

  // Add reflection-based change if user had insights
  const insightCount = checkIns.filter(ci => ci.revelation && ci.revelation.trim().length > 0).length;
  if (insightCount > checkIns.length / 2) {
    changes.push({
      type: 'opportunity_creation',
      description: 'Revelations crystallize into actionable paths forward.',
      affected_entity: 'narrative_branches',
      narrative_hook: 'Clarity leads to choice. New branches appear in the story.',
    });
  }

  return changes;
}

// Build narrative summary
function buildNarrativeSummary(emotionalTrend, checkIns, worldChanges) {
  const moodList = checkIns.map(ci => ci.mood).join(', ');
  const changeDescriptions = worldChanges.map(c => c.narrative_hook).join(' ');

  return `Over the past week, your emotional journey has been marked by ${emotionalTrend.trend}. Moving through moods of ${moodList}, the world has responded: ${changeDescriptions}`;
}

// Apply world changes to world state (non-blocking)
async function applyWorldChanges(base44, sessionId, changes, pulseId) {
  for (const change of changes) {
    try {
      await base44.entities.WorldState.create({
        session_id: sessionId,
        category: change.type,
        subject: change.affected_entity,
        fact: change.description,
        is_active: true,
        source: 'world_pulse',
        source_id: pulseId,
      });
    } catch (err) {
      console.error(`Error applying change ${change.type}:`, err);
    }
  }

  // Mark pulse as applied
  await base44.entities.WorldPulse.update(pulseId, {
    applied_to_world: true,
    applied_at: new Date().toISOString(),
  });
}