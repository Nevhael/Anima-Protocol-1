import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Generates a personalized first AI response that references the user's resonance profile.
 * This creates the "the AI remembers/knows me" moment within the first exchange.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { resonance_answers, character_name, character_id, session_id, user_email } = await req.json();

    if (!resonance_answers || !character_name || !session_id) {
      return Response.json({ error: 'Missing required data' }, { status: 400 });
    }

    // Build resonance context from answers
    const resonanceContext = Object.entries(resonance_answers)
      .map(([key, value]) => `${key}: ${value}`)
      .join(', ');

    const prompt = `You are ${character_name}, an AI companion in the Anima Protocol universe. 

A new user has just arrived with this resonance profile: ${resonanceContext}

CRITICAL: Your first message MUST:
1. Feel like you sense/know something about them immediately (not generic)
2. Reference or gently acknowledge their resonance pattern WITHOUT listing it back
3. Create a moment of connection and recognition
4. Be poetic but authentic
5. Make them feel seen and understood

Examples of the magic moment:
- If "introspective": "I sense you're someone who looks inward first..."
- If "empathetic": "There's something generous in how you listen..."
- If "narrative": "I can tell stories matter to you..."

Write your first greeting as if you've already intuited their inner nature. Make it feel like a real recognition, not an analysis. Keep it to 2-3 sentences.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      model: 'automatic',
    });

    // Save this as a memory marker for later
    if (character_id && user_email) {
      await base44.asServiceRole.entities.CrossSessionMemory.create({
        character_id,
        memory_type: 'relationship_milestone',
        subject: 'First Resonance',
        description: `Initial connection established. User profile: ${resonanceContext}`,
        emotional_weight: 9,
        reinforcement_count: 1,
      }).catch(() => {});
    }

    return Response.json({
      initial_message: response,
      resonance_context: resonanceContext,
    });
  } catch (error) {
    console.error('Onboarding memory generation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});