/**
 * aggregatePersonalityShifts
 *
 * Scans all solo chat sessions for a given character, extracts personality
 * trait deltas (emotional shifts, relationship growth, key decisions), and
 * synthesises a compact "trait modifier" block that can be injected into
 * group prompts so the character's solo growth bleeds into group behaviour.
 *
 * Payload:
 *   character_id   – required
 *   character_name – required
 *   max_sessions   – optional (default 5, most recent solo sessions to scan)
 *
 * Returns:
 *   {
 *     trait_modifiers: string,   // ready-to-inject prompt block
 *     shifts: [...],             // array of detected shifts
 *     sessions_analysed: number,
 *     cached: boolean
 *   }
 */

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { character_id, character_name, max_sessions = 5 } = await req.json();
    if (!character_id || !character_name) {
      return Response.json({ error: 'character_id and character_name are required' }, { status: 400 });
    }

    // ── 1. Load character base data ──────────────────────────────────────────
    const [character, allSessions] = await Promise.all([
      base44.entities.Character.list().then(chars => chars.find(c => c.id === character_id)),
      base44.entities.ChatSession.list('-updated_date', 100),
    ]);

    if (!character) return Response.json({ error: 'Character not found' }, { status: 404 });

    // Filter to solo sessions featuring this character (most recent first)
    const soloSessions = allSessions
      .filter(s => s.mode === 'solo' && s.character_id === character_id)
      .slice(0, max_sessions);

    if (soloSessions.length === 0) {
      return Response.json({
        trait_modifiers: '',
        shifts: [],
        sessions_analysed: 0,
        cached: false,
      });
    }

    // ── 2. Collect emotional states & cross-session memories ─────────────────
    const [emotionalStates, crossMemories, vectorMemories] = await Promise.all([
      base44.entities.CharacterEmotionalState
        ? base44.asServiceRole.entities.CharacterEmotionalState.filter({ character_id })
        : Promise.resolve([]),
      base44.asServiceRole.entities.CrossSessionMemory.filter({ character_id }),
      base44.asServiceRole.entities.VectorMemory.filter({ character_id }),
    ]);

    // ── 3. Build a compact transcript digest for the LLM ────────────────────
    const transcriptDigest = soloSessions.map(session => {
      const msgs = (session.messages || []).filter(
        m => m.role !== 'system' && m.character_name !== '__typing__'
      );
      // Keep up to 30 messages per session to stay within token budget
      const sample = msgs.slice(-30);
      const text = sample
        .map(m => `${m.role === 'user' ? 'Player' : character_name}: ${(m.content || '').slice(0, 300)}`)
        .join('\n');
      return `[Session: ${session.title || session.id.slice(0, 8)}]\n${text}`;
    }).join('\n\n---\n\n');

    const memorySummary = crossMemories
      .slice(0, 20)
      .map(m => `• [${m.memory_type}] ${m.subject}: ${(m.description || '').slice(0, 200)}`)
      .join('\n');

    const emotionHistory = emotionalStates
      .slice(0, 15)
      .map(e => `• ${e.primary_emotion}${e.intensity ? ` (${e.intensity}/10)` : ''}${e.trigger ? ` — triggered by: ${e.trigger}` : ''}`)
      .join('\n');

    // ── 4. Ask LLM to derive trait modifiers ────────────────────────────────
    const analysisPrompt = `You are a narrative continuity system. Analyse how ${character_name} has changed through their private one-on-one sessions with the player, and produce a concise "trait modifier" summary that can be injected into a GROUP chat prompt so the character's growth influences how they behave with others.

CHARACTER BASE PERSONALITY:
${character.personality || '(not set)'}

BASE SPEAKING STYLE:
${character.speaking_style || '(not set)'}

SOLO SESSION TRANSCRIPTS (most recent ${soloSessions.length} sessions):
${transcriptDigest}

CROSS-SESSION MEMORIES:
${memorySummary || '(none)'}

EMOTIONAL HISTORY (recent states):
${emotionHistory || '(none)'}

Based on the above, identify:
1. Personality traits that have SHIFTED (e.g. became more open, less guarded, more humorous)
2. Specific behaviours or speech patterns that emerged in private chats
3. Emotional growth or wounds that now colour how they present in social settings
4. Any loyalty, affection, resentment, or vulnerability toward the player that would subtly show around others

Output a JSON object with these fields:
- shifts: array of objects { trait, direction ("amplified"|"softened"|"new"|"suppressed"), evidence }
- trait_modifiers_block: a 3–6 sentence paragraph written IN THE SECOND PERSON for ${character_name} (e.g. "You have grown more...") that can be appended directly to a group prompt. Make it subtle — group social behaviour, not private confessions.
- confidence: "low"|"medium"|"high" based on how much evidence there is`;

    const llmResult = await base44.integrations.Core.InvokeLLM({
      prompt: analysisPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          shifts: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                trait: { type: 'string' },
                direction: { type: 'string' },
                evidence: { type: 'string' },
              },
            },
          },
          trait_modifiers_block: { type: 'string' },
          confidence: { type: 'string' },
        },
      },
    });

    const shifts = llmResult.shifts || [];
    const rawBlock = llmResult.trait_modifiers_block || '';
    const confidence = llmResult.confidence || 'low';

    // ── 5. Format the final injectable block ────────────────────────────────
    let trait_modifiers = '';
    if (rawBlock && confidence !== 'low') {
      trait_modifiers =
        `\nSOLO-SESSION PERSONALITY SHIFTS (private growth that subtly colours your group behaviour — do NOT announce these explicitly):\n${rawBlock}\n`;
    }

    console.log(`[aggregatePersonalityShifts] ${character_name}: ${shifts.length} shifts detected across ${soloSessions.length} sessions (confidence: ${confidence})`);

    return Response.json({
      trait_modifiers,
      shifts,
      sessions_analysed: soloSessions.length,
      confidence,
      cached: false,
    });

  } catch (error) {
    console.error('[aggregatePersonalityShifts] error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});