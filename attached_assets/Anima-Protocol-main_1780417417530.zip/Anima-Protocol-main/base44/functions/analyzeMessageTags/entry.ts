import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { message, character_ids = [] } = await req.json();

    if (!message || !message.trim()) {
      return Response.json({ suggestions: [] });
    }

    const messageLower = message.toLowerCase();

    // Fetch characters, memories, and storypoints
    const [characters, memories, storypoints] = await Promise.all([
      base44.entities.Character.list("-created_date", 100),
      base44.entities.CharacterMemory.list("-created_date", 200),
      base44.entities.Storypoint.list("-created_date", 100),
    ]);

    const suggestions = {
      characters: [],
      memories: [],
      storypoints: [],
    };

    // Find mentioned characters
    characters.forEach((char) => {
      if (messageLower.includes(char.name.toLowerCase())) {
        suggestions.characters.push({
          id: char.id,
          name: char.name,
          type: 'character',
        });
      }
    });

    // Find relevant memories (by character match or keyword match)
    const relevantMemories = new Map();
    memories.forEach((mem) => {
      let score = 0;

      // Character match
      if (character_ids.includes(mem.character_id)) {
        score += 2;
      }

      // Keyword match in memory fact
      const memFactLower = mem.fact.toLowerCase();
      const words = messageLower.split(/\s+/);
      words.forEach((word) => {
        if (word.length > 3 && memFactLower.includes(word)) {
          score += 1;
        }
      });

      // Character name match in message
      characters.forEach((char) => {
        if (messageLower.includes(char.name.toLowerCase()) && mem.character_id === char.id) {
          score += 3;
        }
      });

      if (score > 0) {
        relevantMemories.set(mem.id, { ...mem, score });
      }
    });

    // Sort by score and take top 5
    suggestions.memories = Array.from(relevantMemories.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map((mem) => ({
        id: mem.id,
        character_id: mem.character_id,
        fact: mem.fact.substring(0, 80),
        category: mem.category,
        type: 'memory',
      }));

    // Find relevant storypoints (by keyword or title match)
    const relevantStorypoints = [];
    storypoints.forEach((sp) => {
      let score = 0;
      const titleLower = (sp.title || "").toLowerCase();
      const summaryLower = (sp.summary || "").toLowerCase();

      const words = messageLower.split(/\s+/);
      words.forEach((word) => {
        if (word.length > 3) {
          if (titleLower.includes(word)) score += 2;
          if (summaryLower.includes(word)) score += 1;
        }
      });

      if (score > 0) {
        relevantStorypoints.push({ ...sp, score });
      }
    });

    suggestions.storypoints = relevantStorypoints
      .sort((a, b) => b.score - a.score)
      .slice(0, 3)
      .map((sp) => ({
        id: sp.id,
        title: sp.title,
        summary: sp.summary?.substring(0, 60),
        type: 'storypoint',
      }));

    return Response.json({ suggestions });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});