import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { session_id } = body;

    if (!session_id) return Response.json({ error: 'session_id required' }, { status: 400 });

    // Fetch the session
    const sessions = await base44.entities.ChatSession.filter({ id: session_id });
    const session = sessions?.[0];
    if (!session) return Response.json({ error: 'Session not found' }, { status: 404 });

    const messages = session.messages || [];
    if (messages.length < 5) {
      return Response.json({ skipped: true, reason: 'Not enough messages to summarize' });
    }

    // Take the last 20 messages (or all if fewer)
    const recentMessages = messages.slice(-20);
    const dialogue = recentMessages
      .filter(m => m.character_name !== '__typing__' && m.type !== 'event')
      .map(m => {
        const speaker = m.role === 'user' ? 'Player' : (m.character_name || 'Character');
        return `${speaker}: ${m.content}`;
      })
      .join('\n');

    if (!dialogue.trim()) {
      return Response.json({ skipped: true, reason: 'No dialogue to summarize' });
    }

    // Check if a summary already exists for this session to avoid duplicates
    const existingSummaries = await base44.entities.WorldState.filter({
      session_id,
      category: 'event',
      subject: 'Story Summary'
    });

    // Generate summary via LLM
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a narrative chronicler. Read the following roleplay dialogue and write a concise, vivid story summary (3-5 sentences max) capturing the key events, emotional beats, decisions made, and how relationships shifted. Write in past tense, third person, as if recording it for posterity.

DIALOGUE:
${dialogue}

Return JSON with:
- summary: the story summary text
- key_themes: array of 2-4 short theme tags (e.g. "betrayal", "discovery", "alliance")`,
      response_json_schema: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          key_themes: { type: 'array', items: { type: 'string' } }
        }
      }
    });

    if (!result?.summary) {
      return Response.json({ error: 'LLM returned no summary' }, { status: 500 });
    }

    const themeTag = result.key_themes?.length ? ` [${result.key_themes.join(', ')}]` : '';
    const fact = `${result.summary}${themeTag}`;

    // If an existing summary exists, update it; otherwise create new
    let entry;
    if (existingSummaries?.length > 0) {
      // Update the most recent one
      const latest = existingSummaries.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
      entry = await base44.entities.WorldState.update(latest.id, {
        fact,
        source_message_index: messages.length - 1,
        importance: 'critical',
        is_active: true
      });
    } else {
      entry = await base44.entities.WorldState.create({
        session_id,
        category: 'event',
        subject: 'Story Summary',
        fact,
        importance: 'critical',
        is_active: true,
        source_message_index: messages.length - 1
      });
    }

    return Response.json({
      success: true,
      summary: fact,
      entry_id: entry?.id,
      message_count: messages.length
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});