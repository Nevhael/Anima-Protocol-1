import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id, query, limit = 10 } = await req.json();

    if (!character_id || !query) {
      return Response.json({ error: 'character_id and query required' }, { status: 400 });
    }

    // Get all memories for this character
    const result = await base44.functions.invoke('characterMemory', {
      action: 'get',
      character_id,
    });

    const memories = result?.data?.memories || [];

    if (memories.length === 0) {
      return Response.json({ results: [] });
    }

    // Use LLM to find semantically similar memories
    const memoryTexts = memories
      .map((m, idx) => `${idx}. [${m.category}] ${m.fact}`)
      .join('\n');

    const searchPrompt = `Given these memories:

${memoryTexts}

Find the top ${limit} memories most relevant to this query: "${query}"

Return ONLY a JSON array of memory indices (numbers) in order of relevance, like: [2, 5, 1]
Do not include any other text.`;

    const llmResult = await base44.integrations.Core.InvokeLLM({
      prompt: searchPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          indices: {
            type: 'array',
            items: { type: 'number' },
          },
        },
      },
    });

    const relevantIndices = llmResult.indices || [];
    const results = relevantIndices
      .slice(0, limit)
      .map((idx) => memories[idx])
      .filter(Boolean);

    return Response.json({ results, query, total_memories: memories.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});