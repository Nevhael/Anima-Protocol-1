import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    let { session_id, message_content, message_index } = payload;

    // Handle entity automation payload (event.entity_id is the ChatSession id)
    if (!session_id && payload.event?.entity_id) {
      session_id = payload.event.entity_id;
    }
    if (!message_content && payload.data?.messages?.length > 0) {
      const lastMsg = payload.data.messages[payload.data.messages.length - 1];
      message_content = lastMsg.content;
      message_index = payload.data.messages.length - 1;
    }

    if (!session_id || !message_content) {
      return Response.json({ error: 'session_id and message_content required' }, { status: 400 });
    }

    // Fetch all wiki entries for this session to match against message
    const [worldState, locations, characters] = await Promise.all([
      base44.entities.WorldState.filter({ session_id, is_active: true }, "-created_date", 100),
      base44.entities.Location.filter({}, "-created_date", 100),
      base44.entities.Character.list("-created_date", 100),
    ]);

    const lowerContent = message_content.toLowerCase();
    const taggedEntities = [];
    const createdLore = [];

    // Check for mentions of existing wiki entries and create cross-references
    const entitiesToCheck = [
      ...worldState.map(e => ({ name: e.subject, type: 'lore', id: e.id })),
      ...locations.map(l => ({ name: l.name, type: 'location', id: l.id })),
      ...characters.map(c => ({ name: c.name, type: 'character', id: c.id })),
    ];

    for (const entity of entitiesToCheck) {
      if (lowerContent.includes(entity.name.toLowerCase())) {
        taggedEntities.push({
          entity_name: entity.name,
          entity_type: entity.type,
          entity_id: entity.id,
          mentioned_at_message_index: message_index || 0
        });
      }
    }

    // Use LLM to detect NEW entities that should be added to wiki
    if (message_content.length > 20) {
      const existingEntities = entitiesToCheck.map(e => e.name).join(', ') || 'None yet';
      
      const detectionPrompt = `Analyze this roleplay message for new entities (characters, items, locations, factions) that should be added to the world wiki.

EXISTING WIKI ENTRIES:
${existingEntities}

MESSAGE:
"${message_content}"

Identify NEW entities NOT already in the wiki that are:
1. Named locations (cities, dungeons, landmarks)
2. Items or artifacts mentioned with significance
3. New factions or organizations
4. Major events or story beats worth documenting

Return ONLY truly new entities that add to world-building. Ignore casual mentions.`;

      const detected = await base44.integrations.Core.InvokeLLM({
        prompt: detectionPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            new_entities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  type: { type: "string", enum: ["location", "item", "faction", "event"] },
                  description: { type: "string" },
                  category: { type: "string" }
                }
              }
            }
          }
        }
      });

      // Create WorldState or Location entries for detected entities
      for (const entity of detected.new_entities || []) {
        try {
          if (entity.type === 'location') {
            await base44.entities.Location.create({
              name: entity.name,
              description: entity.description,
              x_coord: Math.random() * 100,
              y_coord: Math.random() * 100,
              category: 'other',
              significance: 'important',
              visited: true,
              first_visit_session_id: session_id,
            });
          } else {
            await base44.entities.WorldState.create({
              session_id,
              category: entity.type,
              subject: entity.name,
              fact: entity.description,
              importance: 'medium',
              is_active: true,
              source_message_index: message_index || 0,
            });
          }
          createdLore.push({
            name: entity.name,
            type: entity.type,
            created: true
          });
        } catch (err) {
          console.error(`Error creating entity ${entity.name}:`, err);
        }
      }
    }

    return Response.json({
      success: true,
      session_id,
      tagged_entities: taggedEntities,
      created_lore: createdLore,
      total_tags: taggedEntities.length,
      total_created: createdLore.length
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});