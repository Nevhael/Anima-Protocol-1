import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const today = new Date().toISOString().split('T')[0];
    
    // Get or create streak record
    const streaks = await base44.entities.UserStreak.filter({ user_email: user.email });
    const streak = streaks?.[0];
    
    if (!streak) {
      // First activity ever
      const created = await base44.entities.UserStreak.create({
        user_email: user.email,
        current_streak: 1,
        longest_streak: 1,
        last_active_date: today,
        total_active_days: 1
      });
      
      return Response.json({ streak: created, streakUpdated: true });
    }

    const lastDate = streak.last_active_date;
    const currentStreak = streak.current_streak || 0;
    const longestStreak = streak.longest_streak || 0;
    
    // Check if already active today
    if (lastDate === today) {
      return Response.json({ streak, already_active_today: true });
    }

    // Calculate days since last activity
    const lastDateObj = new Date(lastDate + 'T00:00:00');
    const todayObj = new Date(today + 'T00:00:00');
    const daysDiff = Math.floor((todayObj - lastDateObj) / (1000 * 60 * 60 * 24));

    let newCurrentStreak = currentStreak;
    let newLongestStreak = longestStreak;

    if (daysDiff === 1) {
      // Consecutive day - increase streak
      newCurrentStreak = currentStreak + 1;
      newLongestStreak = Math.max(newCurrentStreak, longestStreak);
    } else if (daysDiff > 1 && streak.streak_frozen) {
      // Streak was frozen, extend it
      newCurrentStreak = currentStreak + 1;
      newLongestStreak = Math.max(newCurrentStreak, longestStreak);
    } else if (daysDiff > 1) {
      // Streak broken - start new one
      newCurrentStreak = 1;
    }

    // Update streak
    const updated = await base44.entities.UserStreak.update(streak.id, {
      current_streak: newCurrentStreak,
      longest_streak: newLongestStreak,
      last_active_date: today,
      total_active_days: (streak.total_active_days || 0) + 1,
      streak_frozen: false
    });

    // Track in progress
    const progress = await base44.entities.UserProgress.filter({ user_email: user.email });
    if (progress?.[0]) {
      await base44.entities.UserProgress.update(progress[0].id, {
        last_session_date: new Date().toISOString()
      });
    }

    return Response.json({ 
      streak: updated, 
      streakIncreased: newCurrentStreak > currentStreak,
      newStreak: newCurrentStreak 
    });
  } catch (error) {
    console.error('Update streak error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});