import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_id,
      query,
      memory_types,
      related_character_id,
      limit = 8,
      similarity_threshold = 0.5,
    } = await req.json();

    if (!character_id) {
      return Response.json({ error: 'character_id required' }, { status: 400 });
    }

    // Generate query embedding
    const queryEmbeddingPrompt = `Summarize this search query into 5 semantic dimensions (0-1 scale):
[emotional_intensity, narrative_importance, relationship_significance, character_growth, temporal_weight]

Query: "${query}"

Return only the JSON array.`;

    let queryEmbedding;
    try {
      const embeddingResult = await base44.integrations.Core.InvokeLLM({
        prompt: queryEmbeddingPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            dimensions: { type: 'array', items: { type: 'number' }, minItems: 5, maxItems: 5 }
          }
        }
      });
      queryEmbedding = embeddingResult?.dimensions || generateSimpleEmbedding(query);
    } catch {
      queryEmbedding = generateSimpleEmbedding(query);
    }

    // Build filter
    const filter = { character_id };
    if (memory_types?.length > 0) {
      filter.memory_type = { $in: memory_types };
    }
    if (related_character_id) {
      filter.related_characters = { $in: [related_character_id] };
    }

    // Fetch all candidate memories
    const allMemories = await base44.entities.VectorMemory.filter(filter, '-created_date', 100);

    if (!allMemories || allMemories.length === 0) {
      return Response.json({ memories: [], query_metadata: { query, embedding: queryEmbedding } });
    }

    // Calculate similarity scores and rank
    const scored = allMemories
      .map(mem => {
        const similarity = calculateCosineSimilarity(queryEmbedding, mem.embedding || []);
        return { memory: mem, score: similarity };
      })
      .filter(item => item.score >= similarity_threshold)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);

    // Update recall_count and last_recalled
    for (const item of scored) {
      base44.entities.VectorMemory.update(item.memory.id, {
        recall_count: (item.memory.recall_count || 0) + 1,
        last_recalled: new Date().toISOString(),
      }).catch(() => {});
    }

    return Response.json({
      memories: scored.map(item => ({
        ...item.memory,
        similarity_score: item.score,
      })),
      total_candidates: allMemories.length,
      retrieved: scored.length,
      query_metadata: { query, embedding: queryEmbedding },
    });
  } catch (error) {
    console.error('Vector memory search error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function generateSimpleEmbedding(text) {
  const words = text.toLowerCase().split(/\s+/);
  const freq = {};
  words.forEach(w => freq[w] = (freq[w] || 0) + 1);
  
  return [
    Math.min(freq['love'] || freq['care'] || 0, 10) / 10,
    Math.min(freq['conflict'] || freq['fight'] || 0, 5) / 10,
    Math.min(freq['trust'] || freq['believe'] || 0, 10) / 10,
    Math.min(freq['grow'] || freq['learn'] || 0, 10) / 10,
    Math.min(text.length, 1000) / 1000,
  ];
}

function calculateCosineSimilarity(vec1, vec2) {
  const dotProduct = vec1.reduce((sum, val, i) => sum + val * (vec2[i] || 0), 0);
  const magnitude1 = Math.sqrt(vec1.reduce((sum, val) => sum + val * val, 0));
  const magnitude2 = Math.sqrt(vec2.reduce((sum, val) => sum + val * val, 0));
  return magnitude1 && magnitude2 ? dotProduct / (magnitude1 * magnitude2) : 0;
}