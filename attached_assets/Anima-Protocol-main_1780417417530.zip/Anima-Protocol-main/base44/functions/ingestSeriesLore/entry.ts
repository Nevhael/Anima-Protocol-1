import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

/**
 * Fetches lore, plot points, and character relationships for a series/movie
 * and creates memory nodes for the active session
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { series_title, session_id, character_id } = await req.json();

    if (!series_title || !session_id) {
      return Response.json(
        { error: "Missing series_title or session_id" },
        { status: 400 }
      );
    }

    console.log(`Ingesting lore for: ${series_title}`);

    // Fetch series lore and plot points from LLM with web search
    const lorePrompt = `You are a creative writing assistant. For the series/movie "${series_title}", provide a structured JSON response with:

1. series_name: full title
2. universe: genre/franchise
3. overview: 2-3 sentence summary
4. major_plot_points: array of 5-8 key story beats (chronological order, with brief description)
5. key_locations: array of important settings (with 1-line descriptions)
6. factions_or_groups: array of major factions/organizations
7. lore_facts: array of 10-12 critical world-building facts that would matter to a character in this universe
8. character_archetypes: common character types found in this series (e.g., "The Chosen One", "The Mentor", etc.)
9. power_systems_or_magic: explanation of how power/magic/technology works in this world
10. story_themes: array of major themes

Return ONLY valid JSON, no markdown or extra text.`;

    const loreResponse = await base44.integrations.Core.InvokeLLM({
      prompt: lorePrompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          series_name: { type: "string" },
          universe: { type: "string" },
          overview: { type: "string" },
          major_plot_points: {
            type: "array",
            items: { type: "string" },
          },
          key_locations: {
            type: "array",
            items: { type: "string" },
          },
          factions_or_groups: {
            type: "array",
            items: { type: "string" },
          },
          lore_facts: {
            type: "array",
            items: { type: "string" },
          },
          character_archetypes: {
            type: "array",
            items: { type: "string" },
          },
          power_systems_or_magic: { type: "string" },
          story_themes: {
            type: "array",
            items: { type: "string" },
          },
        },
      },
    });

    if (!loreResponse) {
      throw new Error("Failed to fetch series lore");
    }

    console.log(`Retrieved lore structure for ${loreResponse.series_name}`);

    // Create WorldState entries for the series lore
    const loreEntries = [];

    // Add major plot points as events
    for (const point of loreResponse.major_plot_points) {
      loreEntries.push({
        session_id,
        category: "event",
        subject: `${loreResponse.series_name}: Plot Point`,
        fact: point,
        importance: "major",
        is_active: true,
      });
    }

    // Add locations
    for (const location of loreResponse.key_locations) {
      loreEntries.push({
        session_id,
        category: "location",
        subject: location.split(":")[0].trim(),
        fact: location,
        importance: "major",
        is_active: true,
      });
    }

    // Add factions
    for (const faction of loreResponse.factions_or_groups) {
      loreEntries.push({
        session_id,
        category: "faction",
        subject: faction,
        fact: `Faction/Group in ${loreResponse.series_name}: ${faction}`,
        importance: "major",
        is_active: true,
      });
    }

    // Add core lore facts
    for (const fact of loreResponse.lore_facts) {
      loreEntries.push({
        session_id,
        category: "lore",
        subject: `${loreResponse.series_name} Lore`,
        fact,
        importance: fact.toLowerCase().includes("critical") ? "critical" : "major",
        is_active: true,
      });
    }

    // Add power system as critical lore
    loreEntries.push({
      session_id,
      category: "lore",
      subject: "Power System / Magic System",
      fact: loreResponse.power_systems_or_magic,
      importance: "critical",
      is_active: true,
    });

    // Bulk create lore entries
    await base44.entities.WorldState.bulkCreate(loreEntries);

    console.log(`Created ${loreEntries.length} lore entries`);

    // Create CrossSessionMemory nodes if character_id is provided
    let memoryNodesCreated = 0;
    if (character_id) {
      const memoryNodes = [
        {
          character_id,
          memory_type: "shared_event",
          subject: `${loreResponse.series_name} - Series Overview`,
          description: loreResponse.overview,
          session_ids: [session_id],
          emotional_weight: 5,
          reinforcement_count: 1,
        },
        {
          character_id,
          memory_type: "interaction_pattern",
          subject: "Known Character Archetypes",
          description: `Common character types in this universe: ${loreResponse.character_archetypes.join(", ")}`,
          session_ids: [session_id],
          emotional_weight: 3,
          reinforcement_count: 1,
        },
        {
          character_id,
          memory_type: "character_development",
          subject: "Story Themes & Context",
          description: `Major themes: ${loreResponse.story_themes.join(", ")}`,
          session_ids: [session_id],
          emotional_weight: 4,
          reinforcement_count: 1,
        },
      ];

      try {
        await base44.entities.CrossSessionMemory.bulkCreate(memoryNodes);
        memoryNodesCreated = memoryNodes.length;
        console.log(`Created ${memoryNodesCreated} character memory nodes`);
      } catch (memErr) {
        console.warn("Failed to create character memories:", memErr.message);
      }
    }

    return Response.json({
      success: true,
      series_name: loreResponse.series_name,
      lore_entries_created: loreEntries.length,
      memory_nodes_created: memoryNodesCreated,
      lore_summary: {
        overview: loreResponse.overview,
        major_themes: loreResponse.story_themes,
        plot_points_count: loreResponse.major_plot_points.length,
        locations_count: loreResponse.key_locations.length,
      },
    });
  } catch (error) {
    console.error("Series lore ingestion error:", error.message);
    return Response.json(
      { error: error.message || "Lore ingestion failed" },
      { status: 500 }
    );
  }
});