import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id } = await req.json();
    
    if (!session_id) {
      return Response.json({ error: 'session_id required' }, { status: 400 });
    }

    // Fetch the session with recent messages
    const sessions = await base44.entities.ChatSession.filter({ id: session_id });
    if (!sessions || sessions.length === 0) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    const session = sessions[0];
    const characterIds = session.mode === 'solo' ? [session.character_id] : (session.group_character_ids || []);
    
    if (characterIds.length === 0) {
      return Response.json({ success: true, evolved: [] });
    }

    // Fetch all characters in this session
    const characters = await Promise.all(
      characterIds.map(id => base44.entities.Character.list() // We'll filter by id in the next step
        .then(all => all.find(c => c.id === id))
      )
    );

    // Get the last 20 messages for context
    const messages = (session.messages || []).slice(-20);
    
    if (messages.length === 0) {
      return Response.json({ success: true, evolved: [] });
    }

    // Fetch character emotional states and relationships for context
    const emotionalStates = await base44.entities.CharacterEmotionalState.filter({ 
      session_id, 
      is_current: true 
    });

    const relationships = await base44.entities.CharacterRelationship.filter({ 
      session_id 
    });

    // Analyze evolution for each character
    const evolutions = [];

    for (const char of characters) {
      if (!char) continue;

      // Build context for LLM analysis
      const messageContext = messages
        .filter(m => m.character_name === char.name || m.role === 'user')
        .slice(-10)
        .map(m => `${m.character_name || 'User'}: ${m.content}`)
        .join('\n');

      const emotionalState = emotionalStates.find(e => e.character_id === char.id);
      const charRelationships = relationships.filter(r => r.character_id === char.id);

      if (!messageContext.trim()) continue;

      // Use LLM to detect significant trait evolution
      const evolutionPrompt = `Analyze the character "${char.name}" based on their recent interactions in this roleplay session.

CURRENT CHARACTER PROFILE:
Personality: ${char.personality || 'Not defined'}
Backstory: ${char.backstory || 'Not defined'}
Speaking Style: ${char.speaking_style || 'Not defined'}

CURRENT EMOTIONAL STATE:
Primary Emotion: ${emotionalState?.primary_emotion || 'Unknown'}
Intensity: ${emotionalState?.intensity || 0}/100

RECENT INTERACTIONS:
${messageContext}

RELATIONSHIPS IN THIS SESSION:
${charRelationships.map(r => `- ${r.character_id}: Tier ${r.tier} (score ${r.score})`).join('\n') || 'None tracked'}

ANALYSIS:
Identify if there have been significant character evolution shifts. Consider:
1. Has their core personality traits shifted or evolved?
2. Have new character insights been revealed through their actions/dialogue?
3. Has their speaking style changed notably?
4. Have major emotional or narrative revelations affected them?

Only suggest updates if changes are SIGNIFICANT and consistent with the narrative flow. Return null for unchanged traits.`;

      const evolutionData = await base44.integrations.Core.InvokeLLM({
        prompt: evolutionPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            personality_evolved: {
              type: "boolean",
              description: "Has personality significantly evolved?"
            },
            new_personality: {
              type: ["string", "null"],
              description: "Updated personality description if evolved"
            },
            backstory_evolved: {
              type: "boolean",
              description: "Has backstory been meaningfully expanded?"
            },
            new_backstory: {
              type: ["string", "null"],
              description: "Narrative additions to backstory"
            },
            speaking_style_evolved: {
              type: "boolean",
              description: "Has speaking style changed?"
            },
            new_speaking_style: {
              type: ["string", "null"],
              description: "Updated speaking style"
            },
            evolution_summary: {
              type: "string",
              description: "Brief summary of what changed and why"
            }
          }
        }
      });

      // Check if any significant evolution detected
      const hasEvolution = evolutionData.personality_evolved || 
                          evolutionData.backstory_evolved || 
                          evolutionData.speaking_style_evolved;

      if (hasEvolution) {
        // Prepare update with evolved traits
        const updateData = {};
        
        if (evolutionData.personality_evolved && evolutionData.new_personality) {
          updateData.personality = evolutionData.new_personality;
        }
        
        if (evolutionData.backstory_evolved && evolutionData.new_backstory) {
          updateData.backstory = evolutionData.new_backstory;
        }
        
        if (evolutionData.speaking_style_evolved && evolutionData.new_speaking_style) {
          updateData.speaking_style = evolutionData.new_speaking_style;
        }

        // Apply the update to the character
        if (Object.keys(updateData).length > 0) {
          await base44.entities.Character.update(char.id, updateData);
          
          evolutions.push({
            character_id: char.id,
            character_name: char.name,
            evolution_summary: evolutionData.evolution_summary,
            changed_traits: Object.keys(updateData),
            updated_at: new Date().toISOString()
          });
        }
      }
    }

    return Response.json({
      success: true,
      session_id,
      evolved: evolutions,
      count: evolutions.length
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});