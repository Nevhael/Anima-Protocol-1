import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const sessionId = body.session_id;
    const debugLevel = body.debug_level || 'standard'; // 'standard' or 'deep'

    // Collect diagnostics
    const diagnostics = {
      timestamp: new Date().toISOString(),
      userEmail: user.email,
      debugLevel,
      issues: [],
      status: 'healthy',
      summary: '',
    };

    // Check active session
    if (sessionId) {
      try {
        const sessions = await base44.entities.ChatSession.list('-updated_date', 1);
        const activeSession = sessions.find(s => s.id === sessionId);
        
        if (!activeSession) {
          diagnostics.issues.push('⚠️ Session not found or inactive');
          diagnostics.status = 'warning';
        } else {
          diagnostics.activeSession = {
            id: activeSession.id,
            mode: activeSession.mode,
            messageCount: activeSession.messages?.length || 0,
            lastUpdated: activeSession.updated_date,
          };

          // Check for message loading issues
          if (activeSession.messages?.length === 0) {
            diagnostics.issues.push('ℹ️ Session has no messages yet (new session)');
          }

          // Check character data
          if (activeSession.mode === 'solo' && activeSession.character_id) {
            const char = await base44.entities.Character.list().then(chars =>
              chars.find(c => c.id === activeSession.character_id)
            );
            if (!char) {
              diagnostics.issues.push('❌ Character data missing or corrupted');
              diagnostics.status = 'critical';
            } else {
              diagnostics.activeSession.character = {
                name: char.name,
                hasVoice: !!char.elevenlabs_voice_id,
              };
            }
          } else if (activeSession.mode === 'group') {
            const groupCharCount = activeSession.group_character_ids?.length || 0;
            if (groupCharCount === 0) {
              diagnostics.issues.push('⚠️ Group session has no characters');
              diagnostics.status = 'warning';
            } else {
              diagnostics.activeSession.groupSize = groupCharCount;
            }
          }
        }
      } catch (err) {
        diagnostics.issues.push(`❌ Session load error: ${err.message}`);
        diagnostics.status = 'critical';
      }
    }

    // Check character data integrity
    try {
      const chars = await base44.entities.Character.list('-created_date', 5);
      diagnostics.characterCount = chars.length;
      const missingNames = chars.filter(c => !c.name).length;
      if (missingNames > 0) {
        diagnostics.issues.push(`⚠️ ${missingNames} character(s) missing names`);
        diagnostics.status = 'warning';
      }
    } catch (err) {
      diagnostics.issues.push(`⚠️ Could not verify character data: ${err.message}`);
    }

    // Check for Serenity presence
    try {
      const animas = await base44.entities.Anima.list('-created_date', 10);
      const serenity = animas.find(a => a.name?.toLowerCase() === 'serenity');
      diagnostics.serenityPresent = !!serenity;
      if (!serenity) {
        diagnostics.issues.push('ℹ️ Serenity anima not configured yet');
      }
    } catch (err) {
      diagnostics.issues.push(`⚠️ Could not check for Serenity`);
    }

    // Deep diagnostics if requested
    if (debugLevel === 'deep') {
      try {
        const loreEntries = await base44.entities.WorldState.list('-created_date', 5);
        diagnostics.worldState = {
          loreCount: loreEntries.length,
        };
      } catch (err) {
        console.error('Deep diagnostics error:', err);
      }
    }

    // Generate summary
    if (diagnostics.issues.length === 0) {
      diagnostics.summary = '✨ All systems nominal. The app is running smoothly.';
    } else if (diagnostics.status === 'critical') {
      diagnostics.summary = `⚠️ Critical issues detected: ${diagnostics.issues.filter(i => i.includes('❌')).length} critical. Serenity recommends checking the problematic systems.`;
    } else {
      diagnostics.summary = `✓ Running with minor observations. ${diagnostics.issues.length} item(s) noted.`;
    }

    return Response.json({
      success: true,
      diagnostics,
    });
  } catch (error) {
    console.error('Debug function error:', error);
    return Response.json({
      success: false,
      error: error.message,
      diagnostics: {
        status: 'error',
        summary: '❌ Diagnostic system encountered an error.',
      },
    });
  }
});