import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const TRACK_LIBRARY = {
  // Fantasy/Adventure
  forest: {
    name: "Enchanted Forest",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-magical-forest-ambience-1510.mp3",
    tempoRange: [80, 120],
    intensity: 0.6,
  },
  battle: {
    name: "Battle Drums",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-epic-drums-intro-480.mp3",
    tempoRange: [140, 180],
    intensity: 0.9,
  },
  calm: {
    name: "Peaceful Waters",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-calm-lake-ambience-2408.mp3",
    tempoRange: [60, 90],
    intensity: 0.3,
  },
  ancient_ruins: {
    name: "Ancient Whispers",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-ancient-temple-ambience-2664.mp3",
    tempoRange: [70, 110],
    intensity: 0.7,
  },
  city: {
    name: "Urban Pulse",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-tech-forward-upbeat-ambient-11.mp3",
    tempoRange: [100, 140],
    intensity: 0.6,
  },
  dark_mystery: {
    name: "Dark Mystery",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-dark-ambience-1508.mp3",
    tempoRange: [60, 100],
    intensity: 0.8,
  },
  ethereal: {
    name: "Ethereal Realm",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-magic-transition-sparkle-2784.mp3",
    tempoRange: [90, 130],
    intensity: 0.5,
  },
  apocalyptic: {
    name: "Apocalyptic Wasteland",
    baseUrl: "https://assets.mixkit.co/ambient/preview/mixkit-sci-fi-dark-ambient-2711.mp3",
    tempoRange: [75, 115],
    intensity: 0.85,
  },
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { location, emotional_state, narrative_context, character_emotions } = await req.json();

    // Build location-based track preference
    const locationMap = {
      forest: "forest",
      cave: "ancient_ruins",
      dungeon: "dark_mystery",
      temple: "ancient_ruins",
      city: "city",
      town: "calm",
      battle: "battle",
      ruins: "ancient_ruins",
      spirit: "ethereal",
      wasteland: "apocalyptic",
    };

    let trackKey = "calm";
    for (const [locPattern, key] of Object.entries(locationMap)) {
      if (location?.toLowerCase?.().includes(locPattern)) {
        trackKey = key;
        break;
      }
    }

    // Analyze emotional intensity from character emotions
    const emotionalIntensity = character_emotions
      ? Object.values(character_emotions).reduce((max, e) => Math.max(max, e?.intensity || 0), 0) / 10
      : 0.5;

    // If high emotional intensity, shift to more dramatic track
    if (emotionalIntensity > 0.7 && trackKey !== "battle") {
      trackKey = "dark_mystery";
    }

    const track = TRACK_LIBRARY[trackKey];
    const tempo = Math.round(
      track.tempoRange[0] + (track.tempoRange[1] - track.tempoRange[0]) * emotionalIntensity
    );
    const intensity = Math.min(1, track.intensity * (0.5 + emotionalIntensity));

    return Response.json({
      success: true,
      track: {
        id: trackKey,
        name: track.name,
        url: track.baseUrl,
        tempo,
        intensity,
        baseIntensity: track.intensity,
      },
      context: {
        location,
        emotionalIntensity,
        narrativeContext,
      },
    });
  } catch (error) {
    console.error('Ambient audio context error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});