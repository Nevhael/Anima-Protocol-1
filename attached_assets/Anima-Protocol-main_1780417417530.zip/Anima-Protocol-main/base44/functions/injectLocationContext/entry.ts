import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, character_id, character_name } = await req.json();

    if (!session_id || !character_id) {
      return Response.json({ context: '' });
    }

    // Get character's location knowledge
    const memories = await base44.asServiceRole.entities.CharacterMemory.filter({
      character_id,
      category: 'location_knowledge',
    }, '-created_date', 10);

    if (!memories || memories.length === 0) {
      return Response.json({ context: '' });
    }

    // Build location context string
    const locationContext = memories
      .map(m => m.fact)
      .join('\n');

    const contextPrompt = `Based on ${character_name}'s knowledge of their surroundings:

${locationContext}

This character is aware of these locations and their significance. Reference or react to current surroundings naturally when appropriate.`;

    return Response.json({
      success: true,
      context: contextPrompt,
      locations_known: memories.length,
    });
  } catch (error) {
    console.error('Location context injection error:', error);
    return Response.json({ context: '', error: error.message });
  }
});