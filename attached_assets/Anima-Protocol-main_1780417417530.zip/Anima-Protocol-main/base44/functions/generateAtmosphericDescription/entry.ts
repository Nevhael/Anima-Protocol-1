import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, location_name, world_state, character_emotions, recent_messages } = await req.json();

    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch world state details if not provided
    let loreContext = "";
    if (world_state?.loreEntries?.length > 0) {
      const relevantLore = world_state.loreEntries
        .filter(l => l.fact?.toLowerCase().includes(location_name?.toLowerCase()) || l.subject?.toLowerCase().includes(location_name?.toLowerCase()))
        .slice(0, 3);
      loreContext = relevantLore.map(l => `- ${l.subject}: ${l.fact}`).join('\n');
    }

    // Build emotion context
    let emotionContext = "";
    if (character_emotions && Object.keys(character_emotions).length > 0) {
      const emotions = Object.entries(character_emotions)
        .map(([_, e]) => `${e.emotion} (intensity: ${e.intensity}/10)`)
        .join(", ");
      emotionContext = `Current emotional atmosphere: ${emotions}`;
    }

    // Build seasonal context
    let seasonalContext = "";
    if (world_state?.calendar) {
      seasonalContext = `Current season: ${world_state.calendar.current_season} (day ${world_state.calendar.day_of_season}/90)\nWeather: ${world_state.calendar.weather}\nAtmospheric note: ${world_state.calendar.seasonal_description || ''}`;
    }

    const prompt = `Generate a vivid, atmospheric description of the environment for this location in a story context. Make it sensory-rich and reactive to the world state.

LOCATION: ${location_name || "Unknown Location"}

${seasonalContext ? `WORLD STATE:\n${seasonalContext}\n` : ""}

${emotionContext ? `${emotionContext}\n` : ""}

${loreContext ? `RELEVANT LORE:\n${loreContext}\n` : ""}

Requirements:
- 2-3 sentences maximum, punchy and immersive
- Focus on sensory details (sight, sound, smell, touch, temperature)
- Reflect the emotional tone if characters are experiencing strong emotions
- Make it feel alive and reactive to the current moment
- Use literary, evocative language
- Do NOT include narrative direction or character actions — only environmental description
- Start directly with the description, no preamble

Respond with ONLY the atmospheric description, nothing else.`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });

    return Response.json({
      description: result?.trim() || "",
      location: location_name,
      generated_at: new Date().toISOString()
    });
  } catch (error) {
    console.error('Atmospheric description error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});