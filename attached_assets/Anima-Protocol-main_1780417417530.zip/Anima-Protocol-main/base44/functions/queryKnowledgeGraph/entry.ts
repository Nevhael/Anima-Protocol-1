import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { query, limit = 10 } = await req.json();

    if (!query) {
      return Response.json({ error: 'Query required' }, { status: 400 });
    }

    // Fetch the user's knowledge graph
    const graphs = await base44.entities.KnowledgeGraph.filter({
      user_email: user.email,
      is_active: true
    });

    if (!graphs || graphs.length === 0) {
      return Response.json({
        results: [],
        message: 'No knowledge graph built yet. Upload documents first.'
      });
    }

    const graph = graphs[0];

    // Search for matching nodes
    const lowerQuery = query.toLowerCase();
    const matchingNodes = graph.nodes.filter(node =>
      node.label.toLowerCase().includes(lowerQuery) ||
      node.description.toLowerCase().includes(lowerQuery)
    ).slice(0, limit);

    // For each matching node, find connected nodes
    const connectedInfo = matchingNodes.map(node => {
      const connections = graph.edges
        .filter(edge =>
          edge.from_node_id === node.id || edge.to_node_id === node.id
        )
        .map(edge => {
          const connectedId = edge.from_node_id === node.id ? edge.to_node_id : edge.from_node_id;
          const connectedNode = graph.nodes.find(n => n.id === connectedId);
          return {
            label: connectedNode?.label || connectedId,
            relation: edge.relation_type,
            strength: edge.strength
          };
        });

      return {
        entity: node.label,
        type: node.type,
        description: node.description,
        appears_in: node.source_documents.length,
        frequency: node.frequency,
        connected_entities: connections
      };
    });

    return Response.json({
      query,
      results: connectedInfo,
      graph_stats: {
        total_entities: graph.total_entities,
        total_documents: graph.document_count,
        total_relationships: graph.edges.length
      }
    });
  } catch (error) {
    console.error('Knowledge graph query error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});