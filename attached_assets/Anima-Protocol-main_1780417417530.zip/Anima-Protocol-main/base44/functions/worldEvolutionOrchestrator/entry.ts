import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    
    const { session_id, force = false } = body;

    if (!session_id) {
      return Response.json({ error: 'session_id required' }, { status: 400 });
    }

    // Fetch the session to get context
    const session = await base44.entities.ChatSession.list().then(sessions =>
      sessions.find(s => s.id === session_id)
    );

    if (!session) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    // Fetch recent world state and narrative context
    const [worldStates, factions, locations, recentMessages] = await Promise.all([
      base44.entities.WorldState.filter({ session_id, is_active: true }, '-updated_date', 50),
      base44.entities.Faction.filter({ origin_session: session_id }, '-created_date', 20),
      base44.entities.Location.filter({ origin_session: session_id }, '-created_date', 20),
      base44.entities.ChatSession.list().then(s => 
        s.find(x => x.id === session_id)?.messages || []
      ),
    ]);

    // Determine if world evolution should trigger
    const messageCount = recentMessages?.length || 0;
    const shouldEvolve = force || (messageCount % 8 === 0 && messageCount > 0);

    if (!shouldEvolve) {
      return Response.json({ 
        success: false, 
        reason: 'Evolution not yet triggered',
        message_count: messageCount,
      });
    }

    // Synthesize current narrative state
    const recentContext = recentMessages.slice(-12).map(m => ({
      role: m.role,
      character: m.character_name,
      content: m.content?.slice(0, 200),
    }));

    const synthesisPrompt = `You are a world simulation engine. Based on recent narrative events, synthesize how the world should evolve:

Recent Events (last 12 messages):
${recentContext.map(e => `[${e.character}] ${e.content}`).join('\n')}

Current World State:
- Factions: ${factions?.map(f => `${f.name} (${f.status}, power: ${f.power_level}/10)`).join('; ') || 'None'}
- Active Locations: ${locations?.map(l => l.name).join(', ') || 'None'}
- World Events: ${worldStates?.map(w => w.subject).join(', ') || 'None'}

Generate a JSON response with world evolution changes:
{
  "political_shifts": [
    { "faction_name": "string", "power_change": -5 to 5, "reason": "brief explanation" }
  ],
  "environmental_changes": [
    { "location_name": "string", "change_type": "drought|flood|war|peace|discovery", "severity": 1-10, "description": "brief" }
  ],
  "faction_events": [
    { "faction_name": "string", "event_type": "ally|rival|conflict|expansion|decline", "target_faction": "string or null", "impact": "brief narrative" }
  ],
  "new_world_state": {
    "subject": "event name",
    "category": "political|environmental|social|discovery",
    "fact": "specific fact established",
    "importance": "minor|notable|major|central"
  }
}`;

    const synthesisResult = await base44.integrations.Core.InvokeLLM({
      prompt: synthesisPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          political_shifts: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                faction_name: { type: 'string' },
                power_change: { type: 'number' },
                reason: { type: 'string' },
              },
            },
          },
          environmental_changes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                location_name: { type: 'string' },
                change_type: { type: 'string' },
                severity: { type: 'number' },
                description: { type: 'string' },
              },
            },
          },
          faction_events: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                faction_name: { type: 'string' },
                event_type: { type: 'string' },
                target_faction: { type: 'string' },
                impact: { type: 'string' },
              },
            },
          },
          new_world_state: {
            type: 'object',
            properties: {
              subject: { type: 'string' },
              category: { type: 'string' },
              fact: { type: 'string' },
              importance: { type: 'string' },
            },
          },
        },
      },
    });

    const evolution = synthesisResult;
    const updates = {
      political_shifts: [],
      environmental_changes: [],
      faction_events: [],
      new_world_state: null,
    };

    // Apply political shifts to factions
    if (evolution.political_shifts?.length > 0) {
      for (const shift of evolution.political_shifts) {
        const faction = factions?.find(f => f.name.toLowerCase() === shift.faction_name.toLowerCase());
        if (faction) {
          const newPowerLevel = Math.max(0, Math.min(10, (faction.power_level || 5) + shift.power_change));
          await base44.entities.Faction.update(faction.id, {
            power_level: newPowerLevel,
            status: newPowerLevel > 7 ? 'rising' : newPowerLevel < 3 ? 'declining' : faction.status,
          });
          updates.political_shifts.push({
            faction: shift.faction_name,
            new_power: newPowerLevel,
            reason: shift.reason,
          });
        }
      }
    }

    // Create environmental change world states
    if (evolution.environmental_changes?.length > 0) {
      for (const envChange of evolution.environmental_changes) {
        await base44.entities.WorldState.create({
          session_id,
          subject: envChange.location_name,
          category: 'environmental',
          fact: `${envChange.change_type}: ${envChange.description}`,
          importance: envChange.severity >= 8 ? 'major' : envChange.severity >= 5 ? 'notable' : 'minor',
          is_active: true,
        });
        updates.environmental_changes.push(envChange);
      }
    }

    // Record faction events
    if (evolution.faction_events?.length > 0) {
      for (const factionEvent of evolution.faction_events) {
        const eventFaction = factions?.find(f => f.name.toLowerCase() === factionEvent.faction_name.toLowerCase());
        if (eventFaction) {
          // Create world state for the event
          await base44.entities.WorldState.create({
            session_id,
            subject: `${factionEvent.faction_name} ${factionEvent.event_type}`,
            category: 'political',
            fact: factionEvent.impact,
            importance: 'notable',
            is_active: true,
          });

          // Update faction relationships
          if (factionEvent.target_faction && factionEvent.event_type === 'ally') {
            const targetFaction = factions?.find(f => f.name.toLowerCase() === factionEvent.target_faction.toLowerCase());
            if (targetFaction) {
              const updatedAllies = [...(eventFaction.allies || [])];
              if (!updatedAllies.includes(targetFaction.id)) {
                updatedAllies.push(targetFaction.id);
              }
              await base44.entities.Faction.update(eventFaction.id, {
                allies: updatedAllies,
              });
            }
          }

          if (factionEvent.target_faction && factionEvent.event_type === 'rival') {
            const targetFaction = factions?.find(f => f.name.toLowerCase() === factionEvent.target_faction.toLowerCase());
            if (targetFaction) {
              const updatedRivals = [...(eventFaction.rivals || [])];
              if (!updatedRivals.includes(targetFaction.id)) {
                updatedRivals.push(targetFaction.id);
              }
              await base44.entities.Faction.update(eventFaction.id, {
                rivals: updatedRivals,
              });
            }
          }

          updates.faction_events.push(factionEvent);
        }
      }
    }

    // Create new world state entry
    if (evolution.new_world_state) {
      const newWorldState = await base44.entities.WorldState.create({
        session_id,
        subject: evolution.new_world_state.subject,
        category: evolution.new_world_state.category || 'discovery',
        fact: evolution.new_world_state.fact,
        importance: evolution.new_world_state.importance || 'notable',
        is_active: true,
      });
      updates.new_world_state = newWorldState;
    }

    console.log(`World evolution completed for session ${session_id}:`, {
      political_shifts: updates.political_shifts.length,
      environmental_changes: updates.environmental_changes.length,
      faction_events: updates.faction_events.length,
    });

    return Response.json({
      success: true,
      message_count: messageCount,
      evolution: {
        political_shifts: updates.political_shifts,
        environmental_changes: updates.environmental_changes,
        faction_events: updates.faction_events,
        new_world_state: updates.new_world_state,
      },
    });
  } catch (error) {
    console.error('World evolution orchestrator error:', error);
    return Response.json(
      { error: error.message, success: false },
      { status: 500 }
    );
  }
});