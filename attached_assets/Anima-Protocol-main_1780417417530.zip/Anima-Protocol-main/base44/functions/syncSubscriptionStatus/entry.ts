import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@16.2.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { subscription_id, customer_email } = await req.json();

    if (!subscription_id || !customer_email) {
      return Response.json(
        { error: 'Missing subscription_id or customer_email' },
        { status: 400 }
      );
    }

    // Fetch subscription from Stripe
    const subscription = await stripe.subscriptions.retrieve(subscription_id);

    // Determine tier based on subscription status
    let userTier = 'user'; // Default tier
    if (subscription.status === 'active' || subscription.status === 'trialing') {
      userTier = 'premium';
    } else if (subscription.status === 'past_due') {
      userTier = 'user'; // Downgrade if past due
    }

    console.log(`[Sync Subscription] ${customer_email} -> ${userTier} (status: ${subscription.status})`);

    // Update user tier
    const users = await base44.asServiceRole.entities.User.filter({
      email: customer_email,
    });

    if (users && users.length > 0) {
      const user = users[0];
      await base44.asServiceRole.entities.User.update(user.id, {
        role: userTier,
        settings: {
          ...user.settings,
          subscription_id,
          subscription_status: subscription.status,
          subscription_updated: new Date().toISOString(),
        },
      });

      console.log(`[Sync Subscription] Updated ${customer_email} to ${userTier}`);
      return Response.json({
        success: true,
        user_id: user.id,
        tier: userTier,
        subscription_status: subscription.status,
      });
    } else {
      console.warn(`[Sync Subscription] User not found: ${customer_email}`);
      return Response.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('[Sync Subscription] Error:', error.message);
    return Response.json(
      { error: `Sync error: ${error.message}` },
      { status: 500 }
    );
  }
});