import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { prompt } = await req.json();
    
    if (!prompt || prompt.trim().length < 20) {
      return Response.json({ 
        error: 'Prompt must be at least 20 characters long. More detail = better companion.' 
      }, { status: 400 });
    }

    // Generate companion details from detailed prompt
    const generationPrompt = `You are an AI character generator. Based on this detailed description, create a complete companion profile in JSON format.

USER PROMPT:
${prompt}

Generate a JSON object with ONLY these fields (no markdown, just raw JSON):
{
  "name": "string (1-3 words, compelling name)",
  "universe": "string (series, world, or original)",
  "personality": "string (2-3 sentences describing personality, quirks, strengths, flaws)",
  "backstory": "string (detailed background, origins, key life events, 2-3 paragraphs)",
  "speaking_style": "string (how they talk - tone, accent, distinctive phrases, communication patterns)",
  "category": "string (one of: companion, mystic, sage, trickster, shadow, lover, explorer, oracle)",
  "tagline": "string (one short memorable line that defines them)"
}

Focus on creating a unique, memorable character that matches the user's vision as closely as possible. The more detailed the user's prompt, the more nuanced and specific the character should be.`;

    const result = await base44.integrations.Core.InvokeLLM({ 
      prompt: generationPrompt,
      model: "gpt_5_4"
    });

    // Parse the JSON response
    let companion;
    try {
      companion = JSON.parse(result);
    } catch (parseErr) {
      // Try to extract JSON from response if wrapped in markdown
      const jsonMatch = result.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        companion = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('Failed to parse companion data');
      }
    }

    // Create the companion as a character in the database
    const created = await base44.entities.Character.create({
      name: companion.name,
      universe: companion.universe,
      personality: companion.personality,
      backstory: companion.backstory,
      speaking_style: companion.speaking_style,
      category: companion.category,
      status: "online",
      is_default: false,
    });

    return Response.json({ 
      success: true,
      companion: {
        id: created.id,
        ...companion
      }
    });
  } catch (error) {
    console.error('Error generating companion:', error);
    return Response.json({ 
      error: error.message || 'Failed to generate companion'
    }, { status: 500 });
  }
});