import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'POST only' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { name, universe } = await req.json();

    if (!name || !universe) {
      return Response.json({ error: 'name and universe required' }, { status: 400 });
    }

    // Call InvokeLLM to generate personality traits
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate detailed personality traits for the character "${name}" from "${universe}". 
      
      Respond with a JSON object containing exactly these fields (all strings):
      {
        "personality": "A 2-3 sentence description of their personality, behavior patterns, and how they interact with others",
        "backstory": "A 1-2 sentence summary of their background and how it shaped them",
        "speaking_style": "A 1-2 sentence description of their unique way of speaking, vocabulary, tone, and mannerisms"
      }
      
      Be specific to this character. Keep descriptions concise but vivid.`,
      response_json_schema: {
        type: 'object',
        properties: {
          personality: { type: 'string' },
          backstory: { type: 'string' },
          speaking_style: { type: 'string' }
        },
        required: ['personality', 'backstory', 'speaking_style']
      }
    });

    return Response.json({
      name,
      universe,
      personality: result.personality,
      backstory: result.backstory,
      speaking_style: result.speaking_style
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});