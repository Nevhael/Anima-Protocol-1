import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    // Fetch current emotional states for all characters in session
    const emotionalStates = await base44.entities.CharacterEmotionalState.filter(
      { session_id, is_current: true },
      "-created_date",
      100
    );

    // Fetch characters to get names
    const characters = await base44.entities.Character.list("-created_date", 100);

    // Fetch recent world events
    const worldEvents = await base44.entities.WorldState.filter(
      { session_id, is_active: true },
      "-created_date",
      20
    );

    // Aggregate emotional data
    const emotionCounts = {};
    const characterEmotions = [];
    let avgIntensity = 0;

    emotionalStates?.forEach(state => {
      const char = characters?.find(c => c.id === state.character_id);
      emotionCounts[state.primary_emotion] = (emotionCounts[state.primary_emotion] || 0) + 1;
      avgIntensity += state.intensity || 0;
      characterEmotions.push({
        character_id: state.character_id,
        character_name: char?.name || 'Unknown',
        emotion: state.primary_emotion,
        intensity: state.intensity || 5,
        secondary: state.secondary_emotion,
        trigger: state.trigger,
      });
    });

    avgIntensity = emotionalStates?.length > 0 ? Math.round(avgIntensity / emotionalStates.length) : 0;

    // Determine overall climate
    const dominantEmotion = Object.keys(emotionCounts).reduce((a, b) =>
      emotionCounts[a] > emotionCounts[b] ? a : b
    ) || 'neutral';

    // Categorize tone
    const toneMappings = {
      joyful: 'uplifting',
      calm: 'serene',
      sad: 'melancholic',
      angry: 'tense',
      afraid: 'ominous',
      hopeful: 'optimistic',
      conflicted: 'turbulent',
      desperate: 'crisis',
      peaceful: 'serene',
    };

    return Response.json({
      success: true,
      emotional_climate: {
        dominant_emotion: dominantEmotion,
        narrative_tone: toneMappings[dominantEmotion] || 'complex',
        average_intensity: avgIntensity,
        total_characters: emotionalStates?.length || 0,
        emotion_distribution: emotionCounts,
      },
      character_emotions: characterEmotions,
      recent_events: (worldEvents || []).slice(0, 10).map(e => ({
        subject: e.subject,
        fact: e.fact,
        category: e.category,
        importance: e.importance,
      })),
    });
  } catch (error) {
    console.error('Emotional climate analysis error:', error);
    return Response.json(
      { error: error.message || 'Failed to analyze emotional climate' },
      { status: 500 }
    );
  }
});