import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { character_id, session_transcript, ritual_focus, reflection } = await req.json();

    if (!character_id || !session_transcript) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Load current character
    const characters = await base44.entities.Character.list();
    const character = characters.find(c => c.id === character_id);
    if (!character) return Response.json({ error: 'Character not found' }, { status: 404 });

    // Ask the LLM how this sacred space experience should shape the character
    const impactPrompt = `You are analyzing how a Sacred Space / meditation experience between a user and the character "${character.name}" should permanently evolve that character.

CHARACTER CURRENT STATE:
Name: ${character.name}
Personality: ${character.personality || 'Not defined'}
Speaking Style: ${character.speaking_style || 'Not defined'}
Backstory: ${character.backstory || 'Not defined'}

SACRED SPACE SESSION:
Ritual Focus: ${ritual_focus || 'General wellness'}
Session Transcript:
${session_transcript}

User's Reflection: ${reflection || 'None provided'}

Based on this intimate Sacred Space session, describe:
1. How the character's personality subtly shifts (they witnessed the user's vulnerability, intentions, and inner world)
2. How their speaking style with this specific user might soften, deepen, or change
3. A new memory or insight the character gained about the user

Be subtle — these are small, meaningful shifts, not complete personality rewrites. The character becomes more attuned to this user.

Respond in JSON:
{
  "personality_addition": "A 1-2 sentence addition to append to their personality, reflecting how this experience changed them",
  "speaking_style_note": "A single sentence addition about how they now speak differently with this user",
  "new_memory": "A specific memory/insight the character now holds about this user from the Sacred Space session",
  "emotional_shift": "One word describing the dominant emotional shift (e.g. 'softer', 'reverent', 'protective', 'connected')"
}`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: impactPrompt,
      response_json_schema: {
        type: "object",
        properties: {
          personality_addition: { type: "string" },
          speaking_style_note: { type: "string" },
          new_memory: { type: "string" },
          emotional_shift: { type: "string" }
        }
      }
    });

    // Apply the personality and speaking style updates to the character
    const updatedPersonality = [character.personality, result.personality_addition].filter(Boolean).join('\n\n[After Sacred Space with user]: ') + '';
    const updatedSpeakingStyle = [character.speaking_style, result.speaking_style_note].filter(Boolean).join('\n[Sacred Space note]: ');

    await base44.asServiceRole.entities.Character.update(character_id, {
      personality: updatedPersonality,
      speaking_style: updatedSpeakingStyle,
    });

    // Also store as a cross-session memory
    await base44.asServiceRole.entities.CrossSessionMemory.create({
      character_id: character_id,
      memory_type: 'emotional_moment',
      subject: `Sacred Space session — ${ritual_focus || 'General'}`,
      description: result.new_memory,
      related_character_id: null,
      session_ids: [],
      emotional_weight: 8,
      relationship_impact: 3,
      last_reinforced: new Date().toISOString(),
      reinforcement_count: 1,
      relevance_score: 0.85,
      tags: ['sacred_space', 'meditation', 'intimate', ritual_focus || 'wellness'].filter(Boolean),
    });

    return Response.json({
      success: true,
      emotional_shift: result.emotional_shift,
      personality_addition: result.personality_addition,
      new_memory: result.new_memory,
    });
  } catch (error) {
    console.error('sacredSpaceImpact error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});