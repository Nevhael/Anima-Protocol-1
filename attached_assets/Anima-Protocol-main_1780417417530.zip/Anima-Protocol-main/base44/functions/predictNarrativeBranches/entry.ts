import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, last_user_choice, recent_messages, character_emotions, relationships } = await req.json();

    // Generate narrative branches based on user choice
    const prompt = `You are a narrative designer analyzing potential story branches from a user decision.

User's choice: "${last_user_choice}"

Recent story context: ${recent_messages.slice(-3).map(m => `${m.character_name}: ${m.content}`).join('\n')}

Character emotional states: ${Object.entries(character_emotions || {}).map(([id, emotion]) => `${id}: ${emotion.emotion || 'neutral'}`).join(', ')}

Generate 3-5 potential narrative branches that could result from this choice. Each branch should have:
1. A unique path name
2. Probability (likelihood this path is taken)
3. Key consequences (3-4 bullet points)
4. Characters most affected
5. Estimated difficulty/impact (1-10 scale)
6. Prerequisites or locks (what would unlock this path?)

Format as JSON array of branches.`;

    const branchResult = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          branches: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                probability: { type: 'number' },
                consequences: { type: 'array', items: { type: 'string' } },
                affected_characters: { type: 'array', items: { type: 'string' } },
                impact_level: { type: 'number' },
                prerequisites: { type: 'array', items: { type: 'string' } },
                description: { type: 'string' },
              },
            },
          },
        },
      },
    });

    const branches = branchResult?.branches || [];

    // Analyze which branches are "locked" based on current state
    const analyzedBranches = branches.map(branch => {
      const isLocked = branch.prerequisites?.some(prereq =>
        !recent_messages.some(m => m.content?.toLowerCase().includes(prereq.toLowerCase()))
      );

      return {
        ...branch,
        id: branch.name.toLowerCase().replace(/\s+/g, '_'),
        status: isLocked ? 'locked' : 'available',
        discovered: false,
      };
    });

    // Store branch data for this session
    await base44.functions.invoke('storeBranchDecisions', {
      session_id,
      branches: analyzedBranches,
      triggering_choice: last_user_choice,
      timestamp: new Date().toISOString(),
    }).catch(() => {});

    return Response.json({
      branches: analyzedBranches,
      decision_point: last_user_choice,
      total_paths: analyzedBranches.length,
      locked_count: analyzedBranches.filter(b => b.status === 'locked').length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});