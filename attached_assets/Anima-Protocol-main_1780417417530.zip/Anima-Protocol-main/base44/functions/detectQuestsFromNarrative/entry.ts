import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { session_id, narrative_text, existing_quests } = await req.json();

    if (!session_id || !narrative_text) {
      return Response.json({
        error: "Missing session_id or narrative_text",
      }, { status: 400 });
    }

    const lowerText = narrative_text.toLowerCase();
    const detectedQuests = [];

    // Quest detection patterns
    const questPatterns = [
      // Direct quest mentions
      {
        pattern: /(?:accept|receive|get|take|start)(?:ed|s)?\s+(?:the\s+)?(?:quest|mission|objective|task)\s+(?:named\s+)?[:\s]*['""]?([^.!?"'"'\n]+)['""]?/gi,
        difficulty: "moderate",
        description: "A quest assigned by an NPC",
      },
      // Goal-based patterns
      {
        pattern: /(?:must|need|should|have\s+to)(?:\s+now)?\s+([a-z\s]{5,60}?)(?:\s+(?:in|at|from|to|by|before))/gi,
        difficulty: "moderate",
        description: "A goal that has emerged in the narrative",
      },
      // Protection/rescue patterns
      {
        pattern: /(?:protect|rescue|save|defend)\s+(?:the\s+)?([a-z\s]{3,40}?)(?:\s+(?:from|against|in|at))/gi,
        difficulty: "hard",
        description: "A protective mission",
      },
      // Investigation/discovery patterns
      {
        pattern: /(?:investigate|discover|find|search|look\s+for)\s+(?:the\s+)?([a-z\s]{3,40}?)(?:\s+(?:in|at|to|before))/gi,
        difficulty: "moderate",
        description: "An investigative quest",
      },
      // Collection patterns
      {
        pattern: /(?:collect|gather|bring|acquire|obtain)\s+(?:the\s+)?(\d+)?\s*([a-z\s]{3,40}?)(?:\s+(?:for|to|from|in))/gi,
        difficulty: "easy",
        description: "A collection quest",
      },
      // Defeat/combat patterns
      {
        pattern: /(?:defeat|kill|slay|destroy|eliminate)\s+(?:the\s+)?([a-z\s]{3,40}?)(?:\s+(?:in|at|to|before))/gi,
        difficulty: "hard",
        description: "A combat objective",
      },
    ];

    const detectedNames = new Set(existing_quests.map(q => q.title.toLowerCase()));
    const matches = new Map();

    // Run pattern detection
    for (const { pattern, difficulty, description } of questPatterns) {
      let match;
      const regex = new RegExp(pattern.source, "gi");

      while ((match = regex.exec(lowerText)) !== null) {
        let questName = match[1]?.trim() || match[2]?.trim();

        if (
          questName &&
          questName.length > 3 &&
          questName.length < 100 &&
          !questName.match(/^(the|a|an|and|or|but|because|since|while|when)\b/i)
        ) {
          // Normalize quest name
          questName = questName
            .split(/\s+/)
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ")
            .replace(/^(The|A|An)\s+/, "");

          const key = questName.toLowerCase();

          if (!detectedNames.has(key) && !matches.has(key)) {
            matches.set(key, {
              title: questName,
              description,
              difficulty,
              status: "active",
              objectives: [
                { description: `${description}`, completed: false },
              ],
              rewards: { xp: getDifficultyXP(difficulty), items: [] },
            });
          }
        }
      }
    }

    // Check for quest completion indicators
    for (const quest of existing_quests) {
      const questLower = quest.title.toLowerCase();
      if (
        (lowerText.includes(`completed ${questLower}`) ||
          lowerText.includes(`finished ${questLower}`) ||
          lowerText.includes(`${questLower} is complete`) ||
          lowerText.includes(`${questLower} done`)) &&
        quest.status !== "completed"
      ) {
        // Would need to update via database, but we just detect here
      }
    }

    const detectedQuestsList = Array.from(matches.values()).slice(0, 5); // Limit to 5 per parse

    return Response.json({
      success: true,
      detected_quests: detectedQuestsList,
      count: detectedQuestsList.length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function getDifficultyXP(difficulty) {
  const xpMap = {
    trivial: 50,
    easy: 100,
    moderate: 250,
    hard: 500,
    legendary: 1000,
  };
  return xpMap[difficulty] || 250;
}