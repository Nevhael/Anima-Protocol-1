import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { username } = await req.json();

    if (!username || typeof username !== 'string') {
      return Response.json({ error: 'Username is required' }, { status: 400 });
    }

    const apiKey = Deno.env.get('YN_APP_API_KEY');
    if (!apiKey) {
      return Response.json({ 
        error: 'Y/n API not configured' 
      }, { status: 500 });
    }

    // Fetch user's stories from Y/n API
    const apiUrl = `https://yn.app/api/v1/users/${encodeURIComponent(username)}/stories`;
    
    const response = await fetch(apiUrl, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0'
      }
    });

    if (!response.ok) {
      return Response.json({ 
        error: `Failed to fetch stories: ${response.statusText}` 
      }, { status: response.status });
    }

    const data = await response.json();
    const stories = data.stories || data.data || [];

    if (!Array.isArray(stories)) {
      return Response.json({ 
        error: 'Invalid response format from Y/n API' 
      }, { status: 400 });
    }

    return Response.json({
      stories: stories.map(s => ({
        id: s.id,
        title: s.title || s.name || 'Untitled',
        content: s.content || s.text || s.body || '',
        author: s.author || username,
      }))
    });
  } catch (error) {
    console.error('Error fetching Y/n stories:', error);
    return Response.json(
      { error: error.message || 'Failed to fetch stories' },
      { status: 500 }
    );
  }
});