import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { session_id, messages } = await req.json();

    if (!session_id || !messages || messages.length === 0) {
      return Response.json({
        success: false,
        extracted: 0,
        message: "No messages provided",
      });
    }

    // Extract dialogue from recent messages
    const recentText = messages
      .slice(-20)
      .map((m) => m.content || "")
      .join("\n");

    // Use LLM to detect world-building elements
    const analysisPrompt = `Analyze this story dialogue and extract world-building details:

${recentText}

Return a JSON object with arrays of:
{
  "locations": [{"name": "...", "description": "..."}],
  "factions": [{"name": "...", "description": "...", "alignment": "..."}],
  "artifacts": [{"name": "...", "description": "...", "significance": "..."}],
  "customs": [{"name": "...", "description": "..."}],
  "rules": [{"name": "...", "description": "..."}]
}

Only include NEW details not already mentioned. Be concise.`;

    const analysisResult = await base44.integrations.Core.InvokeLLM({
      prompt: analysisPrompt,
      response_json_schema: {
        type: "object",
        properties: {
          locations: {
            type: "array",
            items: { type: "object" },
          },
          factions: {
            type: "array",
            items: { type: "object" },
          },
          artifacts: {
            type: "array",
            items: { type: "object" },
          },
          customs: {
            type: "array",
            items: { type: "object" },
          },
          rules: {
            type: "array",
            items: { type: "object" },
          },
        },
      },
    });

    const extracted = analysisResult;
    let created = 0;

    // Create PendingDiscovery entries for manual review
    if (extracted.locations?.length > 0) {
      for (const loc of extracted.locations) {
        await base44.entities.PendingDiscovery.create({
          session_id,
          discovery_type: "location",
          subject: loc.name,
          description: loc.description,
          context: recentText.slice(0, 500),
          confidence: 0.85,
          status: "pending",
          message_index: messages.length - 1,
        });
        created++;
      }
    }

    if (extracted.factions?.length > 0) {
      for (const faction of extracted.factions) {
        await base44.entities.PendingDiscovery.create({
          session_id,
          discovery_type: "faction",
          subject: faction.name,
          description: faction.description,
          context: recentText.slice(0, 500),
          confidence: 0.8,
          status: "pending",
          message_index: messages.length - 1,
        });
        created++;
      }
    }

    if (extracted.artifacts?.length > 0) {
      for (const artifact of extracted.artifacts) {
        await base44.entities.PendingDiscovery.create({
          session_id,
          discovery_type: "artifact",
          subject: artifact.name,
          description: artifact.description,
          context: recentText.slice(0, 500),
          confidence: 0.8,
          status: "pending",
          message_index: messages.length - 1,
        });
        created++;
      }
    }

    if (extracted.customs?.length > 0) {
      for (const custom of extracted.customs) {
        await base44.entities.PendingDiscovery.create({
          session_id,
          discovery_type: "event",
          subject: `Custom: ${custom.name}`,
          description: custom.description,
          context: recentText.slice(0, 500),
          confidence: 0.75,
          status: "pending",
          message_index: messages.length - 1,
        });
        created++;
      }
    }

    if (extracted.rules?.length > 0) {
      for (const rule of extracted.rules) {
        await base44.entities.PendingDiscovery.create({
          session_id,
          discovery_type: "history",
          subject: `World Rule: ${rule.name}`,
          description: rule.description,
          context: recentText.slice(0, 500),
          confidence: 0.75,
          status: "pending",
          message_index: messages.length - 1,
        });
        created++;
      }
    }

    return Response.json({
      success: true,
      extracted: created,
      details: extracted,
    });
  } catch (error) {
    console.error("Lore extraction error:", error);
    return Response.json(
      { error: error.message, success: false },
      { status: 500 }
    );
  }
});