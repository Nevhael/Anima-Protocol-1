import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, recent_messages, character_id } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    // Fetch recent world events that should influence narrative
    const recentEvents = await base44.entities.WorldState.filter(
      { session_id, is_active: true },
      '-created_date',
      20
    );

    // Extract event consequences and themes
    const eventThemes = [];
    const eventConsequences = [];
    let cumulativeTension = 0;

    (recentEvents || []).forEach(event => {
      if (event.subject) eventThemes.push(event.subject);
      if (event.fact) eventConsequences.push(event.fact);
      if (event.importance === 'critical') cumulativeTension += 40;
      else if (event.importance === 'major') cumulativeTension += 25;
      else cumulativeTension += 10;
    });

    // Build narrative constraints from events
    const narrativeConstraints = {
      themes: [...new Set(eventThemes)].slice(0, 5),
      recentConsequences: eventConsequences.slice(0, 3),
      currentTension: Math.min(100, cumulativeTension),
      eventCount: recentEvents?.length || 0,
    };

    // Generate event-driven narrative direction
    const eventNarrativePrompt = `
You are a narrative director analyzing recent story events to shape the next narrative development.

Recent events and consequences:
${eventConsequences.join('\n')}

Current story themes:
${eventThemes.join(', ')}

Tension level: ${narrativeConstraints.currentTension}%

Based on these events:
1. What are the 3 most likely next narrative developments?
2. What character arcs should be affected?
3. What new conflicts or resolutions might emerge?
4. How should the emotional tone shift?

Respond in JSON format with:
{
  "likely_developments": ["development1", "development2", "development3"],
  "character_impacts": ["character_id: impact"],
  "emerging_conflicts": ["conflict1", "conflict2"],
  "tone_shift": "description of emotional shift",
  "recommended_pacing": "slow|normal|fast"
}`;

    // Invoke LLM for narrative direction
    const narrativeDirection = await base44.integrations.Core.InvokeLLM({
      prompt: eventNarrativePrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          likely_developments: { type: 'array', items: { type: 'string' } },
          character_impacts: { type: 'array', items: { type: 'string' } },
          emerging_conflicts: { type: 'array', items: { type: 'string' } },
          tone_shift: { type: 'string' },
          recommended_pacing: { type: 'string' },
        },
      },
    });

    // Create narrative arc from event analysis
    const arcData = {
      arc_type: 'plot_arc',
      title: `Event-Driven Arc: ${eventThemes[0] || 'Unfolding Narrative'}`,
      description: narrativeDirection.tone_shift,
      first_appearance_session: session_id,
      related_sessions: [session_id],
      related_characters: [],
      status: 'active',
      emotional_weight: Math.ceil(narrativeConstraints.currentTension / 10),
      last_referenced: new Date().toISOString(),
      key_events: (narrativeDirection.likely_developments || []).map((dev, idx) => ({
        session_id,
        message_index: recent_messages?.length || 0,
        description: dev,
      })),
    };

    // Store the narrative arc
    const createdArc = await base44.entities.NarrativeArc.create(arcData).catch(() => null);

    // Return event-driven story flow guidance
    return Response.json({
      success: true,
      constraints: narrativeConstraints,
      narrative_direction: narrativeDirection,
      arc_created: !!createdArc,
      story_flow: {
        description: 'Events dictating narrative flow',
        next_developments: narrativeDirection.likely_developments,
        emotional_trajectory: narrativeDirection.tone_shift,
        pacing: narrativeDirection.recommended_pacing,
        affected_characters: narrativeDirection.character_impacts,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});