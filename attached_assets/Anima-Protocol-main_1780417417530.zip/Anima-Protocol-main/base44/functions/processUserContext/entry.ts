import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { user_context_id, file_url, file_content, is_pdf, document_type, title } = await req.json();

    if (!user_context_id) {
      return Response.json({ error: 'Missing user_context_id' }, { status: 400 });
    }

    let text = '';

    // For PDFs, use ExtractDataFromUploadedFile to properly extract text
    if (is_pdf && file_url) {
      try {
        const extracted = await base44.integrations.Core.ExtractDataFromUploadedFile({
          file_url,
          json_schema: {
            type: 'object',
            properties: {
              full_text: { type: 'string', description: 'All text content extracted from the document' },
            },
          },
        });
        if (extracted?.status === 'success' && extracted?.output?.full_text) {
          text = extracted.output.full_text;
        } else {
          console.warn('PDF extraction returned no text:', extracted?.details);
          text = '[PDF content could not be extracted]';
        }
      } catch (pdfErr) {
        console.error('PDF extraction error:', pdfErr);
        text = '[PDF content could not be extracted]';
      }
    } else {
      text = typeof file_content === 'string' ? file_content : '';
    }

    const wordCount = text.split(/\s+/).filter(Boolean).length;

    const extractionPrompt = `Analyze this ${document_type || 'document'} titled "${title}" and extract:
1. A 2-3 sentence summary of the main themes and narrative
2. Key themes (list 3-5)
3. Any character names or personas mentioned
4. Inferred personal values from the writing (list 2-4)

Text to analyze:
${text.slice(0, 6000)}${text.length > 6000 ? '...[truncated]' : ''}

Return as JSON with keys: summary, themes, characters, values`;

    try {
      const extraction = await base44.integrations.Core.InvokeLLM({
        prompt: extractionPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            summary: { type: 'string' },
            themes: { type: 'array', items: { type: 'string' } },
            characters: { type: 'array', items: { type: 'string' } },
            values: { type: 'array', items: { type: 'string' } },
          },
        },
      });

      await base44.entities.UserContext.update(user_context_id, {
        extracted_summary: extraction.summary,
        key_themes: extraction.themes || [],
        characters_mentioned: extraction.characters || [],
        personal_values: extraction.values || [],
        word_count: wordCount,
        processing_complete: true,
      });

      return Response.json({
        success: true,
        summary: extraction.summary,
        themes: extraction.themes,
        characters: extraction.characters,
        values: extraction.values,
        word_count: wordCount,
      });
    } catch (llmErr) {
      console.error('LLM extraction failed:', llmErr);
      await base44.entities.UserContext.update(user_context_id, {
        extracted_summary: 'Document uploaded. AI analysis pending.',
        processing_complete: true,
      });
      return Response.json({ error: llmErr.message }, { status: 500 });
    }
  } catch (error) {
    console.error('Context processing error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});