import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Derives tier label from numeric score
function scoreTier(score) {
  if (score <= -60) return "hostile";
  if (score <= -20) return "cold";
  if (score <= 20)  return "neutral";
  if (score <= 50)  return "warm";
  if (score <= 80)  return "close";
  return "devoted";
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { character_id, session_id, character_name, user_message, ai_response } = await req.json();
    if (!character_id || !session_id) {
      return Response.json({ error: 'character_id and session_id are required' }, { status: 400 });
    }

    // --- Analyze sentiment delta via LLM ---
    const analysis = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a relationship analyzer for a roleplay game. Analyze the player's message and determine how it would affect a character's affinity toward the player.

Character: ${character_name || 'Unknown'}
Player message: "${user_message}"
Character's reply (for context): "${(ai_response || '').slice(0, 300)}"

Return a JSON object with:
- delta: integer from -15 to +15 representing the relationship score change
  (negative = player was rude/hostile/dismissive, positive = player was kind/engaging/vulnerable/trustworthy, 0 = neutral/factual)
- reason: one short phrase explaining why (e.g. "player showed vulnerability", "player was dismissive")

Be nuanced. Small talk = ±1-3. Deep emotional exchange = ±5-8. Betrayal/cruelty = -10 to -15. Sincere trust = +10 to +15.`,
      response_json_schema: {
        type: "object",
        properties: {
          delta: { type: "number" },
          reason: { type: "string" }
        }
      }
    });

    const delta = Math.max(-15, Math.min(15, Math.round(analysis.delta || 0)));

    // --- Load or create relationship record ---
    const existing = await base44.entities.CharacterRelationship.filter({
      character_id,
      session_id
    });

    let rel;
    if (existing && existing.length > 0) {
      rel = existing[0];
      const newScore = Math.max(-100, Math.min(100, (rel.score || 0) + delta));
      rel = await base44.entities.CharacterRelationship.update(rel.id, {
        score: newScore,
        tier: scoreTier(newScore),
        total_interactions: (rel.total_interactions || 0) + 1,
        last_delta: delta
      });
    } else {
      const initScore = Math.max(-100, Math.min(100, delta));
      rel = await base44.entities.CharacterRelationship.create({
        character_id,
        session_id,
        score: initScore,
        tier: scoreTier(initScore),
        total_interactions: 1,
        last_delta: delta
      });
    }

    return Response.json({
      score: rel.score,
      tier: rel.tier,
      delta,
      reason: analysis.reason
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});