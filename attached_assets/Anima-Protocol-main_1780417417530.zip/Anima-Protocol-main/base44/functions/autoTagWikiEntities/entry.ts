import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { session_id, recent_messages = [], action = 'extract_and_update' } = await req.json();

    if (!session_id || recent_messages.length === 0) {
      return Response.json({ extracted: [] });
    }

    // Build conversation text for analysis
    const messageText = recent_messages
      .map(m => `${m.character_name || 'User'}: ${m.content}`)
      .join('\n\n');

    // Extract entities using LLM
    const extractionPrompt = `Analyze this conversation and identify mentions of characters (NPCs), locations, items, and important concepts. Focus on anything with a proper name or that seems narratively significant.

Conversation:
${messageText}

Return ONLY a valid JSON array. For each entity found:
- name: the entity name
- entry_type: one of: character, location, event, item, faction, concept, creature, lore
- summary: 1-2 sentence description based on context
- tags: 1-3 relevant tags
- importance: minor, notable, major, or central (based on prominence in conversation)

Example format:
[
  {
    "name": "The Forbidden Grove",
    "entry_type": "location",
    "summary": "A dark forest rumored to contain ancient magic",
    "tags": ["dangerous", "magical"],
    "importance": "notable"
  }
]

Extract only named entities. Be selective and focus on things with proper names.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: extractionPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          entities: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                entry_type: { type: 'string' },
                summary: { type: 'string' },
                tags: { type: 'array', items: { type: 'string' } },
                importance: { type: 'string' },
              },
              required: ['name', 'entry_type'],
            },
          },
        },
        required: ['entities'],
      },
    });

    const detectedEntities = result?.entities || [];
    const savedEntities = [];

    for (const entity of detectedEntities) {
      try {
        // Check if entity exists
        const existing = await base44.entities.WikiCodex.filter({
          name: entity.name,
          entry_type: entity.entry_type,
        });

        if (existing?.length > 0) {
          // Update existing entry
          const existingEntry = existing[0];
          const updatedSessionIds = [...new Set([...(existingEntry.session_ids || []), session_id])];
          
          await base44.entities.WikiCodex.update(existingEntry.id, {
            mention_count: (existingEntry.mention_count || 0) + 1,
            session_ids: updatedSessionIds,
            last_mentioned_session: session_id,
            // Enhance summary if new context provided
            summary: entity.summary || existingEntry.summary,
            // Merge tags
            tags: [...new Set([...(existingEntry.tags || []), ...(entity.tags || [])])],
          });
          savedEntities.push(existingEntry);
        } else {
          // Create new entry
          const newEntry = await base44.entities.WikiCodex.create({
            name: entity.name,
            entry_type: entity.entry_type,
            summary: entity.summary,
            tags: entity.tags || [],
            importance: entity.importance || 'minor',
            mention_count: 1,
            session_ids: [session_id],
            first_session_id: session_id,
            last_mentioned_session: session_id,
            lore_facts: entity.summary ? [entity.summary] : [],
            related_entries: [],
          });
          savedEntities.push(newEntry);
        }
      } catch (err) {
        console.error(`Error processing entity ${entity.name}:`, err);
      }
    }

    // Optionally link related entities if they were mentioned together
    if (savedEntities.length > 1) {
      for (let i = 0; i < savedEntities.length; i++) {
        const entity = savedEntities[i];
        const relatedNames = savedEntities
          .filter((_, idx) => idx !== i)
          .map(e => e.name);
        
        const currentRelated = entity.related_entries || [];
        const mergedRelated = [...new Set([...currentRelated, ...relatedNames])];
        
        await base44.entities.WikiCodex.update(entity.id, {
          related_entries: mergedRelated,
        }).catch(() => {});
      }
    }

    return Response.json({
      extracted: savedEntities,
      count: savedEntities.length,
      action,
    });
  } catch (error) {
    console.error('Auto-tag wiki error:', error);
    return Response.json({ error: error.message, extracted: [] }, { status: 500 });
  }
});