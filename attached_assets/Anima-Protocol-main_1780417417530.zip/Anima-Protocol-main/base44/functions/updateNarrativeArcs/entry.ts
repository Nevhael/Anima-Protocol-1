import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      session_id,
      recent_messages,
      character_emotions,
      relationships,
      existing_arcs,
    } = await req.json();

    if (!session_id || !recent_messages) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    // Build context for LLM analysis
    const conversationContext = recent_messages
      .slice(-10)
      .map(m => `${m.character_name || 'Narrator'}: ${m.content}`)
      .join('\n\n');

    const emotionSummary = Object.entries(character_emotions || {})
      .map(([charId, state]) => `${charId}: ${state.emotion} (intensity: ${state.intensity})`)
      .join('; ');

    const prompt = `Analyze this narrative segment and identify or update the following:

1. **Character Arcs**: Personal journeys, growth, transformation
2. **Plot Arcs**: Major story threads, mysteries, escalating conflicts
3. **Unresolved Conflicts**: Problems that remain open, tensions brewing
4. **Recurring Themes**: Patterns, symbols, philosophical questions that recur
5. **Mysteries**: Unexplained events or secrets that need resolution

Current Emotional State: ${emotionSummary}

Recent Narrative:
${conversationContext}

For each arc/theme/conflict found:
- Identify if it's new or continuing from previous sessions
- Describe its current status and development
- Rate emotional weight (1-10)
- Note key characters involved

Return as JSON with structure:
{
  "arcs": [
    {
      "type": "character_arc|plot_arc|conflict|theme|mystery",
      "title": "Arc Name",
      "description": "Current state",
      "status": "active|developing|resolved|dormant",
      "emotional_weight": 7,
      "characters": ["char1", "char2"],
      "is_continuing": true
    }
  ]
}`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          arcs: {
            type: "array",
            items: {
              type: "object",
              properties: {
                type: { type: "string" },
                title: { type: "string" },
                description: { type: "string" },
                status: { type: "string" },
                emotional_weight: { type: "number" },
                characters: { type: "array", items: { type: "string" } },
                is_continuing: { type: "boolean" },
              },
            },
          },
        },
      },
    });

    const analyzedArcs = result?.arcs || [];
    const updatedArcs = [];

    for (const arc of analyzedArcs) {
      // Try to find existing arc
      const existing = existing_arcs?.find(
        a => a.title.toLowerCase() === arc.title.toLowerCase()
      );

      if (existing) {
        // Update existing arc
        const keyEvents = existing.key_events || [];
        keyEvents.push({
          session_id,
          message_index: recent_messages.length - 1,
          description: arc.description,
        });

        const relatedSessions = new Set(existing.related_sessions || []);
        relatedSessions.add(session_id);

        const updated = await base44.entities.NarrativeArc.update(existing.id, {
          description: arc.description,
          status: arc.status,
          emotional_weight: arc.emotional_weight,
          key_events: keyEvents.slice(-20), // Keep last 20 events
          related_sessions: Array.from(relatedSessions),
          last_referenced: new Date().toISOString(),
          related_characters: [
            ...new Set([...(existing.related_characters || []), ...(arc.characters || [])]),
          ],
        });

        updatedArcs.push(updated);
      } else if (!arc.is_continuing) {
        // Create new arc
        const created = await base44.entities.NarrativeArc.create({
          arc_type: arc.type,
          title: arc.title,
          description: arc.description,
          status: arc.status,
          emotional_weight: arc.emotional_weight,
          first_appearance_session: session_id,
          related_sessions: [session_id],
          related_characters: arc.characters || [],
          key_events: [
            {
              session_id,
              message_index: recent_messages.length - 1,
              description: arc.description,
            },
          ],
          last_referenced: new Date().toISOString(),
        });

        updatedArcs.push(created);
      }
    }

    return Response.json({
      arcs_updated: updatedArcs.length,
      arcs: updatedArcs,
      total_arcs_analyzed: analyzedArcs.length,
    });
  } catch (error) {
    console.error('Error updating narrative arcs:', error);
    return Response.json(
      { error: error.message || 'Failed to update narrative arcs' },
      { status: 500 }
    );
  }
});