import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      session_id,
      message_count,
      character_emotions,
      recent_messages,
      current_calendar,
    } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    const worldEvents = [];

    // Determine event triggers based on story progression
    const emotionalIntensity = Object.values(character_emotions || {}).reduce(
      (sum, e) => sum + (e.intensity || 0),
      0
    ) / Math.max(Object.keys(character_emotions || {}).length, 1);

    const progressionLevel = Math.min(Math.floor(message_count / 10), 5);
    const daysPassed = current_calendar?.days_elapsed || 0;

    // Random event selection weighted by progression
    const eventRoll = Math.random();
    let selectedEvent = null;

    if (eventRoll < 0.3) {
      selectedEvent = generateWeatherEvent(current_calendar, daysPassed);
    } else if (eventRoll < 0.55) {
      selectedEvent = generateResourceEvent(emotionalIntensity, progressionLevel);
    } else if (eventRoll < 0.75) {
      selectedEvent = generatePoliticalEvent(progressionLevel, emotionalIntensity);
    } else {
      selectedEvent = generateEnvironmentalEvent(daysPassed, progressionLevel);
    }

    if (selectedEvent) {
      // Store in WorldState
      const worldState = await base44.entities.WorldState.create({
        session_id,
        category: selectedEvent.category,
        subject: selectedEvent.subject,
        fact: selectedEvent.description,
        importance: selectedEvent.importance,
        is_active: true,
        source_message_index: message_count,
      });

      worldEvents.push({
        id: worldState.id,
        ...selectedEvent,
        triggered_at_message: message_count,
      });
    }

    return Response.json({
      world_events: worldEvents,
      event_count: worldEvents.length,
      progression_level: progressionLevel,
    });
  } catch (error) {
    console.error('World evolution error:', error);
    return Response.json(
      { error: error.message || 'Failed to evolve world' },
      { status: 500 }
    );
  }
});

function generateWeatherEvent(calendar, daysPassed) {
  const weathers = [
    {
      subject: "Sudden Storm",
      description: "Dark clouds gather unexpectedly. The wind picks up with an eerie howl, and rain begins to fall in heavy sheets. Visibility drops sharply.",
      importance: "medium",
      category: "event",
    },
    {
      subject: "Unseasonable Cold",
      description: "Temperatures plummet far below what the season should allow. Frost forms on surfaces despite it being " + (calendar?.current_season || "the season") + ".",
      importance: "medium",
      category: "event",
    },
    {
      subject: "Clear Skies",
      description: "The clouds dissipate. A rare moment of clarity and good weather settles across the land, providing respite.",
      importance: "low",
      category: "event",
    },
    {
      subject: "Supernatural Fog",
      description: "A strange, luminescent fog creeps across the landscape. It smells of magic and ancient things. Visibility is reduced to mere feet.",
      importance: "high",
      category: "event",
    },
  ];

  return weathers[Math.floor(Math.random() * weathers.length)];
}

function generateResourceEvent(emotionalIntensity, progressionLevel) {
  const resources = [
    {
      subject: "Food Shortage",
      description: "Local food supplies are running low. Hunters report game is scarce, and crops have failed to yield. Rationing may soon be necessary.",
      importance: "high",
      category: "event",
    },
    {
      subject: "Fresh Water Crisis",
      description: "Wells run dry or become contaminated. The discovery is alarming—communities must find new sources or face dehydration.",
      importance: "high",
      category: "event",
    },
    {
      subject: "Resource Abundance",
      description: "An unexpected bounty is discovered. Markets overflow with fresh goods, and morale among traders lifts considerably.",
      importance: "medium",
      category: "event",
    },
    {
      subject: "Trade Route Disrupted",
      description: "Normally reliable supply routes are cut off. Whether by accident or intent, essential goods can no longer reach the community easily.",
      importance: "medium",
      category: "event",
    },
  ];

  // Higher emotional intensity = higher chance of scarcity
  if (emotionalIntensity > 7 && Math.random() < 0.7) {
    return resources[Math.floor(Math.random() * 2)]; // Lean toward shortages
  }

  return resources[Math.floor(Math.random() * resources.length)];
}

function generatePoliticalEvent(progressionLevel, emotionalIntensity) {
  const political = [
    {
      subject: "Power Shift",
      description: "A local leader steps down or is removed. A successor takes control, and the implications of this shift ripple through society.",
      importance: "high",
      category: "event",
    },
    {
      subject: "Diplomatic Tension",
      description: "Relations between factions grow strained. Words are exchanged. The threat of conflict looms on the horizon.",
      importance: "high",
      category: "event",
    },
    {
      subject: "Alliance Forged",
      description: "Two previously rival groups come together, united by common cause or necessity. This unlikely alliance surprises everyone.",
      importance: "medium",
      category: "event",
    },
    {
      subject: "Rebellion Brewing",
      description: "Whispers of discontent grow louder. A faction considers breaking away or defying established authority. Change may be coming.",
      importance: "high",
      category: "event",
    },
    {
      subject: "Peace Declaration",
      description: "A surprising announcement of peace or ceasefire is made. Whether genuine or fleeting remains to be seen.",
      importance: "medium",
      category: "event",
    },
  ];

  // Higher progression and tension = political instability
  if (progressionLevel >= 3 && emotionalIntensity > 6) {
    return political[Math.floor(Math.random() * 3)]; // Lean toward conflict
  }

  return political[Math.floor(Math.random() * political.length)];
}

function generateEnvironmentalEvent(daysPassed, progressionLevel) {
  const environmental = [
    {
      subject: "Earthquake",
      description: "The ground trembles violently. Buildings sway, and the landscape shifts. Everyone feels the primal power of nature.",
      importance: "high",
      category: "event",
    },
    {
      subject: "Aurora Phenomenon",
      description: "Strange lights dance across the sky in colors never before seen. Scholars debate their meaning while the common folk feel unease.",
      importance: "medium",
      category: "event",
    },
    {
      subject: "Creature Migration",
      description: "Massive herds or flocks of creatures move through the region—rare sightings that haven't occurred in living memory.",
      importance: "medium",
      category: "event",
    },
    {
      subject: "Volcanic Activity",
      description: "Smoke and ash rise from a distant volcano. The air grows thick and acrid. The earth seems unstable.",
      importance: "high",
      category: "event",
    },
    {
      subject: "Luminous Eclipse",
      description: "The sun or moon disappears behind shadow, but leaves an ethereal glow. The phenomenon lasts far longer than natural astronomy allows.",
      importance: "high",
      category: "event",
    },
  ];

  return environmental[Math.floor(Math.random() * environmental.length)];
}