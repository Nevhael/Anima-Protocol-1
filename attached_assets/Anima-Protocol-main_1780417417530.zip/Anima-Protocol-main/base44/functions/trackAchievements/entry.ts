import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const ACHIEVEMENTS = {
  first_chat: {
    title: "First Resonance",
    description: "Started your first conversation",
    icon: "🌟",
    xp: 10,
    secret: false,
    rarity: "common"
  },
  first_character: {
    title: "Creator",
    description: "Created your first character",
    icon: "👤",
    xp: 15,
    secret: false,
    rarity: "common"
  },
  milestone_10_sessions: {
    title: "Devoted",
    description: "Completed 10 sessions",
    icon: "🔟",
    xp: 50,
    secret: false,
    rarity: "uncommon"
  },
  milestone_50_sessions: {
    title: "Storyteller",
    description: "Completed 50 sessions",
    icon: "📖",
    xp: 100,
    secret: false,
    rarity: "rare"
  },
  deep_resonance: {
    title: "Deep Resonance",
    description: "A session exceeded 1000 messages",
    icon: "🌊",
    xp: 75,
    secret: false,
    rarity: "rare"
  },
  relationship_milestone: {
    title: "Kindred Spirit",
    description: "Character relationship reached 100+ affinity",
    icon: "💝",
    xp: 40,
    secret: false,
    rarity: "uncommon"
  }
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { achievement_type, session_id } = await req.json();
    
    if (!achievement_type || !ACHIEVEMENTS[achievement_type]) {
      return Response.json({ error: 'Invalid achievement type' }, { status: 400 });
    }

    // Check if already earned
    const existing = await base44.entities.Achievement.filter({
      user_email: user.email,
      achievement_type
    });

    if (existing && existing.length > 0) {
      return Response.json({ already_earned: true });
    }

    const achievement = ACHIEVEMENTS[achievement_type];
    
    // Create achievement record
    const created = await base44.entities.Achievement.create({
      user_email: user.email,
      achievement_type,
      title: achievement.title,
      description: achievement.description,
      icon_emoji: achievement.icon,
      xp_reward: achievement.xp,
      rarity: achievement.rarity,
      is_secret: achievement.secret,
      unlocked_at: new Date().toISOString()
    });

    // Update user XP
    const progress = await base44.entities.UserProgress.filter({ user_email: user.email });
    const currentProgress = progress?.[0];
    
    if (currentProgress) {
      const newXp = (currentProgress.xp_total || 0) + achievement.xp;
      const newLevel = Math.floor(newXp / 100) + 1;
      
      await base44.entities.UserProgress.update(currentProgress.id, {
        xp_total: newXp,
        level: newLevel,
        achievements_earned: (currentProgress.achievements_earned || 0) + 1
      });
    } else {
      // Create initial progress record
      await base44.entities.UserProgress.create({
        user_email: user.email,
        xp_total: achievement.xp,
        level: 1,
        achievements_earned: 1
      });
    }

    return Response.json({ created, xp_awarded: achievement.xp });
  } catch (error) {
    console.error('Track achievements error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});