import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const apiKey = Deno.env.get('ELEVENLABS_API_KEY');
    if (!apiKey) {
      return Response.json({ error: 'ElevenLabs API key not configured' }, { status: 500 });
    }

    // Fetch available voices from ElevenLabs
    const voicesRes = await fetch('https://api.elevenlabs.io/v1/voices', {
      headers: { 'xi-api-key': apiKey }
    });
    const voicesData = await voicesRes.json();
    const voices = voicesData.voices || [];

    if (voices.length === 0) {
      return Response.json({ error: 'No voices available from ElevenLabs' }, { status: 500 });
    }

    // Fetch all characters
    const characters = await base44.entities.Character.list('-created_date', 200);
    
    // Simple voice assignment: cycle through voices for characters
    let assigned = 0;
    for (let i = 0; i < characters.length; i++) {
      const char = characters[i];
      
      // Skip if already has a voice
      if (char.elevenlabs_voice_id) continue;

      // Assign voice (cycle through available voices)
      const voiceIndex = i % voices.length;
      const selectedVoice = voices[voiceIndex];

      await base44.entities.Character.update(char.id, {
        elevenlabs_voice_id: selectedVoice.voice_id
      });
      assigned++;
    }

    return Response.json({
      success: true,
      assigned,
      totalCharacters: characters.length,
      voicesAvailable: voices.length
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});