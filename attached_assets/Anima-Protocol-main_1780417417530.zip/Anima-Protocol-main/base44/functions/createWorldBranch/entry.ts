import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      session_id,
      branch_name,
      decision_point,
      outcome_summary,
      parent_snapshot_id,
    } = await req.json();

    if (!session_id || !branch_name || !decision_point) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    // Fetch current world state to freeze
    const [calendar, factions, locations, relationships] = await Promise.all([
      base44.entities.Calendar.filter({ session_id }, "-created_date", 1),
      base44.entities.Faction.list("-created_date", 100),
      base44.entities.Location.list("-created_date", 100),
      base44.entities.CharacterRelationship.filter({ session_id }, "-created_date", 100),
    ]);

    // Determine depth for tree visualization
    let depth = 0;
    if (parent_snapshot_id) {
      const parent = await base44.entities.WorldSnapshot.list("-created_date", 1);
      const parentSnap = parent?.find(s => s.id === parent_snapshot_id);
      depth = (parentSnap?.depth || 0) + 1;
    }

    // Create snapshot
    const snapshot = await base44.entities.WorldSnapshot.create({
      session_id,
      branch_name,
      decision_point,
      parent_snapshot_id: parent_snapshot_id || null,
      outcome_summary: outcome_summary || "",
      world_state: {
        calendar: calendar?.[0] || {},
        faction_states: factions || [],
        location_states: locations || [],
      },
      relationship_snapshots: (relationships || []).map(r => ({
        character_id: r.character_id,
        score: r.score,
        tier: r.tier,
      })),
      is_active: true,
      depth,
      key_events: [],
      political_outcome: "",
      environmental_outcome: "",
    });

    // Mark this as the active branch
    const allSnapshots = await base44.entities.WorldSnapshot.filter({ session_id });
    for (const snap of allSnapshots || []) {
      if (snap.id !== snapshot.id) {
        await base44.entities.WorldSnapshot.update(snap.id, { is_active: false }).catch(() => {});
      }
    }

    return Response.json({
      success: true,
      snapshot,
      message: `Branch "${branch_name}" created successfully`,
    });
  } catch (error) {
    console.error('World branch creation error:', error);
    return Response.json(
      { error: error.message || 'Failed to create branch' },
      { status: 500 }
    );
  }
});