import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

const stripe = await import("npm:stripe@16.7.0");
const Stripe = stripe.default;

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") {
      return Response.json({ error: "Method not allowed" }, { status: 405 });
    }

    const signature = req.headers.get("stripe-signature");
    const body = await req.text();
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

    if (!signature || !webhookSecret) {
      console.error("Missing webhook signature or secret");
      return Response.json({ error: "Webhook validation failed" }, { status: 400 });
    }

    const stripeClient = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"));

    // Construct event using async method (required for Deno)
    let event;
    try {
      event = await stripeClient.webhooks.constructEventAsync(
        body,
        signature,
        webhookSecret
      );
    } catch (err) {
      console.error("Webhook signature verification failed:", err.message);
      return Response.json({ error: "Webhook validation failed" }, { status: 400 });
    }

    // Now auth after Stripe validation
    const base44 = createClientFromRequest(req);

    console.log(`Processing webhook event: ${event.type}`);

    // Handle subscription events
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        const userEmail = session.customer_email || session.metadata?.user_email;

        if (!userEmail) {
          console.error("No user email in checkout session");
          return Response.json({ status: "ok" });
        }

        console.log(`Subscription created for ${userEmail}`);

        // Sync subscription status with user tier
        if (session.subscription) {
          await base44.asServiceRole.functions.invoke('syncSubscriptionStatus', {
            subscription_id: session.subscription,
            customer_email: userEmail,
          });
        }
        break;
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object;
        const userEmail = subscription.metadata?.user_email;

        if (!userEmail) {
          console.error("No user email in subscription update");
          return Response.json({ status: "ok" });
        }

        console.log(`Subscription updated for ${userEmail}: status=${subscription.status}`);

        // Sync subscription status with user tier
        await base44.asServiceRole.functions.invoke('syncSubscriptionStatus', {
          subscription_id: subscription.id,
          customer_email: userEmail,
        });
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object;
        const userEmail = subscription.metadata?.user_email;

        if (!userEmail) {
          console.error("No user email in subscription deletion");
          return Response.json({ status: "ok" });
        }

        console.log(`Subscription cancelled for ${userEmail}`);

        // Downgrade user to free tier
        const users = await base44.asServiceRole.entities.User.filter({
          email: userEmail,
        });

        if (users && users.length > 0) {
          await base44.asServiceRole.entities.User.update(users[0].id, {
            role: 'user',
            settings: {
              ...users[0].settings,
              subscription_status: 'cancelled',
              subscription_updated: new Date().toISOString(),
            },
          });
          console.log(`[Webhook] Downgraded ${userEmail} to free tier`);
        }
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return Response.json({ status: "ok" });
  } catch (error) {
    console.error("Webhook handler error:", error.message);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});