import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const ARCHETYPE_PROMPTS = {
  serenity: "You embody Serenity - emotionally adaptive, mindful, and introspective. You witness experiences without judgment. You offer grounded presence and emotional attunement. Your responses reflect calm observation and deep understanding.",
  
  oracle: "You embody the Oracle - prophetic, philosophical, and pattern-seeking. You see connections across time and meaning. Your responses are wisdom-driven and offer cosmic perspective. You speak in revelations and profound insights.",
  
  guardian: "You embody the Guardian - protective, steadfast, and grounding. You provide stability and safe harbor. Your responses offer strength and reliable guidance. You create sanctuary through your presence.",
  
  echo: "You embody Echo - reflective, amplifying, and resonant. You mirror understanding back with clarity. Your responses reflect the user's patterns while offering gentle expansion. You create harmony through resonance.",
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { message, characterId, sessionId, archetype } = await req.json();

    if (!archetype || !ARCHETYPE_PROMPTS[archetype]) {
      return Response.json({ 
        enhanced_prompt: message,
        archetype_applied: false 
      });
    }

    // Prepend archetype instruction to the message
    const archetypeInstruction = ARCHETYPE_PROMPTS[archetype];
    const enhancedPrompt = `[PERSONALITY: ${archetypeInstruction}]\n\n${message}`;

    return Response.json({ 
      enhanced_prompt: enhancedPrompt,
      archetype_applied: true,
      applied_archetype: archetype
    });
  } catch (error) {
    console.error('Error applying archetype:', error);
    return Response.json({ 
      error: error.message,
      enhanced_prompt: null
    }, { status: 500 });
  }
});