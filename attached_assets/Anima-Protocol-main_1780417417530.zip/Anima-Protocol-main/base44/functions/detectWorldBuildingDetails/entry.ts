import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, messages, start_index } = await req.json();

    if (!session_id || !messages || !Array.isArray(messages)) {
      return Response.json({ error: 'session_id and messages array required' }, { status: 400 });
    }

    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Process each message to detect discoveries
    const discoveries = [];
    const messageSlice = start_index ? messages.slice(start_index) : messages;

    for (let i = 0; i < messageSlice.length; i++) {
      const msg = messageSlice[i];
      if (!msg.content || msg.role === 'user') continue;

      const actualIndex = start_index ? start_index + i : i;
      const detectionPrompt = `Analyze this story excerpt and identify NEW world-building details (places, historical events, factions, artifacts, character details, or history).

Story excerpt:
"${msg.content}"

Return ONLY a JSON array of discoveries. Each discovery should have:
- type: one of "location", "event", "faction", "artifact", "character_detail", "history"
- subject: the name/title (max 50 chars)
- description: what makes it significant (2-3 sentences max)
- confidence: 0.1-1.0 (how confident this is a genuine NEW detail, not repetition)

Only return ACTUAL world-building details explicitly mentioned in the text, not implied or assumed. If no clear new details, return empty array [].

Example output:
[
  {
    "type": "location",
    "subject": "The Crystalline Spire",
    "description": "An ancient tower of crystal that glows with inner light, said to be the source of all magic in the realm.",
    "confidence": 0.9
  }
]`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: detectionPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            discoveries: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  type: { type: 'string' },
                  subject: { type: 'string' },
                  description: { type: 'string' },
                  confidence: { type: 'number' }
                }
              }
            }
          }
        }
      });

      const detectedItems = result?.discoveries || [];

      for (const item of detectedItems) {
        // Only create discovery if confidence is high enough and not duplicate
        if (item.confidence >= 0.6) {
          // Check if already discovered
          const existing = await base44.entities.PendingDiscovery.filter({
            session_id,
            subject: item.subject,
            status: { $ne: 'rejected' }
          });

          if (!existing || existing.length === 0) {
            discoveries.push({
              session_id,
              message_index: actualIndex,
              discovery_type: item.type,
              subject: item.subject,
              description: item.description,
              context: msg.content.slice(0, 200) + (msg.content.length > 200 ? '...' : ''),
              confidence: item.confidence,
              status: 'pending'
            });
          }
        }
      }
    }

    // Batch insert discoveries
    if (discoveries.length > 0) {
      await base44.entities.PendingDiscovery.bulkCreate(discoveries);
    }

    return Response.json({
      discovered: discoveries.length,
      details: discoveries
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});