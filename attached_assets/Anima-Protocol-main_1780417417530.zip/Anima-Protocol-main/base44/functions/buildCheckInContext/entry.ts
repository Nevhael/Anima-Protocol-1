import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id, session_id, days_lookback = 7 } = await req.json();

    // Fetch recent check-ins
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days_lookback);
    const cutoffDateString = cutoffDate.toISOString().split('T')[0];

    const recentCheckIns = await base44.entities.CheckIn.filter({
      session_id,
    }).then(checkins =>
      checkins
        .filter(c => c.check_in_date >= cutoffDateString)
        .sort((a, b) => new Date(b.check_in_date) - new Date(a.check_in_date))
        .slice(0, 5)
    );

    if (!recentCheckIns || recentCheckIns.length === 0) {
      return Response.json({
        context: '',
        check_in_count: 0,
      });
    }

    // Build narrative context
    const checkInSummaries = recentCheckIns.map(ci => {
      const parts = [];
      parts.push(`[${ci.check_in_date}] Mood: ${ci.mood}`);
      if (ci.current_focus) parts.push(`Focus: ${ci.current_focus}`);
      if (ci.revelation) parts.push(`Insight: ${ci.revelation}`);
      if (ci.freeform_note) parts.push(`Notes: ${ci.freeform_note}`);
      return parts.join(' | ');
    });

    const context = `
RECENT USER CHECK-INS (LAST ${days_lookback} DAYS):
${checkInSummaries.join('\n')}

NARRATIVE INSTRUCTIONS:
- Reference the user's recent emotional patterns and focus areas naturally
- Weave their reported insights into the ongoing story
- Let their mood influence the tone of your responses
- Acknowledge their journey through these check-ins without being explicit
- Adapt the narrative pacing based on their current focus and emotional state
`;

    return Response.json({
      context: context.trim(),
      check_in_count: recentCheckIns.length,
      recent_mood: recentCheckIns[0]?.mood,
      recent_focus: recentCheckIns[0]?.current_focus,
    });
  } catch (error) {
    console.error('Check-in context building error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});