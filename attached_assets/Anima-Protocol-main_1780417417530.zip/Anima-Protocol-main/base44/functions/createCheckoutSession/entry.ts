import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

const stripe = await import("npm:stripe@16.7.0");
const Stripe = stripe.default;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { price_id, success_url, cancel_url } = await req.json();

    if (!price_id || !success_url || !cancel_url) {
      return Response.json(
        { error: "Missing required parameters" },
        { status: 400 }
      );
    }

    // Check if running in iframe (Base44 preview)
    const referrer = req.headers.get("referer") || "";
    if (referrer.includes("preview") || referrer.includes("iframe")) {
      return Response.json(
        { error: "Checkout must be done from published app. Visit your app's live URL to subscribe." },
        { status: 400 }
      );
    }

    const stripeClient = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"));

    const session = await stripeClient.checkout.sessions.create({
      payment_method_types: ["card"],
      customer_email: user.email,
      line_items: [
        {
          price: price_id,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url,
      cancel_url,
      metadata: {
        base44_app_id: Deno.env.get("BASE44_APP_ID"),
        user_email: user.email,
      },
    });

    console.log(`Checkout session created: ${session.id} for ${user.email}`);

    return Response.json({ checkout_url: session.url });
  } catch (error) {
    console.error("Checkout error:", error.message);
    return Response.json(
      { error: error.message || "Checkout failed" },
      { status: 500 }
    );
  }
});