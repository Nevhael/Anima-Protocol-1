import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const sessionId = body.session_id;

    if (!sessionId) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    // Get the session
    const sessions = await base44.entities.ChatSession.filter({ id: sessionId });
    const session = sessions?.[0];

    if (!session) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    // Check if summary already exists for today
    const existingSummaries = await base44.entities.SessionSummary.filter({
      session_id: sessionId
    }, '-generated_at', 1);

    const today = new Date().toDateString();
    if (existingSummaries?.length > 0) {
      const lastGenerated = new Date(existingSummaries[0].generated_at).toDateString();
      if (lastGenerated === today) {
        // Return existing summary if generated today
        return Response.json({
          success: true,
          summary: existingSummaries[0],
          cached: true
        });
      }
    }

    // Extract key moments and emotional arc from messages
    const messages = session.messages || [];
    const characterInvolved = [];
    if (session.mode === 'solo' && session.character_id) {
      characterInvolved.push(session.character_id);
    } else if (session.mode === 'group' && session.group_character_ids) {
      characterInvolved.push(...session.group_character_ids);
    }

    // Skip summary generation if session is empty
    let generatedText = '';
    if (messages.length > 0) {
      try {
        const summaryResult = await base44.functions.invoke('generateStorySummary', {
          session_id: sessionId,
          recent_messages: messages.slice(-20)
        });
        generatedText = summaryResult?.data || 'Session in progress.';
      } catch (err) {
        console.warn('Story summary generation failed:', err.message);
        generatedText = 'Session narrative being developed.';
      }
    } else {
      generatedText = 'New session started. The story awaits.';
    }

    // Create new summary record
    const newSummary = await base44.entities.SessionSummary.create({
      session_id: sessionId,
      title: session.title || 'Untitled Session',
      synopsis: generatedText,
      key_moments: messages
        .filter(m => m.role === 'assistant')
        .slice(-3)
        .map(m => m.content.slice(0, 100) + '...')
        .filter(Boolean),
      characters_involved: characterInvolved,
      emotional_arc: messages.length > 0 ? 'Complex narrative arc' : 'New session',
      generated_at: new Date().toISOString()
    });

    return Response.json({
      success: true,
      summary: newSummary,
      cached: false
    });
  } catch (error) {
    console.error('Session summary generation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});