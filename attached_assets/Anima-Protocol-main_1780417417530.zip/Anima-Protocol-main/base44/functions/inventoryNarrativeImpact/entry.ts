import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id, session_id, recent_messages } = await req.json();

    if (!character_id || !session_id) {
      return Response.json({ error: 'character_id and session_id required' }, { status: 400 });
    }

    // Fetch inventory
    const inventoryItems = await base44.entities.Inventory.filter({
      character_id,
      session_id,
    });

    // Get character info for context
    const character = await base44.entities.Character.list().then(chars => chars.find(c => c.id === character_id));

    // Identify rare/special items
    const specialItems = (inventoryItems || []).filter(item => 
      item.rarity === 'rare' || item.rarity === 'legendary' || item.narrative_triggers?.length > 0
    );

    // Build inventory context for narrative
    const inventoryContext = specialItems.map(item => ({
      name: item.name,
      type: item.type,
      rarity: item.rarity,
      description: item.description,
      triggers: item.narrative_triggers || [],
    }));

    // Generate narrative hooks that would incorporate inventory
    let narrativeChoices = [];
    if (inventoryContext.length > 0) {
      const prompt = `Given the character ${character?.name} has these special items: ${JSON.stringify(inventoryContext)}, 
      and the recent story context from these messages: ${JSON.stringify(recent_messages?.slice(-3) || [])},
      generate 2-3 compelling narrative choices that involve or are influenced by these items. 
      Return as JSON array with objects: {title, description, item_requirement, stat_bonus}`;

      try {
        const response = await base44.integrations.Core.InvokeLLM({
          prompt,
          response_json_schema: {
            type: 'object',
            properties: {
              choices: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    title: { type: 'string' },
                    description: { type: 'string' },
                    item_requirement: { type: 'string' },
                    stat_bonus: { type: 'string' },
                  },
                },
              },
            },
          },
        });
        narrativeChoices = response?.choices || [];
      } catch (e) {
        console.warn('Narrative generation failed:', e);
      }
    }

    return Response.json({
      success: true,
      inventory_items: inventoryItems || [],
      special_items: specialItems,
      narrative_choices: narrativeChoices,
      narrative_context: inventoryContext,
    });
  } catch (error) {
    console.error('Narrative impact error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});