import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_id,
      other_character_id,
      session_id,
      include_all_memories = false,
    } = await req.json();

    if (!character_id) {
      return Response.json({ error: 'character_id required' }, { status: 400 });
    }

    // Retrieve memories relevant to this character
    const memoryFilter = { character_id };
    if (other_character_id) {
      memoryFilter.related_character_id = other_character_id;
    }
    if (session_id && !include_all_memories) {
      memoryFilter.session_ids = { $nin: [session_id] };
    }

    const memories = await base44.entities.CrossSessionMemory.filter(memoryFilter, '-relevance_score', 20);

    if (!memories || memories.length === 0) {
      return Response.json({
        context: '',
        memory_count: 0,
        relationships_mentioned: [],
      });
    }

    // Organize memories by type
    const byType = {};
    const relationships = new Set();

    memories.forEach(mem => {
      if (!byType[mem.memory_type]) {
        byType[mem.memory_type] = [];
      }
      byType[mem.memory_type].push(mem);
      if (mem.related_character_id) {
        relationships.add(mem.related_character_id);
      }
    });

    // Build narrative context
    let context = 'LONG-TERM MEMORIES (from previous sessions):\n\n';

    // Relationship memories first (most contextually important)
    if (byType.relationship_milestone) {
      context += '=== RELATIONSHIP MILESTONES ===\n';
      byType.relationship_milestone.slice(0, 3).forEach(mem => {
        context += `[${mem.subject}] ${mem.description} (significance: ${mem.emotional_weight}/10, reinforced ${mem.reinforcement_count} times)\n`;
      });
      context += '\n';
    }

    // Shared events
    if (byType.shared_event) {
      context += '=== SHARED EXPERIENCES ===\n';
      byType.shared_event.slice(0, 3).forEach(mem => {
        context += `[${mem.subject}] ${mem.description}\n`;
      });
      context += '\n';
    }

    // Character development
    if (byType.character_development) {
      context += '=== CHARACTER GROWTH ===\n';
      byType.character_development.slice(0, 2).forEach(mem => {
        context += `[${mem.subject}] ${mem.description}\n`;
      });
      context += '\n';
    }

    // Interaction patterns
    if (byType.interaction_pattern) {
      context += '=== INTERACTION PATTERNS ===\n';
      byType.interaction_pattern.slice(0, 2).forEach(mem => {
        context += `[${mem.subject}] ${mem.description}\n`;
      });
      context += '\n';
    }

    // Personal growth
    if (byType.personal_growth) {
      context += '=== PERSONAL EVOLUTION ===\n';
      byType.personal_growth.slice(0, 2).forEach(mem => {
        context += `[${mem.subject}] ${mem.description}\n`;
      });
      context += '\n';
    }

    return Response.json({
      context: context.trim(),
      memory_count: memories.length,
      memories_by_type: Object.keys(byType),
      relationships_mentioned: Array.from(relationships),
      total_relationships_history: memories.filter(m => m.related_character_id).length,
    });
  } catch (error) {
    console.error('Memory context build error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});