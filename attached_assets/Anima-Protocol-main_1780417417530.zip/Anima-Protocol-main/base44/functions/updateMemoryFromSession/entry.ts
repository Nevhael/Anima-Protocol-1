import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      character_id,
      session_id,
      relationship_changes,
      new_interactions,
      emotional_discoveries,
    } = await req.json();

    if (!character_id || !session_id) {
      return Response.json({ error: 'character_id and session_id required' }, { status: 400 });
    }

    const updates = [];

    // Update relationship impact memories
    if (relationship_changes && Object.keys(relationship_changes).length > 0) {
      for (const [relCharId, scoreDelta] of Object.entries(relationship_changes)) {
        // Find relevant relationship memories
        const relMemories = await base44.entities.CrossSessionMemory.filter({
          character_id,
          related_character_id: relCharId,
          memory_type: { $in: ['relationship_milestone', 'interaction_pattern'] },
        }, '-last_reinforced', 5);

        if (relMemories?.length > 0) {
          for (const mem of relMemories) {
            // Update relationship impact based on new score delta
            const updatedImpact = Math.min(10, Math.max(-10, (mem.relationship_impact || 0) + scoreDelta * 0.1));
            await base44.entities.CrossSessionMemory.update(mem.id, {
              relationship_impact: updatedImpact,
              last_reinforced: new Date().toISOString(),
              relevance_score: calculateRelevance(mem.emotional_weight, (mem.reinforcement_count || 1) + 1),
            });
            updates.push({ memory_id: mem.id, type: 'relationship_update' });
          }
        }
      }
    }

    // Form memories from new interactions (if provided)
    if (new_interactions?.length > 0) {
      const extractPrompt = `Extract 1-2 key interaction patterns from these exchanges that should shape future understanding:
${new_interactions.join('\n---\n')}

Return JSON: { patterns: [{ pattern_name: string, description: string, tags: string[] }] }`;

      try {
        const patternsResult = await base44.integrations.Core.InvokeLLM({
          prompt: extractPrompt,
          response_json_schema: {
            type: 'object',
            properties: {
              patterns: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    pattern_name: { type: 'string' },
                    description: { type: 'string' },
                    tags: { type: 'array', items: { type: 'string' } }
                  }
                }
              }
            }
          }
        });

        if (patternsResult?.patterns) {
          for (const pattern of patternsResult.patterns) {
            const newMemory = await base44.entities.CrossSessionMemory.create({
              character_id,
              memory_type: 'interaction_pattern',
              subject: pattern.pattern_name,
              description: pattern.description,
              session_ids: [session_id],
              tags: pattern.tags,
              emotional_weight: 5,
              reinforcement_count: 1,
              last_reinforced: new Date().toISOString(),
              relevance_score: 0.6,
            });
            updates.push({ memory_id: newMemory.id, type: 'interaction_pattern' });
          }
        }
      } catch (e) {
        console.error('Pattern extraction failed:', e);
      }
    }

    // Update emotional discoveries (character development)
    if (emotional_discoveries?.length > 0) {
      for (const discovery of emotional_discoveries) {
        const growthMemory = await base44.entities.CrossSessionMemory.create({
          character_id,
          memory_type: 'character_development',
          subject: `Emotional Discovery: ${discovery.discovery || 'Personal Growth'}`,
          description: discovery.description || 'Learned something new about themselves',
          emotional_weight: discovery.intensity || 7,
          session_ids: [session_id],
          tags: discovery.tags || ['self-awareness', 'growth'],
          reinforcement_count: 1,
          last_reinforced: new Date().toISOString(),
          relevance_score: (discovery.intensity || 7) / 10,
        });
        updates.push({ memory_id: growthMemory.id, type: 'character_development' });
      }
    }

    return Response.json({
      updated: updates.length,
      updates,
    });
  } catch (error) {
    console.error('Session memory update error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function calculateRelevance(emotionalWeight, reinforcementCount) {
  return Math.min((emotionalWeight / 10) * (1 + Math.log(reinforcementCount + 1)), 1);
}