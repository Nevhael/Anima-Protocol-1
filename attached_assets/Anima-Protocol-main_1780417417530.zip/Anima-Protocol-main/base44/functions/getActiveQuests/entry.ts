import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const sessionId = body.session_id;
    const characterId = body.character_id;

    if (!sessionId) {
      return Response.json({ error: 'Missing session_id' }, { status: 400 });
    }

    // Fetch active quests for the session
    const quests = await base44.entities.Quest.filter({
      session_id: sessionId,
      status: { $in: ['active', 'available'] },
    }, '-created_date', 50);

    // Build AI-readable quest summary
    const questSummary = quests.map(q => {
      const progress = q.objectives
        ? `${q.objectives.filter(obj => obj.completed).length}/${q.objectives.length} complete`
        : 'tracking';
      return `• ${q.title} (${progress})`;
    }).join('\n');

    const context = quests.length > 0
      ? `Active quests:\n${questSummary}\n\nCharacters should acknowledge these goals and help the player progress toward them.`
      : 'No active quests. The player is exploring freely.';

    return Response.json({
      success: true,
      questCount: quests.length,
      quests,
      aiContext: context,
    });
  } catch (error) {
    console.error('Get quests error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});