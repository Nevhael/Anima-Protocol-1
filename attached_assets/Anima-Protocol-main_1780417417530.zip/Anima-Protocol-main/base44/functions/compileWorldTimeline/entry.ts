import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Compiles a unified world timeline from WorldState lore, Quests, NarrativeArcs,
 * and VectorMemory entries, then uses the LLM to produce cumulative world-impact
 * annotations and an overall "world shift" score for each epoch.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { session_id } = body; // optional — if omitted, pull everything

    // ── Fetch raw data in parallel ────────────────────────────────────────────
    const [loreEntries, quests, arcs, memories] = await Promise.all([
      session_id
        ? base44.entities.WorldState.filter({ session_id, is_active: true }, '-created_date', 200)
        : base44.entities.WorldState.list('-created_date', 300),
      session_id
        ? base44.entities.Quest.filter({ session_id }, '-created_date', 100)
        : base44.entities.Quest.list('-created_date', 150),
      base44.entities.NarrativeArc.list('-created_date', 100),
      session_id
        ? base44.entities.VectorMemory.filter({ session_id }, '-created_date', 100)
        : base44.entities.VectorMemory.list('-created_date', 150),
    ]);

    // ── Normalize all events into a flat timeline ─────────────────────────────
    const allEvents = [];

    for (const e of (loreEntries || [])) {
      allEvents.push({
        id: e.id,
        type: 'lore',
        category: e.category || 'event',
        date: e.created_date,
        title: e.subject || 'World Event',
        description: e.fact || '',
        importance: e.importance || 'medium',
        session_id: e.session_id,
        source_message_index: e.source_message_index || null,
        impact_weight: { low: 1, medium: 2, high: 3, critical: 5 }[e.importance] || 2,
      });
    }

    for (const q of (quests || [])) {
      const weight = q.status === 'completed' ? 4 : q.status === 'failed' ? 2 : 1;
      allEvents.push({
        id: q.id,
        type: 'quest',
        category: 'quest',
        date: q.completed_at || q.started_at || q.created_date,
        title: q.title,
        description: q.narrative_context || q.description || '',
        importance: q.difficulty === 'legendary' || q.difficulty === 'hard' ? 'high' : 'medium',
        status: q.status,
        session_id: q.session_id,
        xp: q.rewards?.xp || 0,
        impact_weight: weight,
      });
    }

    for (const arc of (arcs || [])) {
      allEvents.push({
        id: arc.id,
        type: 'arc',
        category: 'narrative_arc',
        date: arc.last_referenced || arc.created_date,
        title: arc.title,
        description: arc.description || '',
        importance: arc.emotional_weight >= 8 ? 'critical' : arc.emotional_weight >= 5 ? 'high' : 'medium',
        status: arc.status,
        arc_type: arc.arc_type,
        emotional_weight: arc.emotional_weight,
        impact_weight: Math.ceil((arc.emotional_weight || 5) / 2),
      });
    }

    for (const m of (memories || [])) {
      if (!['emotional_moment', 'conflict', 'resolution', 'growth'].includes(m.memory_type)) continue;
      allEvents.push({
        id: m.id,
        type: 'memory',
        category: m.memory_type,
        date: m.created_date,
        title: m.title || 'Character Moment',
        description: m.content ? m.content.slice(0, 200) : '',
        importance: m.narrative_significance >= 0.8 ? 'high' : 'medium',
        session_id: m.session_id,
        impact_weight: Math.ceil((m.narrative_significance || 0.5) * 4),
      });
    }

    // ── Sort chronologically ──────────────────────────────────────────────────
    allEvents.sort((a, b) => new Date(a.date) - new Date(b.date));

    // ── Compute cumulative world-impact score ─────────────────────────────────
    let cumulative = 0;
    const eventsScoredRaw = allEvents.map(ev => {
      cumulative += ev.impact_weight;
      return { ...ev, cumulative_impact: cumulative };
    });

    // ── Group into epochs (chunks of ~10 events) for LLM annotation ──────────
    const EPOCH_SIZE = 10;
    const epochs = [];
    for (let i = 0; i < eventsScoredRaw.length; i += EPOCH_SIZE) {
      epochs.push(eventsScoredRaw.slice(i, i + EPOCH_SIZE));
    }

    // Only annotate up to 6 epochs to stay within cost limits
    const epochsToAnnotate = epochs.slice(0, 6);
    const annotatedEpochs = [];

    for (const epoch of epochsToAnnotate) {
      const summaryLines = epoch.map(ev =>
        `[${ev.type.toUpperCase()}] ${ev.title}: ${ev.description.slice(0, 100)}`
      ).join('\n');

      const annotation = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a narrative historian analyzing how a fictional world has shifted. Given these events from a roleplay session, produce a short (2-3 sentence) "world state annotation" that describes how the narrative environment, power dynamics, or atmosphere has cumulatively changed. Then give a one-word "world mood" (e.g. Turbulent, Hopeful, Darkening, Peaceful, Volatile, Ascending).

Events:
${summaryLines}

Respond in JSON: { "annotation": "...", "mood": "..." }`,
        response_json_schema: {
          type: 'object',
          properties: {
            annotation: { type: 'string' },
            mood: { type: 'string' },
          }
        }
      });

      annotatedEpochs.push({
        events: epoch,
        annotation: annotation?.annotation || '',
        mood: annotation?.mood || 'Shifting',
        start_date: epoch[0]?.date,
        end_date: epoch[epoch.length - 1]?.date,
        total_impact: epoch.reduce((s, e) => s + e.impact_weight, 0),
        cumulative_at_end: epoch[epoch.length - 1]?.cumulative_impact || 0,
      });
    }

    // Append any unannotated epochs (without LLM cost)
    for (let i = epochsToAnnotate.length; i < epochs.length; i++) {
      const epoch = epochs[i];
      annotatedEpochs.push({
        events: epoch,
        annotation: '',
        mood: 'Shifting',
        start_date: epoch[0]?.date,
        end_date: epoch[epoch.length - 1]?.date,
        total_impact: epoch.reduce((s, e) => s + e.impact_weight, 0),
        cumulative_at_end: epoch[epoch.length - 1]?.cumulative_impact || 0,
      });
    }

    const totalImpact = cumulative;
    const dominantType = (() => {
      const counts = {};
      for (const e of eventsScoredRaw) counts[e.type] = (counts[e.type] || 0) + 1;
      return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'lore';
    })();

    return Response.json({
      epochs: annotatedEpochs,
      total_events: eventsScoredRaw.length,
      total_impact: totalImpact,
      dominant_type: dominantType,
      all_events: eventsScoredRaw,
    });

  } catch (error) {
    console.error('compileWorldTimeline error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});