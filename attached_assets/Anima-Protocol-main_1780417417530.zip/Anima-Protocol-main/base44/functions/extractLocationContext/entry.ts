import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { session_id, messages = [] } = body;

    if (!messages.length) {
      return Response.json({ locations: [], character_locations: {} });
    }

    // Extract location mentions using LLM
    const messageContent = messages.slice(-20).map(m => `${m.character_name}: ${m.content}`).join('\n');

    const extractionPrompt = `Analyze these roleplay messages and extract all geographic locations mentioned or implied. For each location, identify:
1. Location name
2. Description/atmosphere
3. Characters present
4. Previous interactions hinted at
5. Strategic/emotional significance

Return ONLY valid JSON:
{
  "locations": [
    {
      "name": "location name",
      "description": "brief atmosphere/details",
      "coordinates": null,
      "type": "city/building/wilderness/dungeon/etc",
      "characters_present": ["char1", "char2"],
      "significance": "strategic/emotional context"
    }
  ]
}

Messages:
${messageContent}`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: extractionPrompt,
      response_json_schema: {
        type: 'object',
        properties: {
          locations: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                description: { type: 'string' },
                coordinates: { type: 'object', nullable: true },
                type: { type: 'string' },
                characters_present: { type: 'array', items: { type: 'string' } },
                significance: { type: 'string' }
              }
            }
          }
        }
      }
    });

    const extractedData = result || { locations: [] };

    // Save locations to database
    const savedLocations = [];
    const characterLocations = {};

    for (const loc of extractedData.locations || []) {
      try {
        // Check if location exists
        const existing = await base44.asServiceRole.entities.Location.filter({
          name: loc.name,
          session_id
        });

        let location;
        if (existing && existing.length > 0) {
          location = existing[0];
          // Update with latest context
          await base44.asServiceRole.entities.Location.update(location.id, {
            description: loc.description,
            visited: true,
            last_visit: new Date().toISOString(),
          });
        } else {
          // Create new location
          location = await base44.asServiceRole.entities.Location.create({
            session_id,
            name: loc.name,
            description: loc.description,
            category: loc.type || 'other',
            significance: loc.significance === 'strategic' ? 'important' : 'minor',
            visited: true,
            first_visit_session_id: session_id,
            icon_emoji: getLocationEmoji(loc.type),
          });
        }

        savedLocations.push({
          id: location.id,
          name: loc.name,
          characters: loc.characters_present,
        });

        // Track character presence at location
        for (const char of loc.characters_present || []) {
          if (!characterLocations[char]) {
            characterLocations[char] = [];
          }
          characterLocations[char].push({
            location: loc.name,
            context: loc.description,
            timestamp: new Date().toISOString(),
          });
        }
      } catch (err) {
        console.error(`Failed to save location ${loc.name}:`, err);
      }
    }

    return Response.json({
      success: true,
      locations: savedLocations,
      character_locations: characterLocations,
      total_locations: savedLocations.length,
    });
  } catch (error) {
    console.error('Location extraction error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function getLocationEmoji(type) {
  const emojis = {
    city: '🏰',
    building: '🏛️',
    wilderness: '🌲',
    dungeon: '🕳️',
    tavern: '🍺',
    throne: '👑',
    forest: '🌳',
    mountain: '⛰️',
    cave: '🗻',
    castle: '🏯',
    temple: '⛩️',
    market: '🏪',
  };
  return emojis[type] || '📍';
}