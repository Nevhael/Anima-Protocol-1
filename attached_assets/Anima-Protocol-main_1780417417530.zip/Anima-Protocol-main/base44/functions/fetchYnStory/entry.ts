import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { url, content } = await req.json();

    // If content is provided, parse it directly
    if (content) {
      const parseResult = parseStoryContent(content);

      const session = await base44.entities.ChatSession.create({
        title: parseResult.title,
        mode: 'solo',
        messages: parseResult.messages,
        last_message: parseResult.messages[parseResult.messages.length - 1]?.content.slice(0, 60) || '',
      });

      return Response.json({
        session_id: session.id,
        title: session.title,
        message_count: parseResult.messages.length,
        characters_found: parseResult.characters,
      });
    }

    // Otherwise, fetch from URL with API key if provided
    if (!url || typeof url !== 'string') {
      return Response.json({ error: 'No content or URL provided' }, { status: 400 });
    }

    const apiKey = Deno.env.get('YN_APP_API_KEY');
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    };
    if (apiKey) {
      headers['Authorization'] = `Bearer ${apiKey}`;
    }

    const response = await fetch(url, {
      headers,
      redirect: 'follow'
    });

    if (!response.ok) {
      return Response.json({ 
        error: `Failed to fetch URL: ${response.statusText}` 
      }, { status: 400 });
    }

    const html = await response.text();
    const content_extracted = extractStoryFromHtml(html);

    if (!content_extracted || content_extracted.length < 50) {
      return Response.json({ 
        error: 'Could not extract story content from URL. Try copying and pasting instead.' 
      }, { status: 400 });
    }

    const parseResult = parseStoryContent(content_extracted);
    const session = await base44.entities.ChatSession.create({
      title: parseResult.title,
      mode: 'solo',
      messages: parseResult.messages,
      last_message: parseResult.messages[parseResult.messages.length - 1]?.content.slice(0, 60) || '',
    });

    return Response.json({
      session_id: session.id,
      title: session.title,
      message_count: parseResult.messages.length,
      characters_found: parseResult.characters,
      source_url: url,
    });
  } catch (error) {
    console.error('Error processing Y/n story:', error);
    return Response.json(
      { error: error.message || 'Failed to process story' },
      { status: 500 }
    );
  }
});

function extractStoryFromHtml(html) {
  // Look for common Y/n content containers
  const patterns = [
    /<article[^>]*>(.*?)<\/article>/is,
    /<div[^>]*class="[^"]*story[^"]*"[^>]*>(.*?)<\/div>/is,
    /<div[^>]*class="[^"]*content[^"]*"[^>]*>(.*?)<\/div>/is,
    /<main[^>]*>(.*?)<\/main>/is,
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match) {
      let content = match[1];
      // Remove HTML tags but preserve line breaks
      content = content
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<p[^>]*>/gi, '\n')
        .replace(/<\/p>/gi, '')
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/g, ' ')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .split('\n')
        .map(line => line.trim())
        .filter(Boolean)
        .join('\n');
      
      if (content.length > 100) {
        return content;
      }
    }
  }

  // Fallback: extract all text
  const text = html
    .replace(/<script[^>]*>.*?<\/script>/gis, '')
    .replace(/<style[^>]*>.*?<\/style>/gis, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .join('\n');

  return text;
}

function parseStoryContent(content) {
  const lines = content.split('\n').map(l => l.trim()).filter(Boolean);
  
  if (lines.length === 0) {
    throw new Error('No content extracted');
  }

  const title = lines[0].slice(0, 100) || 'Imported Y/n Story';
  
  const characterPattern = /^\[([^\]]+)\]:|^(\*\*[^\*]+\*\*):/;
  const mentionedChars = new Set();
  
  const messages = [];
  let currentSpeaker = 'Narrator';

  lines.forEach((line, idx) => {
    if (idx === 0) return;

    const charMatch = line.match(characterPattern);
    
    if (charMatch) {
      currentSpeaker = charMatch[1] || charMatch[2].replace(/\*/g, '');
      const dialogue = line.replace(characterPattern, '').trim();
      mentionedChars.add(currentSpeaker);
      
      if (dialogue) {
        messages.push({
          role: 'assistant',
          character_name: currentSpeaker,
          content: dialogue,
          timestamp: new Date(Date.now() + idx * 1000).toISOString(),
        });
      }
    } else if (line) {
      messages.push({
        role: 'assistant',
        character_name: 'Narrator',
        content: line,
        timestamp: new Date(Date.now() + idx * 1000).toISOString(),
      });
    }
  });

  return {
    title,
    messages,
    characters: Array.from(mentionedChars),
  };
}