import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch recent check-ins and reflections
    const [checkIns, reflections] = await Promise.all([
      base44.entities.CheckIn.list('-created_date', 30),
      base44.entities.Reflection.list('-created_date', 30),
    ]);

    // Analyze mood patterns and emotional trends
    const moodCounts = {};
    let totalIntensity = 0;
    const breakthroughs = reflections.filter(r => r.tags?.includes('breakthrough')) || [];
    const shadowWork = reflections.filter(r => r.tags?.includes('shadow-work')) || [];

    checkIns.forEach(ci => {
      moodCounts[ci.mood] = (moodCounts[ci.mood] || 0) + 1;
      totalIntensity += ci.mood_intensity || 0;
    });

    const avgIntensity = checkIns.length > 0 ? totalIntensity / checkIns.length : 0;
    const dominantMood = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'balanced';

    // Extract recurring themes
    const allInsights = reflections.flatMap(r => r.insights_extracted || []);
    const themeFrequency = {};
    allInsights.forEach(insight => {
      themeFrequency[insight] = (themeFrequency[insight] || 0) + 1;
    });
    const topThemes = Object.entries(themeFrequency)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([theme]) => theme);

    // Build summary prompt injection
    const summaryPrompt = `
[LONG-TERM INSIGHTS FROM SHADOW WORK & REFLECTION]
Current Emotional Baseline: ${dominantMood} (avg intensity: ${avgIntensity.toFixed(1)}/10)
Recent Breakthroughs: ${breakthroughs.length} transformative insights
Shadow Work Sessions: ${shadowWork.length} deep inner work explorations
Recurring Growth Themes: ${topThemes.join(', ') || 'emerging patterns'}
Reflections This Month: ${reflections.length} documented insights

These patterns show ${user.full_name}'s journey toward growth and self-awareness.
Honor this evolution in your responses. Reference specific breakthroughs or themes when relevant.`;

    return Response.json({
      summary: summaryPrompt,
      stats: {
        avg_intensity: avgIntensity,
        dominant_mood: dominantMood,
        breakthroughs: breakthroughs.length,
        shadow_work_sessions: shadowWork.length,
        top_themes: topThemes,
        total_reflections: reflections.length
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});