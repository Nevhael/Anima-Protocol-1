import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const SEASON_DURATIONS = { spring: 90, summer: 90, autumn: 90, winter: 90 };
const SEASON_ORDER = ["spring", "summer", "autumn", "winter"];

// Narrative-driven time progression
// Time advances based on story decisions and scene shifts, not real-world elapsed time
const NARRATIVE_TIME_ADVANCES = {
  DECISION: 6,        // Major decision: +6 hours
  INTENSE_DECISION: 8, // Combat/intimacy decision: +8 hours
  LOCATION_SHIFT: 4,   // Scene transition: +4 hours
  CONFLICT: 5,         // Conflict moment: +5 hours
  DEFAULT: 0           // Regular dialogue: no advancement
};

const SEASONAL_EFFECTS = {
  spring: {
    description: "Blossoms bloom and the world awakens. Travel is easy, crops are being planted.",
    world_effects: [
      { subject: "Travel", fact: "Spring roads are clear and passable. Journey times are normal." },
      { subject: "Resources", fact: "Spring provides abundant fresh water and game. Food is easier to find." },
      { subject: "Mood", fact: "Spring brings hope and renewal. Characters feel energized and optimistic." }
    ]
  },
  summer: {
    description: "The sun burns bright. The land is vibrant with life but heat can be exhausting.",
    world_effects: [
      { subject: "Travel", fact: "Summer heat makes travel challenging. Dehydration is a real threat." },
      { subject: "Resources", fact: "Summer harvests are beginning. Markets are full but prices are high." },
      { subject: "Environment", fact: "Daylight dominates. Nights are short. Visibility is excellent." }
    ]
  },
  autumn: {
    description: "Leaves turn gold and red. Harvest season brings abundance and preparation for winter.",
    world_effects: [
      { subject: "Events", fact: "Autumn is harvest season. Festivals and celebrations are common. Trading is brisk." },
      { subject: "Resources", fact: "Autumn bounty is at its peak. Food is abundant and prices are lowest." },
      { subject: "Mood", fact: "Autumn brings a sense of culmination. Characters reflect on past victories and losses." }
    ]
  },
  winter: {
    description: "Snow blankets the land. Cold and isolation shape survival and introspection.",
    world_effects: [
      { subject: "Travel", fact: "Winter snow and ice make travel perilous. Movement is slow and dangerous." },
      { subject: "Resources", fact: "Winter supplies are scarce. Food must be hunted or stored. Prices are steep." },
      { subject: "Survival", fact: "Winter cold threatens life. Shelter, warmth, and rest are critical. Community bonds deepen." }
    ]
  }
};

// Detect narrative events that trigger time advancement
function detectNarrativeEvent(userMessage, aiResponse) {
  const combined = ((userMessage || "") + (aiResponse || "")).toLowerCase();

  // Intense decisions (combat/intimacy)
  const intenseKeywords = ["fight", "battle", "attack", "kiss", "embrace", "confess", "surrender", "kill", "passion"];
  if (intenseKeywords.some(k => combined.includes(k))) {
    return { type: "INTENSE_DECISION", hours: NARRATIVE_TIME_ADVANCES.INTENSE_DECISION };
  }

  // Location shifts (new scene/area)
  const locationKeywords = ["[location:", "arrives at", "enters", "reaches", "emerges", "arrives"];
  if (locationKeywords.some(k => combined.includes(k))) {
    return { type: "LOCATION_SHIFT", hours: NARRATIVE_TIME_ADVANCES.LOCATION_SHIFT };
  }

  // Conflict moments
  const conflictKeywords = ["disagree", "argue", "oppose", "refuse", "challenge", "confront"];
  if (conflictKeywords.some(k => combined.includes(k))) {
    return { type: "CONFLICT", hours: NARRATIVE_TIME_ADVANCES.CONFLICT };
  }

  // Regular decision (question answered, choice made)
  if (userMessage && aiResponse && aiResponse.length > 50) {
    return { type: "DECISION", hours: NARRATIVE_TIME_ADVANCES.DECISION };
  }

  return { type: "DEFAULT", hours: NARRATIVE_TIME_ADVANCES.DEFAULT };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { session_id, user_message = "", ai_response = "", message_index = 0 } = await req.json();
    if (!session_id) return Response.json({ error: 'session_id required' }, { status: 400 });

    // Get or create calendar for this session
    let calendar = (await base44.asServiceRole.entities.Calendar.filter({ session_id }))?.at(0);
    
    if (!calendar) {
      calendar = await base44.asServiceRole.entities.Calendar.create({
        session_id,
        days_elapsed: 0,
        current_season: "spring",
        day_of_season: 1,
        weather: "clear",
        seasonal_description: SEASONAL_EFFECTS.spring.description,
        last_update_timestamp: new Date().toISOString(),
        accumulated_hours: 0
      });
    }

    // Detect narrative event and calculate hours to add
    const event = detectNarrativeEvent(user_message, ai_response);
    const hoursToAdd = event.hours;
    const accumulatedTotal = (calendar.accumulated_hours || 0) + hoursToAdd;

    let newDaysElapsed = calendar.days_elapsed || 0;
    let newDayOfSeason = calendar.day_of_season || 1;
    let newSeason = calendar.current_season || "spring";
    let newAccumulatedHours = accumulatedTotal;
    let seasonChanged = false;

    // Check if accumulated hours trigger a new day (24 hours = 1 day)
    if (accumulatedTotal >= 24) {
      const daysToAdd = Math.floor(accumulatedTotal / 24);
      newAccumulatedHours = accumulatedTotal % 24; // Keep remainder
      newDaysElapsed += daysToAdd;
      newDayOfSeason += daysToAdd;

      // Check for season transition
      const currentSeasonDuration = SEASON_DURATIONS[newSeason];
      if (newDayOfSeason > currentSeasonDuration) {
        const fullCycles = Math.floor((newDayOfSeason - 1) / currentSeasonDuration);
        newDayOfSeason = ((newDayOfSeason - 1) % currentSeasonDuration) + 1;
        const currentSeasonIndex = SEASON_ORDER.indexOf(newSeason);
        newSeason = SEASON_ORDER[(currentSeasonIndex + fullCycles) % SEASON_ORDER.length];
        seasonChanged = true;
      }
    }

    // Update calendar
    const updatedCalendar = await base44.asServiceRole.entities.Calendar.update(calendar.id, {
      days_elapsed: newDaysElapsed,
      current_season: newSeason,
      day_of_season: Math.floor(newDayOfSeason),
      seasonal_description: SEASONAL_EFFECTS[newSeason].description,
      last_update_timestamp: new Date().toISOString(),
      accumulated_hours: newAccumulatedHours,
      last_transition_message_index: seasonChanged ? message_index : calendar.last_transition_message_index
    });

    // If season changed, inject seasonal world state entries
    let createdLore = [];
    if (seasonChanged) {
      const effects = SEASONAL_EFFECTS[newSeason].world_effects;
      for (const effect of effects) {
        const entry = await base44.asServiceRole.entities.WorldState.create({
          session_id,
          category: "rule",
          subject: effect.subject,
          fact: effect.fact,
          importance: "high",
          is_active: true,
          source_message_index: message_index
        });
        createdLore.push(entry);
      }
    }

    return Response.json({
      calendar: updatedCalendar,
      season_changed: seasonChanged,
      new_season: newSeason,
      lore_created: createdLore.length,
      effects: seasonChanged ? SEASONAL_EFFECTS[newSeason].world_effects : [],
      narrative_event: event.type,
      hours_added: hoursToAdd,
      in_game_days_added: newDaysElapsed - (calendar.days_elapsed || 0)
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});