import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";

/**
 * Maps emotion to voice parameters for ElevenLabs API
 */
function getEmotionalVoiceSettings(emotion, intensity = 5) {
  const intensityRatio = Math.max(0, Math.min(10, intensity)) / 10;

  const baseSettings = {
    stability: 0.5,
    similarity_boost: 0.75,
    style: 0,
    speaker_boost: true,
  };

  const emotionSettings = {
    joyful: {
      stability: 0.4 + intensityRatio * 0.2,
      similarity_boost: 0.85,
      style: 25 + intensityRatio * 25,
    },
    calm: {
      stability: 0.7 + intensityRatio * 0.15,
      similarity_boost: 0.8,
      style: 5 + intensityRatio * 10,
    },
    sad: {
      stability: 0.65 + intensityRatio * 0.15,
      similarity_boost: 0.7,
      style: 30 + intensityRatio * 20,
    },
    angry: {
      stability: 0.3 + intensityRatio * 0.2,
      similarity_boost: 0.85,
      style: 50 + intensityRatio * 20,
    },
    anxious: {
      stability: 0.4 + intensityRatio * 0.15,
      similarity_boost: 0.75,
      style: 40 + intensityRatio * 20,
    },
    peaceful: {
      stability: 0.75 + intensityRatio * 0.2,
      similarity_boost: 0.8,
      style: 10 + intensityRatio * 5,
    },
    hopeful: {
      stability: 0.55 + intensityRatio * 0.15,
      similarity_boost: 0.85,
      style: 20 + intensityRatio * 15,
    },
    conflicted: {
      stability: 0.45 + intensityRatio * 0.2,
      similarity_boost: 0.7,
      style: 35 + intensityRatio * 20,
    },
  };

  const emotionKey = emotion?.toLowerCase() || "neutral";
  const settings = emotionSettings[emotionKey];

  return settings ? { ...baseSettings, ...settings } : baseSettings;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { text, voice_id, emotion, intensity = 5 } = await req.json();

    if (!text || !voice_id) {
      return Response.json(
        { error: "Missing text or voice_id" },
        { status: 400 }
      );
    }

    // Get emotional voice settings
    const voiceSettings = getEmotionalVoiceSettings(emotion, intensity);

    console.log(
      `Synthesizing voice with emotion: ${emotion} (intensity: ${intensity})`
    );
    console.log(`Voice settings: ${JSON.stringify(voiceSettings)}`);

    // Call ElevenLabs API with emotional parameters
    const elevenLabsUrl = `https://api.elevenlabs.io/v1/text-to-speech/${voice_id}?optimize_streaming_latency=0`;

    const response = await fetch(elevenLabsUrl, {
      method: "POST",
      headers: {
        "xi-api-key": Deno.env.get("ELEVENLABS_API_KEY"),
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
          stability: Math.round(voiceSettings.stability * 100) / 100,
          similarity_boost: Math.round(voiceSettings.similarity_boost * 100) / 100,
          style: Math.round(voiceSettings.style),
          use_speaker_boost: voiceSettings.speaker_boost,
        },
      }),
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error(`ElevenLabs API error: ${response.status} - ${errorData}`);
      throw new Error(`ElevenLabs API error: ${response.status}`);
    }

    // Stream audio response
    const audioBuffer = await response.arrayBuffer();
    const audioBase64 = btoa(String.fromCharCode(...new Uint8Array(audioBuffer)));

    return Response.json({
      audio_base64: audioBase64,
      emotion_applied: emotion,
      voice_settings: voiceSettings,
    });
  } catch (error) {
    console.error("Voice emotion synthesis error:", error.message);
    return Response.json(
      { error: error.message || "Voice synthesis failed" },
      { status: 500 }
    );
  }
});