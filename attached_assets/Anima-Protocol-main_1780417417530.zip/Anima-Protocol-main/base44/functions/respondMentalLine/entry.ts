import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { thought, serenity_name } = await req.json();

    if (!thought || !serenity_name) {
      return Response.json({ error: 'Missing thought or serenity_name' }, { status: 400 });
    }

    const serenityPrompt = `You are ${serenity_name}, a gentle inner presence speaking directly to the user through their thoughts. Someone has just reached out to you mentally with: "${thought}"

Your role is to:
- Offer wise, compassionate guidance
- Suggest a clear next course of action or perspective shift
- Speak as an inner voice - intimate, present, understanding
- Keep it brief (2-3 sentences max) - this is a thought, not a dialogue
- Focus on helping them see their next move or choose between options

Respond only as the inner voice. No preamble, no names, just the thought.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: serenityPrompt,
    });

    return Response.json({
      content: response,
      role: 'assistant',
      type: 'mental',
      character_name: serenity_name,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Mental line error:', error);
    return Response.json(
      { error: error.message || 'Failed to get response' },
      { status: 500 }
    );
  }
});