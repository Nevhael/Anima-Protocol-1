import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { session_id, character_id } = await req.json();

    if (!session_id) {
      return Response.json({ error: 'session_id required' }, { status: 400 });
    }

    // Fetch session context data
    const [session, char, locations, relationships, lore] = await Promise.all([
      base44.entities.ChatSession.list("-updated_date", 1),
      character_id ? base44.entities.Character.list("-created_date", 100) : Promise.resolve([]),
      base44.entities.Location.list("-created_date", 100),
      base44.entities.CharacterRelationship.filter({ session_id }),
      base44.entities.WorldState.filter({ session_id, is_active: true }, "-created_date", 50),
    ]);

    const currentSession = session?.find(s => s.id === session_id);
    const activeChar = character_id ? char?.find(c => c.id === character_id) : null;

    if (!currentSession) {
      return Response.json({ error: 'Session not found' }, { status: 404 });
    }

    // Extract narrative context from recent messages
    const recentMessages = (currentSession.messages || []).slice(-10);
    const narrativeContext = recentMessages.map(m => m.content).join(' ');

    // Build context for LLM
    const contextPrompt = `
You are a quest generator for an immersive narrative RPG. Based on the narrative context, character relationships, and locations, generate 3 engaging quests.

NARRATIVE CONTEXT:
${narrativeContext.slice(0, 500)}

ACTIVE CHARACTER: ${activeChar?.name || 'Player Character'}
CHARACTER RELATIONSHIPS:
${relationships?.slice(0, 5).map(r => `- ${r.character_id}: ${r.tier} (${r.score}/100)`).join('\n')}

AVAILABLE LOCATIONS:
${locations?.slice(0, 5).map(l => `- ${l.name}: ${l.description?.slice(0, 50)}`).join('\n')}

WORLD LORE:
${lore?.slice(0, 5).map(l => `- ${l.subject}: ${l.fact.slice(0, 50)}`).join('\n')}

Generate 3 quests as JSON array with this structure:
[
  {
    "title": "Quest Name",
    "description": "Detailed description tied to narrative",
    "difficulty": "easy|moderate|hard|legendary",
    "objectives": [
      { "description": "Objective 1", "completed": false },
      { "description": "Objective 2", "completed": false }
    ],
    "required_locations": ["location_name_1", "location_name_2"],
    "related_characters": ["character_name_1"],
    "narrative_context": "How this connects to the story",
    "rewards": {
      "xp": 100,
      "items": ["item_name"],
      "relationship_bonuses": {
        "character_name": 10
      }
    }
  }
]

Make quests feel organic to the narrative, not generic. Use character names and location names from context.
`;

    // Call LLM to generate quests
    const llmResult = await base44.integrations.Core.InvokeLLM({
      prompt: contextPrompt,
      response_json_schema: {
        type: "object",
        properties: {
          quests: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                difficulty: { type: "string" },
                objectives: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      description: { type: "string" },
                      completed: { type: "boolean" }
                    }
                  }
                },
                required_locations: { type: "array", items: { type: "string" } },
                related_characters: { type: "array", items: { type: "string" } },
                narrative_context: { type: "string" },
                rewards: {
                  type: "object",
                  properties: {
                    xp: { type: "number" },
                    items: { type: "array", items: { type: "string" } },
                    relationship_bonuses: { type: "object" }
                  }
                }
              }
            }
          }
        }
      }
    });

    // Map generated quests to database records
    const quests = llmResult.quests || [];
    const createdQuests = await Promise.all(
      quests.map(q =>
        base44.entities.Quest.create({
          session_id,
          title: q.title,
          description: q.description,
          objectives: q.objectives || [],
          required_locations: q.required_locations || [],
          related_characters: q.related_characters || [],
          narrative_context: q.narrative_context,
          rewards: q.rewards || { xp: 0, items: [], relationship_bonuses: {} },
          difficulty: q.difficulty || "moderate",
          status: "available"
        })
      )
    );

    return Response.json({
      generated: createdQuests.length,
      quests: createdQuests
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});