import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_name } = await req.json();

    if (!character_name) {
      return Response.json({ error: 'Character name required' }, { status: 400 });
    }

    // Use LLM to analyze character and propose behavior settings
    const prompt = `Analyze the following character and suggest AI behavior slider values (0-100 scale) for a conversational AI:

Character: ${character_name}

Based on typical character archetypes and common personality traits, suggest values for:
1. verbosity (0=concise, 100=verbose)
2. emotional_intensity (0=stoic, 100=emotional)
3. lore_compliance (0=flexible, 100=strict)
4. vibrato (0=monotone, 100=expressive)
5. lewdity (0=family-friendly, 100=explicit)
6. sexuality (0=neutral, 100=flirtatious)
7. humor (0=serious, 100=comedic)
8. sarcasm (0=sincere, 100=sarcastic)
9. aggressiveness (0=gentle, 100=hostile)

Respond ONLY with a JSON object with these exact keys and numeric values. Example:
{"verbosity": 45, "emotional_intensity": 65, "lore_compliance": 70, "vibrato": 55, "lewdity": 20, "sexuality": 30, "humor": 60, "sarcasm": 35, "aggressiveness": 25}`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          verbosity: { type: 'number' },
          emotional_intensity: { type: 'number' },
          lore_compliance: { type: 'number' },
          vibrato: { type: 'number' },
          lewdity: { type: 'number' },
          sexuality: { type: 'number' },
          humor: { type: 'number' },
          sarcasm: { type: 'number' },
          aggressiveness: { type: 'number' },
        },
        required: [
          'verbosity',
          'emotional_intensity',
          'lore_compliance',
          'vibrato',
          'lewdity',
          'sexuality',
          'humor',
          'sarcasm',
          'aggressiveness',
        ],
      },
    });

    return Response.json({
      verbosity: Math.max(0, Math.min(100, result.verbosity || 50)),
      emotional_intensity: Math.max(0, Math.min(100, result.emotional_intensity || 60)),
      lore_compliance: Math.max(0, Math.min(100, result.lore_compliance || 70)),
      vibrato: Math.max(0, Math.min(100, result.vibrato || 50)),
      lewdity: Math.max(0, Math.min(100, result.lewdity || 30)),
      sexuality: Math.max(0, Math.min(100, result.sexuality || 40)),
      humor: Math.max(0, Math.min(100, result.humor || 50)),
      sarcasm: Math.max(0, Math.min(100, result.sarcasm || 40)),
      aggressiveness: Math.max(0, Math.min(100, result.aggressiveness || 30)),
    });
  } catch (error) {
    console.error('Error analyzing character:', error);
    return Response.json(
      { error: error.message || 'Failed to analyze character' },
      { status: 500 }
    );
  }
});