import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      session_id,
      active_character_id,
      recent_messages,
      characters_in_session,
      all_characters
    } = await req.json();

    if (!session_id || !active_character_id || !recent_messages || recent_messages.length === 0) {
      return Response.json({ skipped: true });
    }

    // Find guest characters who haven't spoken recently
    const recentSpeakers = recent_messages
      .slice(-5)
      .map(m => m.character_name)
      .filter(v => v && v !== "Narrator");

    const availableGuests = characters_in_session.filter(
      name => name !== recentSpeakers[recentSpeakers.length - 1] && recentSpeakers.indexOf(name) === -1
    );

    if (availableGuests.length === 0) {
      return Response.json({ skipped: true });
    }

    // Pick random guest
    const randomGuest = availableGuests[Math.floor(Math.random() * availableGuests.length)];
    const guestData = all_characters.find(c => c.name === randomGuest);

    if (!guestData) {
      return Response.json({ skipped: true });
    }

    const messageContext = recent_messages
      .slice(-4)
      .map(m => `${m.character_name || "User"}: ${m.content}`)
      .join('\n');

    const prompt = `You are ${guestData.name}${guestData.universe ? ` from ${guestData.universe}` : ""}.
${guestData.personality ? `Personality: ${guestData.personality}\n` : ""}${guestData.speaking_style ? `Voice: ${guestData.speaking_style}\n` : ""}
Recent conversation:
${messageContext}

Briefly react (1-2 sentences max) as ${guestData.name} to what was just said. Only respond if it makes sense for your character—if it doesn't naturally fit, respond with "SKIP".`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt });

    if (result && result.trim() !== "SKIP" && result.trim().length > 0) {
      return Response.json({
        interaction: {
          character_name: randomGuest,
          content: result.replace(/\[(EMOTION|LOCATION):[^\]]+\]/gi, "").trim(),
        }
      });
    }

    return Response.json({ skipped: true });
  } catch (error) {
    console.error('Error triggering AI interaction:', error);
    return Response.json({ skipped: true });
  }
});