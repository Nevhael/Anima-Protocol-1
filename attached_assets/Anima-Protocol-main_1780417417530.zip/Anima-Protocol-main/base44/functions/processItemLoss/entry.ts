import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { character_id, session_id, loss_type, item_name, quantity, reason } = await req.json();

    if (!character_id || !session_id || !loss_type || !item_name) {
      return Response.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    // Find the item
    const items = await base44.entities.Inventory.filter({
      character_id,
      session_id,
      name: item_name,
    });

    const item = items?.[0];
    if (!item) {
      return Response.json({ error: 'Item not found' }, { status: 404 });
    }

    const qtyToRemove = quantity || 1;
    let narrativeEvent = null;

    // Process loss
    if (loss_type === 'destroy') {
      // Permanently remove the item
      item.quantity -= qtyToRemove;
      narrativeEvent = `${item_name} was destroyed${reason ? ` (${reason})` : ''}`;
    } else if (loss_type === 'drop') {
      item.quantity -= qtyToRemove;
      narrativeEvent = `${item_name} was dropped and lost`;
    } else if (loss_type === 'steal') {
      item.quantity -= qtyToRemove;
      narrativeEvent = `${item_name} was stolen by an unknown thief`;
    } else if (loss_type === 'consume') {
      item.quantity -= qtyToRemove;
      narrativeEvent = `${item_name} was consumed/used`;
    }

    // Update or delete
    if (item.quantity <= 0) {
      await base44.entities.Inventory.delete(item.id);
    } else {
      await base44.entities.Inventory.update(item.id, { quantity: item.quantity });
    }

    // If item was equipped, unequip it
    if (item.equipped && item.quantity <= 0) {
      // Item is gone, so equipment slot is now free
    } else if (item.equipped) {
      await base44.entities.Inventory.update(item.id, { equipped: false });
    }

    return Response.json({
      success: true,
      item_name,
      quantity_removed: qtyToRemove,
      remaining_quantity: Math.max(0, item.quantity),
      narrative_event: narrativeEvent,
    });
  } catch (error) {
    console.error('Item loss error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});