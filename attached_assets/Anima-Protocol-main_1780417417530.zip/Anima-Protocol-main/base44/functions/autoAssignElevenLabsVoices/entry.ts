import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Auto-assigns ElevenLabs voice IDs to characters that don't have them.
 * Uses character personality to select appropriate voice profiles.
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Fetch available voices from ElevenLabs
    const voicesResponse = await fetch('https://api.elevenlabs.io/v1/voices', {
      headers: {
        'xi-api-key': Deno.env.get('ELEVENLABS_API_KEY'),
      },
    });

    if (!voicesResponse.ok) {
      throw new Error(`ElevenLabs API error: ${voicesResponse.statusText}`);
    }

    const voicesData = await voicesResponse.json();
    const availableVoices = voicesData.voices || [];

    // Get all characters
    const allCharacters = await base44.asServiceRole.entities.Character.list();

    // Filter characters without voice IDs
    const needsVoice = allCharacters.filter(c => !c.elevenlabs_voice_id);

    if (needsVoice.length === 0) {
      return Response.json({ assigned: 0, message: 'All characters already have voices' });
    }

    // Voice personality mapping
    const voiceMapping = {
      companion: 'soft', // Warm, supportive
      warrior: 'deep', // Strong, confident
      mystic: 'ethereal', // Mysterious, wise
      scientist: 'neutral', // Clear, analytical
      villain: 'dark', // Intense, commanding
      hero: 'bright', // Heroic, powerful
      other: 'balanced', // Generic
      guardian: 'protective', // Caring
      muse: 'artistic', // Creative
      sage: 'wise', // Contemplative
      trickster: 'playful', // Energetic
      shadow: 'mysterious', // Deep
      lover: 'warm', // Intimate
      explorer: 'adventurous', // Energetic
      oracle: 'ethereal', // Mystical
    };

    const assigned = [];

    for (const character of needsVoice) {
      const category = character.category || 'other';
      const voiceType = voiceMapping[category] || 'balanced';

      // Find best matching voice
      let selectedVoice = availableVoices.find(v =>
        v.name?.toLowerCase().includes(voiceType) ||
        v.labels?.some(l => l?.toLowerCase().includes(voiceType))
      ) || availableVoices[Math.floor(Math.random() * availableVoices.length)];

      if (selectedVoice) {
        try {
          await base44.asServiceRole.entities.Character.update(character.id, {
            elevenlabs_voice_id: selectedVoice.voice_id,
          });

          assigned.push({
            character_id: character.id,
            character_name: character.name,
            voice_id: selectedVoice.voice_id,
            voice_name: selectedVoice.name,
          });
        } catch (err) {
          console.error(`Failed to assign voice to ${character.name}:`, err);
        }
      }
    }

    return Response.json({
      assigned: assigned.length,
      total_needed: needsVoice.length,
      assignments: assigned,
    });
  } catch (error) {
    console.error('Auto-assign voices error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});