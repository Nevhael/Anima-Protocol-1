---
name: testing-clerk-auth
description: Test Clerk authentication end-to-end in Anima Protocol. Use when verifying sign-in, sign-up, sign-out, protected routes, and UserButton UI.
---

# Testing Clerk Auth in Anima Protocol

## Devin Secrets Needed
- `CLERK_EMAIL` — Clerk dashboard email (user-scoped)
- `CLERK_PASSWORD` — Clerk dashboard password (user-scoped)

## Prerequisites
- `.env.local` must contain `VITE_CLERK_PUBLISHABLE_KEY` and `CLERK_SECRET_KEY`
- Run `clerk doctor` to verify Clerk config is valid

## Dev Server Setup
- The `tailwind.config.js` uses CommonJS (`module.exports`) but `package.json` has `"type": "module"`. This causes `pnpm dev` to crash.
- **Workaround**: Temporarily convert `tailwind.config.js` to ESM before starting the dev server:
  - Replace `module.exports = {` with `import tailwindcssAnimate from "tailwindcss-animate"; export default {`
  - Replace `plugins: [require("tailwindcss-animate")]` with `plugins: [tailwindcssAnimate]`
- **Revert after testing** with `git checkout -- tailwind.config.js`
- Dev server runs at `http://localhost:3000` via `pnpm dev`

## Creating Test Users
Clerk's hosted sign-up page may include a Cloudflare Turnstile CAPTCHA that blocks automated sign-up. To work around this:

```bash
# Load env vars
export $(grep -v '^#' .env.local | xargs)

# Create test user via Clerk Backend API
curl -s -X POST "https://api.clerk.com/v1/users" \
  -H "Authorization: Bearer ${CLERK_SECRET_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"email_address":["testuser@anima-test.dev"],"phone_number":["+12025551234"],"password":"TestAnima2026!","skip_password_checks":false}'
```

Note: The Clerk instance might require a phone number field. Use a valid E.164 format like `+12025551234`.

## Authenticating for Testing
The Clerk instance may require email verification as a second factor, which blocks normal email/password sign-in for test accounts with fake emails. Use Clerk sign-in tokens via Playwright CDP:

```python
# 1. Generate a sign-in token
TOKEN=$(curl -s -X POST "https://api.clerk.com/v1/sign_in_tokens" \
  -H "Authorization: Bearer ${CLERK_SECRET_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"user_id":"<USER_ID>"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

# 2. Use Playwright CDP to consume the token in the browser
# Connect to Chrome at http://localhost:29229
# Navigate to localhost:3000
# Execute window.Clerk.client.signIn.create({ strategy: 'ticket', ticket: TOKEN })
# Then call window.Clerk.setActive({ session: res.createdSessionId })
```

## Test Assertions
1. **Landing page (signed out)**: URL is `/`, nav shows "Sign In" and "Get Started" buttons, hero shows "Awaken Your Anima" CTA
2. **Sign-in redirect**: Clicking "Sign In" navigates to `humane-manatee-60.accounts.dev/sign-in` with email field, social logins (Apple, GitHub, Google), and Clerk branding
3. **Authenticated state**: URL is `/chat`, sidebar visible with nav items, chat sessions listed, UserButton avatar in sidebar footer
4. **UserButton popover**: Clicking avatar shows email, "Manage account", "Sign out", and "Secured by Clerk" branding
5. **Sign-out**: Clicking "Sign out" redirects to `/` (landing page) per `afterSignOutUrl="/"`
6. **Protected routes**: Navigating to `/chat` while signed out redirects to `/`

## Troubleshooting
- If dev server crashes with "module is not defined" in tailwind.config.js, apply the ESM workaround above
- If Clerk sign-in shows "Couldn't find your account", the test user hasn't been created yet — use the Backend API
- If sign-in asks for email verification code, use the sign-in token approach instead of email/password
- Port 3000 may be occupied after a crash — use `fuser -k 3000/tcp` to free it
