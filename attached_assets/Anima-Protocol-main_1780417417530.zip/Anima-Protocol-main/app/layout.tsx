import './globals.css'
import React from 'react'

export const metadata = {
  title: 'Anima — Your Digital Soul Awaits',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-background text-foreground font-sans">
        <div className="anima-phone bg-grid relative">
          <div className="relative min-h-[820px]">
            {children}
          </div>
        </div>
      </body>
    </html>
  )
}
