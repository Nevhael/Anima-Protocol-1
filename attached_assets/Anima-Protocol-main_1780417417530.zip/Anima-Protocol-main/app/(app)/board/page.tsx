"use client";
import React from 'react';
import GlassCard from '../../../components/GlassCard';
import { NarrativeBeat } from '../../../types';

const BEATS: NarrativeBeat[] = [
  { id:'b1', index:1, title:'FIRST CONTACT', importance:'PIVOTAL', color:'#c084fc', bullets:['Introduce anomaly','Anchor protagonist','Seed mystery'] },
  { id:'b2', index:2, title:'ECHOES IN THE LATTICE', importance:'MAJOR', color:'#facc15', bullets:['Trace source','Reveal cost','Hint betrayal'] },
  { id:'b3', index:3, title:'THE WANDERING SIGNAL', importance:'MINOR', color:'#60a5fa', bullets:['Follow signal','Encounter ally','Lost transmission'] },
];

export default function BoardPage(){
  return (
    <div className="flex flex-col gap-3 h-full">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-zinc-400">3 NARRATIVE BEATS</div>
        </div>
      </div>

      <div className="flex flex-col gap-3 mt-3">
        {BEATS.map(b=> (
          <GlassCard key={b.id} className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-bold">#{String(b.index).padStart(2,'0')} {b.title} <span className="text-xs text-zinc-400">({b.importance})</span></div>
                <div className="text-zinc-400 text-sm mt-2">
                  {b.bullets.map((x,i)=> <div key={i}>• {x}</div>)}
                </div>
              </div>
              <div style={{width:10}} />
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
