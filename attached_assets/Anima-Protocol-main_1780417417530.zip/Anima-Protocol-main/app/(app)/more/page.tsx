"use client";
import React from 'react';
import GlassCard from '../../../components/GlassCard';

const MODULES = ['CHAT','SETTINGS','STORYBOARD','NARRATIVE DASHBOARD','FLOWCHART','BRANCHING PATHS','WHAT-IF SCENARIOS','QUEST JOURNAL','LOCATIONS MAP','CALENDAR','CHRONICLES','WORLD CODEX','LORE BOOK','JOURNALS','SESSION WIKI','GLOBAL WIKI','MEMORY MAP','INVENTORY','CHARACTERS','WORLD MAP','SIGN OUT'];

export default function MorePage(){
  return (
    <div className="h-full">
      <div className="text-xs text-zinc-400 mb-2">ALL MODULES</div>
      <div className="grid grid-cols-4 gap-3">
        {MODULES.map(m=> (
          <GlassCard key={m} className={`text-center p-3 ${m==='WORLD MAP'? 'border-2 border-teal-400':''} ${m==='SIGN OUT'?'border-2 border-red-500':''}`}>
            <div className="text-xs font-semibold">{m}</div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
