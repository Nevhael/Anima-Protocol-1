"use client";
import React from 'react';
import StatusBar from '../../components/StatusBar';
import BottomNav from '../../components/BottomNav';
import {
  SidebarProvider,
  Sidebar,
  SidebarInset,
} from '@/components/ui/sidebar'
import { motion } from 'framer-motion';
import '../../app/globals.css';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <div className="min-h-[100dvh] flex bg-background scanline text-primary relative">
        {/* Left sidebar (desktop) — hidden on mobile via Sidebar component */}
        <Sidebar side="left" variant="sidebar" className="w-64 bg-black/95 backdrop-blur-md border-r border-primary/20">
          <div className="p-4">
            <div className="text-lg font-medium">Anima</div>
          </div>
        </Sidebar>

        {/* Main content area — collapses padding for desktop */}
        <SidebarInset className="flex-1">
          <div className="w-full">
            <StatusBar />

            <motion.main
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.32 }}
              className="min-h-[100dvh] overflow-hidden px-4 pb-[calc(var(--tab-bar-height)+1rem)] lg:pb-0"
              style={{ paddingBottom: 'var(--tab-bar-height, 56px)' }}
            >
              {children}
            </motion.main>

            <BottomNav />
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
