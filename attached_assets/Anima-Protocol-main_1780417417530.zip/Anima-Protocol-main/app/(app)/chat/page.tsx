"use client";
import React from 'react';
import { Session } from '../../../types';
import GlassCard from '../../../components/GlassCard';
import NeonButton from '../../../components/NeonButton';

const MOCK: Session[] = [
  { id:'s1', title:'FIRST CONTACT', character:'Wanda Maximoff', snippet:'The stars whispered your name…', updatedAt:'15m ago' },
  { id:'s2', title:'TIDELASS VIGIL', character:'Steve Rogers', snippet:'I traced the resonance to its source.', updatedAt:'2h ago' },
  { id:'s3', title:'HOLLOW REFUSAL', character:'Korra', snippet:'I closed the chamber and walked away.', updatedAt:'1d ago' },
];

export default function ChatPage(){
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-zinc-400">SESSIONS</div>
          <div className="text-sm text-zinc-200">SWIPE TO DELETE</div>
        </div>
        <NeonButton>NEW</NeonButton>
      </div>

      <div className="mt-4 flex flex-col gap-3">
        {MOCK.map(s=> (
          <GlassCard key={s.id} className="flex items-start gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#06b6d4]/20 to-[#7c3aed]/20 flex items-center justify-center">
              <div className="text-xs text-zinc-100">{s.title.split(' ')[0]}</div>
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div className="font-semibold">{s.title} — {s.character}</div>
                <div className="text-xs text-zinc-400">{s.updatedAt}</div>
              </div>
              <div className="text-zinc-400 text-sm mt-1">{s.snippet}</div>
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="mt-auto text-zinc-400 text-xs">Anima is typing…</div>
    </div>
  );
}
