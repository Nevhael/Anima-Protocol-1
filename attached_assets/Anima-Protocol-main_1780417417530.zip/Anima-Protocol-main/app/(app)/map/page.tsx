"use client";
import React, { useState } from 'react';
import GlassCard from '../../../components/GlassCard';
import GlowingOrb from '../../../components/GlowingOrb';
import { Region } from '../../../types';

const REGIONS: Region[] = [
  { id:'r1', name:'Halcyon Plateau', status:'STABLE', population:'1.2M', control:'Ascendant Compact', coords:[42,38], description:'A bastion of light and trade.', color:'#34d399' },
  { id:'r2', name:'Hollow Foundries', status:'CONTESTED', population:'400k', control:'Red Syndicate', coords:[18,22], description:'Molten cities and whispering forges.', color:'#f59e0b' },
  { id:'r3', name:'Ember Marches', status:'HOSTILE', population:'80k', control:'Ember Clans', coords:[61,12], description:'Scorched badlands.', color:'#ef4444' },
];

export default function MapPage(){
  const [selected, setSelected] = useState<Region | null>(REGIONS[0]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 relative bg-grid rounded-xl p-3">
        <div className="w-full h-full flex items-center justify-center">
          <svg viewBox="0 0 600 400" className="w-full h-full">
            {/* faint map grid */}
          </svg>
          <div className="absolute top-16 left-10">
            <div onClick={()=>setSelected(REGIONS[0])} className="cursor-pointer"><GlowingOrb color={REGIONS[0].color} label={REGIONS[0].name} /></div>
          </div>
          <div className="absolute top-40 right-12">
            <div onClick={()=>setSelected(REGIONS[1])} className="cursor-pointer"><GlowingOrb color={REGIONS[1].color} label={REGIONS[1].name} /></div>
          </div>
          <div className="absolute bottom-24 left-20">
            <div onClick={()=>setSelected(REGIONS[2])} className="cursor-pointer"><GlowingOrb color={REGIONS[2].color} label={REGIONS[2].name} /></div>
          </div>
        </div>
      </div>

      {selected && (
        <GlassCard className="mt-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-bold">{selected.name}</div>
              <div className="text-xs text-zinc-400">{selected.status} • Population: {selected.population}</div>
              <div className="text-xs text-zinc-400">Control: {selected.control} • Coords: {selected.coords?.join(',')}</div>
              <div className="mt-2 text-zinc-300 text-sm">{selected.description}</div>
            </div>
            <div className="flex flex-col gap-2 text-xs">
              <div className="px-2 py-1 rounded-md bg-green-600/10 text-green-300">STABLE</div>
              <div className="px-2 py-1 rounded-md bg-zinc-800/40 text-zinc-300">Legend</div>
            </div>
          </div>
        </GlassCard>
      )}
    </div>
  );
}
