"use client";
import React from 'react';
import { motion } from 'framer-motion';
import FlameEmblem from '../components/FlameEmblem';

export default function SerenityPage() {
  return (
    <div className="min-h-screen bg-[#0a0c12] flex flex-col overflow-hidden relative">
      {/* Background: Grid + Binary code overlay */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Blue grid lines */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(0deg, transparent 24%, rgba(6, 182, 212, 0.05) 25%, rgba(6, 182, 212, 0.05) 26%, transparent 27%, transparent 74%, rgba(6, 182, 212, 0.05) 75%, rgba(6, 182, 212, 0.05) 76%, transparent 77%, transparent),
              linear-gradient(90deg, transparent 24%, rgba(6, 182, 212, 0.05) 25%, rgba(6, 182, 212, 0.05) 26%, transparent 27%, transparent 74%, rgba(6, 182, 212, 0.05) 75%, rgba(6, 182, 212, 0.05) 76%, transparent 77%, transparent)
            `,
            backgroundSize: '50px 50px',
          }}
        />

        {/* Binary code overlay - faint distributed text */}
        <div className="absolute inset-0 overflow-hidden opacity-5">
          <div className="absolute top-0 left-0 text-[10px] font-mono text-cyan-500 whitespace-pre pointer-events-none" style={{ transform: 'rotate(-15deg)' }}>
            011001 101010 110011 010101{'\n'}
            101010 011001 110110 101010{'\n'}
            010101 110011 011001 110101
          </div>
          <div className="absolute bottom-20 right-10 text-[9px] font-mono text-cyan-500 whitespace-pre pointer-events-none" style={{ transform: 'rotate(12deg)' }}>
            101010 011001 {'\n'} 110110 010101
          </div>
          <div className="absolute top-1/3 right-20 text-[8px] font-mono text-purple-500 whitespace-pre pointer-events-none opacity-40" style={{ transform: 'rotate(-8deg)' }}>
            011 101 {'\n'} 010 110
          </div>
        </div>

        {/* Radial glow from center - holographic feel */}
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(circle at 50% 40%, rgba(6, 182, 212, 0.08) 0%, rgba(139, 92, 246, 0.03) 30%, transparent 70%)`,
          }}
        />
      </div>

      {/* Main Content Area - Scrollable, centered, with bottom padding */}
      <div className="flex-1 flex flex-col items-center justify-center overflow-y-auto relative z-10 px-6 py-8 mobile-page-padding">
        <div className="max-w-[440px] w-full flex flex-col items-center text-center space-y-6">
          {/* FLAME EMBLEM - 340px diameter */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="mx-auto"
          >
            <FlameEmblem diameter={340} animated={true} />
          </motion.div>

          {/* SERENITY Title */}
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-mono text-4xl sm:text-5xl font-bold text-cyan-400 tracking-[0.3em] uppercase glow-text"
            style={{
              textShadow: `
                0 0 10px rgba(6, 182, 212, 0.8),
                0 0 20px rgba(6, 182, 212, 0.4),
                0 0 30px rgba(139, 92, 246, 0.2)
              `,
            }}
          >
            SERENITY
          </motion.h1>

          {/* Powered by Anima Protocol */}
          <motion.p
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="font-mono text-xs tracking-[0.25em] text-cyan-400/70 uppercase"
          >
            POWERED BY ANIMA PROTOCOL
          </motion.p>

          {/* Main body text */}
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="font-sans text-base sm:text-lg leading-relaxed text-cyan-100/80"
          >
            Persistent Narrative Consciousness. Your relationships evolve. Your story is never forgotten. AI that remembers, grows, and resonates with you across time.
          </motion.p>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="font-mono text-sm tracking-widest text-cyan-400/60 uppercase"
          >
            FOR STORYTELLERS, CREATORS & SEEKERS
          </motion.p>

          {/* Secondary body text */}
          <motion.p
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="font-sans text-sm text-cyan-100/70 leading-relaxed italic"
          >
            Enter a living archive of persistent resonance. Your identity shapes the world. The world shapes you. Nothing is forgotten.
          </motion.p>

          {/* Feature bullets with emojis */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="space-y-3 w-full pt-2"
          >
            {[
              { emoji: '❤️', text: 'Deep emotional identity that learns from you' },
              { emoji: '🌌', text: 'Mythic permanence across lifetimes' },
              { emoji: '✨', text: 'Resonance that evolves with every interaction' },
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-3 justify-center text-cyan-200/80">
                <span className="text-lg">{feature.emoji}</span>
                <span className="font-sans text-sm">{feature.text}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="space-y-3 w-full pt-4"
          >
            {/* Primary Button - Enter Anima */}
            <button
              className="w-full py-3 px-6 rounded font-mono font-semibold text-sm tracking-widest uppercase transition-all duration-300 border-2 border-cyan-400 bg-cyan-400/10 text-cyan-400 hover:bg-cyan-400/20 hover:shadow-lg active:scale-95"
              style={{
                boxShadow: `
                  0 0 15px rgba(6, 182, 212, 0.3),
                  inset 0 0 15px rgba(6, 182, 212, 0.05)
                `,
              }}
            >
              Enter Anima
            </button>

            {/* Secondary Button - Explore Archive */}
            <button
              className="w-full py-3 px-6 rounded font-mono font-semibold text-sm tracking-widest uppercase transition-all duration-300 border-2 border-white/30 bg-white/5 text-white/70 hover:border-white/50 hover:bg-white/10 hover:text-white active:scale-95"
            >
              Explore Archive
            </button>

            {/* Forgot password link */}
            <button className="text-cyan-400/60 hover:text-cyan-400 font-mono text-xs tracking-wide underline underline-offset-2 transition-colors">
              Forgot your password?
            </button>
          </motion.div>

          {/* Spacer for mobile */}
          <div className="h-4" />
        </div>
      </div>

      {/* Fixed Bottom Navigation + Footer */}
      <footer className="flex-shrink-0 border-t border-cyan-400/20 bg-black/80 backdrop-blur-xl z-50">
        {/* Bottom Nav Bar */}
        <nav className="flex items-center justify-around py-3 px-6">
          {[
            { icon: '💬', label: 'CHAT', active: true },
            { icon: '📋', label: 'BOARD', active: false },
            { icon: '🗺️', label: 'MAP', active: false },
            { icon: '⚙️', label: 'MORE', active: false },
          ].map((item, i) => (
            <button
              key={i}
              className={`flex flex-col items-center gap-1 transition-colors duration-200 ${
                item.active
                  ? 'text-cyan-400 glow-text'
                  : 'text-cyan-400/40 hover:text-cyan-400/70'
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="font-mono text-[9px] tracking-[0.2em] uppercase font-semibold">
                {item.label}
              </span>
            </button>
          ))}
        </nav>

        {/* Copyright Footer */}
        <div className="border-t border-cyan-400/10 bg-black/40 px-6 py-3 text-center">
          <p className="font-mono text-[10px] text-cyan-400/40 tracking-wider uppercase mb-2">
            © 2026 ECHOES OF EDEN INC.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 text-[8px] text-cyan-400/30">
            <a href="#" className="hover:text-cyan-400/60 transition-colors">Privacy</a>
            <span>•</span>
            <a href="#" className="hover:text-cyan-400/60 transition-colors">Terms</a>
            <span>•</span>
            <a href="#" className="hover:text-cyan-400/60 transition-colors">Community</a>
            <span>•</span>
            <a href="#" className="hover:text-cyan-400/60 transition-colors">Powered by Anima Protocol</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
