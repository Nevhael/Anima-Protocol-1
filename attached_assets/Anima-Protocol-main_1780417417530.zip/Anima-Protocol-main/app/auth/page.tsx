"use client";
import React from 'react';
import GlassCard from '../../components/GlassCard';
import NeonButton from '../../components/NeonButton';

export default function AuthPage(){
  return (
    <div className="p-5 h-full flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div className="text-xl font-bold">Create account</div>
        <div className="text-sm text-zinc-400">Development mode</div>
      </div>

      <GlassCard>
        <div className="flex flex-col gap-3">
          <button className="w-full py-3 rounded-lg bg-black/30 border border-white/6 flex items-center justify-center gap-3">Sign in with Apple</button>
          <button className="w-full py-3 rounded-lg bg-black/30 border border-white/6 flex items-center justify-center gap-3">Sign in with Google</button>
          <button className="w-full py-3 rounded-lg bg-black/30 border border-white/6 flex items-center justify-center gap-3">Sign in with GitHub</button>
        </div>
      </GlassCard>

      <GlassCard>
        <form className="flex flex-col gap-3">
          <input placeholder="Email" className="px-3 py-2 rounded-md bg-transparent border border-white/6 text-zinc-100" />
          <input placeholder="Phone" className="px-3 py-2 rounded-md bg-transparent border border-white/6 text-zinc-100" />
          <input placeholder="Password" type="password" className="px-3 py-2 rounded-md bg-transparent border border-white/6 text-zinc-100" />
          <NeonButton className="w-full">Continue</NeonButton>
        </form>
      </GlassCard>

      <div className="mt-auto text-center text-zinc-400 text-sm">By creating an account you agree to the protocol.</div>
    </div>
  );
}
