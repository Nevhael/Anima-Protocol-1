// src/api/base44Client.js
import { createClient } from '@base44/sdk';
import { appParams } from '@/lib/app-params';

const apiKey = appParams.token;
const appId = appParams.appId;

export const base44 = createClient({
  appId,
  token: apiKey,
  functionsVersion: appParams.functionsVersion || 'latest',
  serverUrl: '',
  requiresAuth: false,
  appBaseUrl: appParams.appBaseUrl,
});

// Dev-only log
if (import.meta.env.DEV) {
  console.log('✅ Base44 client initialized', appId ? '(with key)' : '⚠️ MISSING KEY');
}