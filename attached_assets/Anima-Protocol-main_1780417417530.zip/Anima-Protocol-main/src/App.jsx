export default function App() {
  return (
    <div style={{ background: "black", color: "white", minHeight: "100vh", padding: 40 }}>
      <h1>Anima Protocol Test Render</h1>
      <p>React works.</p>
    </div>
  );
}
