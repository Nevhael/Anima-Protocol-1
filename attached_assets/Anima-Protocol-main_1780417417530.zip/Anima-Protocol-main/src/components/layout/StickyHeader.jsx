import React from 'react'

export default function StickyHeader({ left, right, children }) {
  return (
    <header className="border-b border-primary/20 bg-black/60 backdrop-blur-md px-6 py-4 sticky top-0 z-40">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">{left}</div>
        <div className="flex items-center gap-2">{children}</div>
        <div className="flex items-center gap-2">{right}</div>
      </div>
    </header>
  )
}
