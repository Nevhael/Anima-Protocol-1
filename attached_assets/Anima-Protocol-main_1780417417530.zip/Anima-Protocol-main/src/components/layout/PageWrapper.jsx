import React from 'react'

export default function PageWrapper({ children, style, className = '' }) {
  return (
    <div
      className={`min-h-[100dvh] bg-background scanline ${className}`}
      style={{ paddingBottom: "var(--tab-bar-height, 120px)", ...(style || {}) }}
    >
      {children}
    </div>
  )
}
