import React from 'react'

export default function ContentContainer({ children, className = '' }) {
  return (
    <div className={`max-w-4xl mx-auto px-6 py-12 space-y-8 pb-24 lg:pb-12 ${className}`}>
      {children}
    </div>
  )
}
