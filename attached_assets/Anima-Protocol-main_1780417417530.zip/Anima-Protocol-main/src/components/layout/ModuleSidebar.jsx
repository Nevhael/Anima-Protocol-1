import { Link, useLocation } from "react-router-dom";
import {
  Home,
  MapPin,
  BookOpen,
  Layers,
  Sparkles,
  Heart,
  Shield,
  Users,
  Compass,
  Settings,
  FileText,
  Grid,
} from "lucide-react";

const MODULES = [
  { path: "/home", label: "Dashboard", icon: Home, description: "Narrative command center" },
  { path: "/storyboard", label: "Storyboard", icon: Layers, description: "Branching story flow" },
  { path: "/worldmap", label: "World Map", icon: MapPin, description: "Location intelligence" },
  { path: "/quest-journal", label: "Quest Journal", icon: BookOpen, description: "Active tasks & arcs" },
  { path: "/memory-map", label: "Memory Map", icon: Grid, description: "Relationships & resonance" },
  { path: "/characters-repository", label: "Characters", icon: Users, description: "Roster & bond levels" },
  { path: "/what-if", label: "What If", icon: Sparkles, description: "Scenario exploration" },
  { path: "/settings", label: "Settings", icon: Settings, description: "System preferences" },
];

export default function ModuleSidebar() {
  const location = useLocation();
  const currentPath = location.pathname;

  return (
    <aside className="hidden lg:flex flex-col w-72 shrink-0 border-r border-primary/15 bg-black/70 backdrop-blur-xl text-primary min-h-screen overflow-hidden">
      <div className="px-6 py-5 border-b border-primary/10">
        <div className="flex items-center gap-3">
          <div className="grid place-items-center w-11 h-11 rounded-2xl bg-primary/15 text-primary shadow-[inset_0_0_18px_rgba(0,229,255,0.16)]">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-mono text-primary/40 uppercase tracking-[0.35em]">ANIMA OS</p>
            <h2 className="mt-1 text-lg font-semibold tracking-tight">Command Nexus</h2>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-2 py-4 space-y-2">
        {MODULES.map((module) => {
          const isActive = module.path === currentPath;
          const Icon = module.icon;
          return (
            <Link
              key={module.path}
              to={module.path}
              className={`group flex flex-col gap-1 rounded-3xl px-4 py-3 transition-all duration-200 ${
                isActive ? "bg-primary/15 text-primary" : "text-primary/60 hover:bg-primary/10 hover:text-primary"
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={`grid place-items-center w-9 h-9 rounded-2xl ${isActive ? "bg-primary/20" : "bg-white/5"}`}>
                  <Icon className="w-4 h-4" />
                </span>
                <div>
                  <p className="text-sm font-semibold tracking-[0.02em]">{module.label}</p>
                  <p className="text-[9px] text-primary/40 tracking-[0.25em] uppercase">{module.description}</p>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      <div className="border-t border-primary/10 px-6 py-5">
        <p className="text-[9px] font-mono text-primary/40 uppercase tracking-[0.35em] mb-3">Quick access</p>
        <div className="grid gap-3">
          <Link
            to="/chat/1"
            className="flex items-center justify-center gap-2 rounded-3xl border border-primary/15 bg-primary/5 px-4 py-3 text-sm font-semibold text-primary transition-all hover:bg-primary/10"
          >
            <MessageIcon className="w-4 h-4" />
            Open Chat
          </Link>
          <Link
            to="/lorebook"
            className="flex items-center justify-center gap-2 rounded-3xl border border-primary/15 bg-white/5 px-4 py-3 text-sm font-semibold text-primary/70 transition-all hover:bg-primary/10 hover:text-primary"
          >
            <BookOpen className="w-4 h-4" />
            Lore Vault
          </Link>
        </div>
      </div>
    </aside>
  );
}

function MessageIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}
