import { Link, useLocation, useNavigate } from "react-router-dom";
import { MessageSquare, Users, Settings, Sparkles, Heart, Menu, X, MoreVertical, BookOpen, Home } from "lucide-react";
import { useTabNavigation } from "@/hooks/useTabNavigation";
import { useState, useEffect, useCallback, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { base44 } from "@/api/base44Client";

// Paths where we want to preserve scroll position across tab switches
const SCROLL_PRESERVED_PATHS = ["/", "/chat"];

// Per-tab last-visited path — maps tab root path → last full path visited within that tab
const TAB_ROOTS = ["/", "/characters", "/chronicles", "/animas", "/meditation", "/settings"];

function getTabRoot(pathname) {
  // Find the longest matching tab root
  return TAB_ROOTS.slice().sort((a, b) => b.length - a.length).find(root =>
    root === "/" ? pathname === "/" || pathname.startsWith("/chat") : pathname.startsWith(root)
  ) || "/";
}

function saveTabPath(tabRoot, pathname) {
  sessionStorage.setItem(`tab_path_${tabRoot.replace(/\//g, "_") || "root"}`, pathname);
}

function getTabPath(tabRoot) {
  return sessionStorage.getItem(`tab_path_${tabRoot.replace(/\//g, "_") || "root"}`) || tabRoot;
}

function saveScrollPosition(pathname) {
  const key = `scroll_pos_${pathname.replace(/\//g, "_") || "root"}`;
  const scrollEl = document.querySelector("[data-scroll-preserve]") || document.querySelector(".overflow-y-auto");
  if (scrollEl) sessionStorage.setItem(key, String(scrollEl.scrollTop));
}

function restoreScrollPosition(pathname) {
  const key = `scroll_pos_${pathname.replace(/\//g, "_") || "root"}`;
  const saved = sessionStorage.getItem(key);
  if (!saved) return;
  requestAnimationFrame(() => {
    const scrollEl = document.querySelector("[data-scroll-preserve]") || document.querySelector(".overflow-y-auto");
    if (scrollEl) scrollEl.scrollTop = parseInt(saved, 10);
  });
}

const tabs = [
  { path: "/home", label: "Home", icon: Home },
  { path: "/", label: "Chat", icon: MessageSquare, special: "chat" },
  { path: "/characters", label: "Characters", icon: Users },
  { path: "/chronicles", label: "Chronicles", icon: BookOpen },
  { path: "/animas", label: "Animas", icon: Sparkles },
  { path: "/meditation", label: "Sacred", icon: Heart },
  { path: "/settings", label: "Settings", icon: Settings },
];

export default function BottomTabBar({ onMenuClick }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { handleTabClick, getActiveTab } = useTabNavigation();
  const [open, setOpen] = useState(false);
  const [mostRecentSessionId, setMostRecentSessionId] = useState(null);

  // Save scroll when leaving a preserved path
  const handleTabNavigate = useCallback((toPath, fromPath) => {
    const isPreserved = SCROLL_PRESERVED_PATHS.some(p => fromPath.startsWith(p));
    if (isPreserved) saveScrollPosition(fromPath);
  }, []);

  // Restore scroll when arriving at a preserved path
  useEffect(() => {
    const isPreserved = SCROLL_PRESERVED_PATHS.some(p => location.pathname.startsWith(p));
    if (isPreserved) restoreScrollPosition(location.pathname);
  }, [location.pathname]);

  // Save the current path under its tab root whenever location changes
  useEffect(() => {
    const root = getTabRoot(location.pathname);
    saveTabPath(root, location.pathname);
  }, [location.pathname]);

  useEffect(() => {
    base44.entities.ChatSession.list("-updated_date", 1).then(sessions => {
      if (sessions?.length > 0) setMostRecentSessionId(sessions[0].id);
    }).catch(() => {});
  }, []);

  // Theme-aware variant selection for drawer animation
  const [navVariant, setNavVariant] = useState("slide");
  useEffect(() => {
    try {
      const isDark = document?.documentElement?.classList?.contains("dark");
      setNavVariant(isDark ? "slide" : "fade");
    } catch (e) {
      setNavVariant("slide");
    }
  }, []);

  const navRef = useRef(null);
  // Keyboard shortcuts + focus management for the drawer
  useEffect(() => {
    function handleKey(e) {
      // Toggle drawer: Ctrl/Cmd + M
      if ((e.ctrlKey || e.metaKey) && (e.key === 'm' || e.key === 'M')) {
        e.preventDefault();
        setOpen(o => !o);
        return;
      }

      // Close on Escape
      if (e.key === 'Escape') {
        setOpen(false);
      }
    }

    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    if (open && navRef.current) {
      const first = navRef.current.querySelector('a,button');
      if (first && typeof first.focus === 'function') first.focus();
    }
  }, [open]);

  const activeTab = getActiveTab(location.pathname);
  const activeTabData = tabs.find(t => t.path === activeTab) || tabs[0];
  const ActiveIcon = activeTabData.icon;

  return (
    <>
      {/* Backdrop */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Vertical nav drawer — mobile: full width from bottom; desktop: left-anchored panel */}
      <AnimatePresence>
        {open && (
          <motion.nav
            ref={navRef}
            variants={{
              slide: {
                hidden: { y: "100%", opacity: 0 },
                visible: { y: 0, opacity: 1 },
                exit: { y: "100%", opacity: 0 },
              },
              fade: {
                hidden: { y: "2%", opacity: 0 },
                visible: { y: 0, opacity: 1 },
                exit: { y: "2%", opacity: 0 },
              },
            }[navVariant]}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={{ type: navVariant === "slide" ? "spring" : "tween", damping: 28, stiffness: 300, duration: 0.22 }}
            className="fixed z-50 border border-primary/30 bg-black/95 backdrop-blur-md overflow-y-auto
              /* mobile */ bottom-0 left-0 right-0 border-t
              /* desktop */ lg:bottom-14 lg:right-2 lg:left-auto lg:rounded-lg lg:w-52 lg:border"
            style={{ maxHeight: "60dvh", paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
          >
            <div className="flex flex-col py-2">
              {tabs.map(({ path, label, icon: Icon, special }) => {
                const isActive = activeTab === path;
                return (
                  <Link
                    key={path}
                    to={path}
                    onClick={(e) => {
                      e.preventDefault();
                      handleTabNavigate(path, location.pathname);
                      // For Chat tab, always go to most recent session
                      if (special === "chat" && mostRecentSessionId) {
                        navigate(`/chat/${mostRecentSessionId}`);
                      } else {
                        // Restore last visited path within this tab
                        const savedPath = getTabPath(path);
                        navigate(savedPath);
                      }
                      setOpen(false);
                    }}
                    className={`flex items-center gap-4 px-6 py-4 transition-all border-b border-primary/10 last:border-b-0 ${
                      isActive
                        ? "text-primary bg-primary/10"
                        : "text-primary/40 hover:text-primary/70 hover:bg-primary/5"
                    }`}
                    tabIndex={0}
                  >
                    <Icon className="w-5 h-5 flex-shrink-0" />
                    <span className={`font-mono text-sm tracking-[0.2em] uppercase ${isActive ? "glow-text" : ""}`}>
                      {label}
                    </span>
                    {isActive && (
                      <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary" />
                    )}
                  </Link>
                );
              })}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>

      {/* Bottom bar — mobile, tablet & desktop */}
       <div
        className="fixed bottom-0 z-[999] left-0 right-0 border-t border-primary/20 bg-black/95 backdrop-blur-md tab-bar flex items-center justify-between px-3 min-h-[44px]"
        style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
      >
        <button
          type="button"
          onClick={() => onMenuClick?.()}
          className="p-2 text-primary/60 hover:text-primary transition-colors flex-shrink-0"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center gap-1 text-primary font-mono text-xs tracking-[0.2em] uppercase glow-text">
          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/5 border border-primary/20">
            <ActiveIcon className="w-5 h-5" />
          </div>
          <span>{activeTabData.label}</span>
        </div>

        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="p-2 text-primary/50 hover:text-primary transition-colors"
          aria-label="Toggle navigation drawer"
        >
          {open ? <X className="w-5 h-5" /> : <MoreVertical className="w-5 h-5" />}
        </button>
      </div>
    </>
  );
}