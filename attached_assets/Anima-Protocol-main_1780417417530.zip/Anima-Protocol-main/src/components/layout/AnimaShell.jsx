import { useLocation } from "react-router-dom";
import { Sparkles, TrendingUp, ShieldCheck, Layers, Users } from "lucide-react";
import ModuleSidebar from "./ModuleSidebar";

const PAGE_LABELS = {
  "/home": { title: "Narrative Dashboard", subtitle: "Current storyline health, active arcs, and fast access to core systems." },
  "/storyboard": { title: "Story Flowchart", subtitle: "Visualize branching beats, plot forks, and emergent narrative paths." },
  "/worldmap": { title: "World Map", subtitle: "Track regions, lore nodes, and location intelligence." },
  "/quest-journal": { title: "Quest Journal", subtitle: "Active tasks, objectives, and quest momentum." },
  "/memory-map": { title: "Memory Map", subtitle: "Relationship resonance, memory nodes, and emotional topology." },
  "/characters-repository": { title: "Character Nexus", subtitle: "Roster, affinities, and bond levels for your cast." },
  "/what-if": { title: "What If Explorer", subtitle: "Run scenario experiments that illuminate alternate story futures." },
  "/settings": { title: "System Settings", subtitle: "Fine-tune AI behavior, interface tone, and identity preferences." },
};

export default function AnimaShell({ children, headerActions }) {
  const location = useLocation();
  const page = PAGE_LABELS[location.pathname] || {
    title: "Anima Control",
    subtitle: "Immersive narrative tools for your worldbuilding command center.",
  };

  return (
    <div className="min-h-[100dvh] bg-background text-primary overflow-hidden">
      <div className="lg:flex lg:min-h-[100dvh]">
        <ModuleSidebar />
        <div className="flex-1 flex flex-col min-h-[100dvh]">
          <header className="sticky top-0 z-30 border-b border-primary/10 bg-black/60 backdrop-blur-xl px-5 py-4 lg:px-8">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
              <div>
                <p className="text-[9px] font-mono text-primary/40 uppercase tracking-[0.35em] mb-2">Narrative Command Center</p>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-sacred tracking-tight">{page.title}</h1>
                    <p className="mt-2 max-w-2xl text-sm text-primary/60 leading-relaxed">{page.subtitle}</p>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <HeaderStat label="Universe" value="Anima" icon={Sparkles} />
                    <HeaderStat label="Phase" value="Orbital" icon={TrendingUp} />
                    <HeaderStat label="Stability" value="92%" icon={ShieldCheck} />
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 self-start xl:self-center">
                {headerActions}
              </div>
            </div>
          </header>

          <main className="flex-1 overflow-y-auto px-5 py-6 lg:px-8 lg:py-8">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
}

function HeaderStat({ label, value, icon: Icon }) {
  return (
    <div className="rounded-3xl border border-primary/10 bg-white/5 px-4 py-3 backdrop-blur-xl text-left min-w-[130px]">
      <div className="flex items-center gap-3">
        <span className="grid place-items-center w-9 h-9 rounded-2xl bg-primary/10 text-primary">
          <Icon className="w-4 h-4" />
        </span>
        <div>
          <p className="text-[9px] font-mono text-primary/40 uppercase tracking-[0.25em]">{label}</p>
          <p className="font-semibold text-sm text-primary">{value}</p>
        </div>
      </div>
    </div>
  );
}
