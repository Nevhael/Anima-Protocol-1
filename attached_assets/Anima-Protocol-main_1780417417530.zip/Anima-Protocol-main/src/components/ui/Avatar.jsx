import React from 'react'

export default function Avatar({ src, alt = '', className = '' }) {
  return (
    <img
      src={src}
      alt={alt}
      className={`w-16 h-16 rounded-full object-cover border border-primary/30 glow-border ${className}`}
    />
  )
}
