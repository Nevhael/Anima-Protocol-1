import React from 'react'

export default function SectionCard({ children, className = '' }) {
  return (
    <div className={`border border-primary/30 bg-black/40 p-8 hud-corner ${className}`}>
      {children}
    </div>
  )
}
