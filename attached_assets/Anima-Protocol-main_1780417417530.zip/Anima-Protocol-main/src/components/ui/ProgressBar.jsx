import React from 'react'

export default function ProgressBar({ value = 0, className = '' }) {
  const pct = Math.max(0, Math.min(100, value))
  return (
    <div className={`flex-1 h-2 bg-black/60 border border-primary/20 rounded overflow-hidden ${className}`}>
      <div className="h-full bg-primary/70" style={{ width: `${pct}%` }} />
    </div>
  )
}
