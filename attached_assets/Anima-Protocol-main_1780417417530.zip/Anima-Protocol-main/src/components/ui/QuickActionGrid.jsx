import React from 'react'

export function QuickActionGrid({ items = [] }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {items.map((it, idx) => (
        <div key={idx} className="border border-primary/20 bg-black/40 p-4 flex flex-col items-center gap-2 hover:border-primary/40 transition-all cursor-pointer">
          {it.icon && <it.icon className="w-5 h-5 text-primary/60" />}
          <p className="font-mono text-[9px] tracking-widest uppercase text-primary/60">{it.label}</p>
          {it.description && <p className="font-mono text-[8px] text-primary/30 text-center">{it.description}</p>}
        </div>
      ))}
    </div>
  )
}

export default QuickActionGrid
