import React from 'react'

export default function FullPageSpinner({ label = 'Initializing...' }) {
  return (
    <div className="min-h-[100dvh] bg-background scanline flex items-center justify-center">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-4" />
        <p className="font-mono text-primary/40 text-xs tracking-[0.3em] uppercase">{label}</p>
      </div>
    </div>
  )
}
