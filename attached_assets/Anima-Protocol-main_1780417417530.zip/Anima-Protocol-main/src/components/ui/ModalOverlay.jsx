import React from 'react'
import { motion } from 'framer-motion'

export default function ModalOverlay({ children, className = '' }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className={`fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 ${className}`}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="w-full max-w-md bg-background border border-primary/30 hud-corner p-6 space-y-6">
        {children}
      </motion.div>
    </motion.div>
  )
}
