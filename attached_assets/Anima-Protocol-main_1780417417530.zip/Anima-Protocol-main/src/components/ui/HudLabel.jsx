import React from 'react'

export default function HudLabel({ children }) {
  return (
    <p className="font-mono text-[9px] text-primary/40 tracking-widest uppercase">{children}</p>
  )
}
